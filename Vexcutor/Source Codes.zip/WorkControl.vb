﻿Public Class WorkControl
    Public FeatureCol As New List(Of Nuctions.Feature)
    'Public EnzymeCol As New List(Of Nuctions.RestrictionEnzyme)
    Public EnzymeCol As New List(Of String)


    '保存自己所属的Tab页
    Private vTabPage As TabPage

    '返回自己所属的Tab页
    Public Property ParentTab() As TabPage
        Get
            Return vTabPage
        End Get
        Set(ByVal value As TabPage)
            vTabPage = value
        End Set
    End Property

    '双击之后打开文件
    Private Sub lv_Chart_DoubleClick(ByVal sender As Object, ByVal e As System.EventArgs)
        If lv_Chart.SelectedItems.Count = 1 Then
            Dim ci As ChartItem = lv_Chart.SelectedItems(0)
            If Form.ModifierKeys = Keys.Alt Then
                'view the property
                'ShowProperties(Me.lv_Chart.SelectedItems(0))
            Else
                If ci.MolecularInfo.DNAs.Count = 1 Then
                    Dim gf As Nuctions.GeneFile = ci.MolecularInfo.DNAs(1)
                    gf.WriteToFile("Temp.gb")
                    Nuctions.ShowGBFile("Temp.gb")
                Else
                    'view the property
                    'ShowProperties(Me.lv_Chart.SelectedItems(0))
                End If
            End If
        End If
    End Sub

    Private Sub ViewVToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ViewVToolStripMenuItem.Click
        If lv_Chart.SelectedItems.Count = 1 Then
            Dim ci As ChartItem = lv_Chart.SelectedItems(0)
            Dim DNA As Nuctions.GeneFile
            Dim i As Integer = 0
            For Each DNA In ci.MolecularInfo.DNAs
                DNA.WriteToFile("Temp" + i.ToString + ".gb")
                Nuctions.ShowGBFile("Temp" + i.ToString + ".gb")
                i += 1
            Next
        End If
    End Sub
#Region "IO操作"

    '保存实验到指定文件
    Public Sub SaveTo(ByVal filename As String)

        Dim XOS As New XmlObjectSerializer
        Dim WS As New WorkSpace
        Dim Citems As New List(Of DNAInfo)
        For Each o As ChartItem In lv_Chart.Items
            Citems.Add(o.MolecularInfo)
        Next

        WS.Scale = lv_Chart.ScaleValue
        WS.OffsetX = lv_Chart.Offset.X
        WS.OffsetY = lv_Chart.Offset.Y

        WS.ChartItems.AddRange(Citems)

        WS.Features.AddRange(FeatureCol)
        Dim cenzs As New List(Of String)
        For Each enz As String In EnzymeCol
            cenzs.Add(enz)
        Next
        WS.Enzymes.AddRange(cenzs)

        WS.Summary = pvMain.rtbSummary.Text

        XOS.Diagnostic = True

        XOS.Add(WS, "WorkChart")

        XOS.SaveGZip(filename)

        Dim fi As New IO.FileInfo(filename)

        ParentTab.Text = fi.Name
        Changed = False
        nFilename = filename
    End Sub
    Private nFilename As String = ""

    '从指定文件中加载实验
    Public Shared Function LoadFrom(ByVal filename As String) As WorkControl
        'do not load a file if there are already files.
        Dim wc As New WorkControl
        Dim XOD As New XmlObjectDeserializer

        Dim DvD As DeviceDictionary = XOD.LoadXml(XmlObjectDeserializer.GetXmlRootFromGZipFile(filename))

        XOD.Deserialize(DvD)

        Dim WS As WorkSpace
        WS = XOD.GetObjectByKey("WorkChart")
        wc.nFilename = filename
        wc.lv_Chart.ScaleValue = WS.Scale
        wc.lv_Chart.Offset = New PointF(WS.OffsetX, WS.OffsetY)
        Dim vFile As New IO.FileInfo(wc.nFilename)
        wc.Text = vFile.Name
        wc.FeatureCol = WS.Features
        wc.EnzymeCol = WS.Enzymes
        wc.lv_Chart.LoadSummary(WS.ChartItems, wc.EnzymeCol)
        wc.pvMain.rtbSummary.Text = WS.Summary
        wc.pvMain.ShowEnzymes()
        Return wc
    End Function

    Public ReadOnly Property ContentChanged() As Boolean
        Get
            Return Changed
        End Get
    End Property
#End Region
    Private Sub WorkChart_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs)
        Select Case MsgBox("Do you want save before closing the current file?", MsgBoxStyle.YesNoCancel, "File Closing")
            Case MsgBoxResult.Yes
                If nFilename.Length = 0 Then
                    If sfdProject.ShowDialog = Windows.Forms.DialogResult.OK Then
                        Me.SaveTo(sfdProject.FileName)
                    End If
                Else
                    SaveTo(nFilename)
                End If
            Case MsgBoxResult.No
                'the file will be lost
            Case MsgBoxResult.Cancel
                e.Cancel = True
        End Select
    End Sub


    Public Sub DeleteItem(Optional ByVal Query As Boolean = True)
        If Query Then
            If MsgBox("Do You Really Want to Delete All the Selected Items?", MsgBoxStyle.YesNo) = MsgBoxResult.Yes Then
            Else
                Exit Sub
            End If
        End If
        Dim ci As ChartItem
        Dim delCol As New List(Of ChartItem)
        For Each ci In Me.lv_Chart.SelectedItems
            delCol.Add(ci)
        Next
        For Each ci In delCol
            lv_Chart.Remove(ci)
        Next

    End Sub

#Region "拖拽操作"

    Dim dragging As Boolean = False

    Private Sub lv_Chart_MouseDown(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs)
        If e.Button = Windows.Forms.MouseButtons.Left Then
            dragging = True
            cX = e.X
            cY = e.Y
        End If
    End Sub

    Dim dX As Integer, dY As Integer 'start position
    Dim cX As Integer, cY As Integer

    'Private Sub lv_Chart_MouseMove(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs)
    '    If Not dragging Then Exit Sub
    '    If Me.lv_Chart.SelectedItems.Count > 0 Then
    '        Dim ci As ChartItem
    '        dX = e.X - cX
    '        dY = e.Y - cY
    '        cX = e.X
    '        cY = e.Y
    '        For Each ci In Me.lv_Chart.SelectedItems
    '            ci.Position = New Point(ci.Position.X + dX, ci.Position.Y + dY)
    '        Next
    '        SavePositions()
    '    End If
    'End Sub

    Private MenuLocation As Point
    'Private Sub lv_Chart_MouseUp(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs)
    '    If dragging Then
    '        dragging = False
    '        SavePositions()
    '    Else

    '    End If
    '    If e.Button = Windows.Forms.MouseButtons.Right Then
    '        MenuLocation = e.Location
    '        'cms_ChartItem.Show(Me, e.Location)
    '    End If
    'End Sub

#End Region
    'Public OffsetO As Point = New Point(0, 0)
#Region "ListView坐标和绘图"


    '每次移动之后 记录所有项的位置 以及屏幕的offset
#End Region

    Private frmRecord As New frmExpRecord

    Private Sub lv_Chart_PositionChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles lv_Chart.PositionChanged
        Changed = True
    End Sub


    '加载文件时绘图


    '选中操作
    Private Sub lv_Chart_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles lv_Chart.SelectedIndexChanged
        If lv_Chart.SourceMode Then
            vTarget.Source.Clear()
            For Each ci As ChartItem In lv_Chart.SelectedItems
                vTarget.Source.Add(ci.MolecularInfo)
            Next
            lv_Chart.Draw()
        Else
            Dim sitems As New List(Of ChartItem)

            For Each it As ChartItem In lv_Chart.SelectedItems
                sitems.Add(it)
            Next
            pvMain.SelectItem = sitems
            lv_Chart.Focus()
        End If

    End Sub

#Region "PropertyView 指令事件"

    Private Sub pvMain_Close(ByVal sender As Object, ByVal e As System.EventArgs) Handles pvMain.Close
        Close()
    End Sub

    Private Sub pvMain_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles pvMain.Load

    End Sub

    Private Sub pvMain_LoadExperiment(ByVal sender As Object, ByVal e As System.EventArgs) Handles pvMain.LoadExperiment
        LoadExperiment()
    End Sub
    Private Sub pvMain_LoadGeneFile(ByVal sender As Object, ByVal e As System.EventArgs) Handles pvMain.LoadGeneFile
        LoadVector()
    End Sub
    Private Sub pvMain_LoadSequenceFile(ByVal sender As Object, ByVal e As System.EventArgs) Handles pvMain.LoadSequenceFile

        If ofdSequence.ShowDialog = DialogResult.OK Then
            LoadSequenceFromFile(ofdSequence.FileName)
        End If
    End Sub

    Private Sub pvMain_LoadSequencingResultFile(ByVal sender As Object, ByVal e As System.EventArgs) Handles pvMain.LoadSequencingResultFile

    End Sub

    Private Sub pvMain_ManageEnzymes(ByVal sender As Object, ByVal e As RestrictionEnzymeView.RESiteEventArgs) Handles pvMain.ManageEnzymes
        EnzymeCol = e.RESites
        pvMain.ShowEnzymes()
        lv_Chart.SetEnzymes(EnzymeCol)

    End Sub

    Private Sub pvMain_ManageFeatures(ByVal sender As Object, ByVal e As FeatureEventArgs) Handles pvMain.ManageFeatures
        Me.FeatureCol.Clear()
        For Each ft As Nuctions.Feature In e.Features
            Me.FeatureCol.Add(ft)
        Next
    End Sub

    Private Sub pvMain_ReqireFeatures(ByVal sender As Object, ByVal e As FeatureEventArgs) Handles pvMain.ReqireFeatures
        Dim ftList As New List(Of Nuctions.Feature)
        For Each ft As Nuctions.Feature In FeatureCol
            ftList.Add(ft)
        Next
        e.Features = ftList
    End Sub

    Private Sub pvMain_RequireEnzymeSite(ByVal sender As Object, ByVal e As RestrictionEnzymeView.RESiteEventArgs) Handles pvMain.RequireEnzymeSite
        e.RESites = EnzymeCol
    End Sub

    Private Sub pvMain_SaveExperiment(ByVal sender As Object, ByVal e As System.EventArgs) Handles pvMain.SaveExperiment
        Save()
    End Sub

    Private Sub pvMain_SaveExperimentAs(ByVal sender As Object, ByVal e As System.EventArgs) Handles pvMain.SaveExperimentAs
        SaveAs()
    End Sub
#End Region

#Region "功能指令"
    Public Event CloseWorkControl(ByVal sender As Object, ByVal e As EventArgs)
    Public ReadOnly Property CurrentFileName() As String
        Get
            Return nFilename
        End Get
    End Property
    Public Sub Close()
        '询问关闭前是否保存
        RaiseEvent CloseWorkControl(Me, New EventArgs)
    End Sub
    Public Event LoadWorkControl(ByVal sender As Object, ByVal e As EventArgs)
    '加载文件
    Public Sub LoadExperiment()
        RaiseEvent LoadWorkControl(Me, New EventArgs)
    End Sub
    '保存文件
    Public Sub Save()
        If nFilename = "" Then
            SaveAs()
        Else
            SaveTo(nFilename)
        End If
    End Sub
    '另存文件
    Public Sub SaveAs()
        If sfdProject.ShowDialog = DialogResult.OK Then
            SaveTo(sfdProject.FileName)
        End If
    End Sub

    '加载一个GeneBank文件
    Public Sub LoadVector()
        If Not ofdGeneFile.ShowDialog = Windows.Forms.DialogResult.OK Then Exit Sub
        LoadVectorFromFile(ofdGeneFile.FileName)
    End Sub
    Public Sub LoadVectorFromFile(ByVal sFilename As String)
        Dim vec As Nuctions.GeneFile = Nuctions.GeneFile.LoadFromGeneBankFile(sFilename)
        Dim ci As New DNAInfo
        Dim gn As Nuctions.GeneAnnotation
        Dim ft As Nuctions.Feature
        Dim fts As List(Of Nuctions.Feature) = FeatureCol
        Dim exist As Boolean
        For Each gn In vec.Features
            'Add the annotation to the collection so that we can store the features
            'The features are useful in the ligation and screen
            ft = New Nuctions.Feature(gn.Label + " <" + vec.Name + "> (" + fts.Count.ToString + ")", gn.GetSuqence, gn.Label, gn.Type, gn.Note + " <" + vec.Name + ">")
            exist = False
            For Each fta As Nuctions.Feature In fts
                If Not (fta.Useful = "Native") AndAlso fta = ft Then
                    exist = True
                    Exit For
                End If
            Next
            If Not exist Then fts.Add(ft)
        Next
        ci.DNAs.Add(vec)
        'If ItemCol.Contains(vec.Name) Then MsgBox("There is already the " + vec.Name + " item!", MsgBoxStyle.OkOnly, "Loading Failed") : Exit Sub
        ci.Name = vec.Name
        ci.MolecularOperation = Nuctions.MolecularOperationEnum.Vector
        ci.File_Filename = sFilename
        'ci.MolecularInfo.FeatureCol = FeatureCol
        ci.DX = (lv_Chart.Width / 2) / lv_Chart.ScaleValue - lv_Chart.Offset.X
        ci.DY = (lv_Chart.Height / 2) / lv_Chart.ScaleValue - lv_Chart.Offset.Y
        lv_Chart.Add(ci, EnzymeCol)
        lv_Chart.Draw()
        Changed = True
    End Sub
    Public Sub LoadSequenceFromFile(ByVal sFilename As String)
        Dim str As String = Nuctions.TAGCFilter(IO.File.ReadAllText(sFilename))
        Dim fi As New System.IO.FileInfo(sFilename)
        LoadSequence(str, fi.Name, sFilename)
    End Sub
    Public Sub LoadSequence(ByVal seq As String, ByVal vName As String, Optional ByVal sFilename As String = "")
        Dim vec As New Nuctions.GeneFile
        vec.Name = vName
        vec.Sequence = seq
        vec.End_F = "*B"
        vec.End_R = "*B"
        'vec.Iscircular = False
        Dim ci As New DNAInfo
        ci.DNAs.Add(vec)
        'If ItemCol.Contains(vec.Name) Then MsgBox("There is already the " + vec.Name + " item!", MsgBoxStyle.OkOnly, "Loading Failed") : Exit Sub
        ci.Name = vec.Name
        ci.MolecularOperation = Nuctions.MolecularOperationEnum.Vector
        ci.File_Filename = sFilename
        'ci.MolecularInfo.FeatureCol = FeatureCol
        ci.DX = (lv_Chart.Width / 2) / lv_Chart.ScaleValue - lv_Chart.Offset.X
        ci.DY = (lv_Chart.Height / 2) / lv_Chart.ScaleValue - lv_Chart.Offset.Y
        lv_Chart.Add(ci, EnzymeCol)
        lv_Chart.Draw()
        Changed = True
    End Sub
    Private Changed As Boolean = False

    Public Function TryCopyDNAs() As List(Of Nuctions.GeneFile)
        Dim glist As New List(Of Nuctions.GeneFile)
        For Each si As ChartItem In lv_Chart.SelectedItems
            If si.MolecularInfo.DNAs.Count = 1 Then
                glist.Add(si.MolecularInfo.DNAs(1))
            End If
        Next
        Return glist
    End Function
    Public Sub TryPasteDNAs(ByVal gList As List(Of Nuctions.GeneFile))
        For Each gf As Nuctions.GeneFile In gList
            'vec.Iscircular = False
            Dim ci As New DNAInfo
            ci.DNAs.Add(gf)
            'If ItemCol.Contains(vec.Name) Then MsgBox("There is already the " + vec.Name + " item!", MsgBoxStyle.OkOnly, "Loading Failed") : Exit Sub
            ci.Name = gf.Name
            ci.MolecularOperation = Nuctions.MolecularOperationEnum.Vector
            ci.File_Filename = "<None>"
            'ci.MolecularInfo.FeatureCol = FeatureCol
            ci.DX = (lv_Chart.Width / 2) / lv_Chart.ScaleValue - lv_Chart.Offset.X
            ci.DY = (lv_Chart.Height / 2) / lv_Chart.ScaleValue - lv_Chart.Offset.Y
            lv_Chart.Add(ci, EnzymeCol)
        Next
        lv_Chart.Draw()
        Changed = True
    End Sub
#End Region

    '处理右键菜单
    Private Sub FunctionToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles EnzymeDigestionEToolStripMenuItem.Click, GelSeparationGToolStripMenuItem.Click, LigationLToolStripMenuItem.Click, ModificationMToolStripMenuItem.Click, PCRRToolStripMenuItem.Click, TransformationScreenTToolStripMenuItem.Click, RecombinationCToolStripMenuItem.Click, EnzymeAnalysisAToolStripMenuItem.Click
        AddNewOperation(sender.tag)
    End Sub

    Public Sub AddNewOperation(ByVal Method As Nuctions.MolecularOperationEnum, Optional ByVal AutoPosition As Boolean = False)
        If Me.lv_Chart.SelectedItems.Count = 0 Then Exit Sub
        Dim ci As New DNAInfo
        Dim ui As New ChartItem
        For Each ui In Me.lv_Chart.SelectedItems
            ci.Source.Add(ui.MolecularInfo)
        Next
        ci.MolecularOperation = Method
        'ci.MolecularInfo.ItemCol = Me.ItemCol
        'ci.MolecularInfo.FeatureCol = Me.FeatureCol
        Select Case ci.MolecularOperation
            Case Nuctions.MolecularOperationEnum.Enzyme
                ci.Name = "Digest"
            Case Nuctions.MolecularOperationEnum.Gel
                ci.Name = "Gel Separate"
            Case Nuctions.MolecularOperationEnum.Modify
                ci.Name = "Modify"
            Case Nuctions.MolecularOperationEnum.PCR
                ci.Name = "PCR"
            Case Nuctions.MolecularOperationEnum.Screen
                ci.Name = "Screen"
            Case Nuctions.MolecularOperationEnum.Recombination
                ci.Name = "Recombination"
            Case Nuctions.MolecularOperationEnum.EnzymeAnalysis
                ci.Name = "Analysis"
            Case Nuctions.MolecularOperationEnum.Ligation
                ci.Name = "Ligation"
        End Select
        ci.DX = lv_Chart.MenuLocation.X
        ci.DY = lv_Chart.MenuLocation.Y
        Dim ch As ChartItem = Me.lv_Chart.Add(ci, EnzymeCol)
        If AutoPosition Then
            ch.Draw(Graphics.FromImage(New Bitmap(1, 1, Imaging.PixelFormat.Format32bppArgb)))
            ch.AutoFit()
        End If
        Me.lv_Chart.SelectedItems.Clear()
        ch.Selected = True
        'ci.Position = New Point(, Y)
        Changed = True
        lv_Chart.Draw()
    End Sub

    Private Sub pvMain_ManageFeatures(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles pvMain.ManageFeatures

    End Sub

    Public Function CopySelectedSequence() As String
        Return pvMain.CopySelectSequence
    End Function

    Private Sub pvMain_LoadSequenceEvent(ByVal sender As Object, ByVal e As LoadSequenceEventArgs) Handles pvMain.LoadSequenceEvent
        LoadSequence(e.Sequence, "Sequence " + e.Sequence.Length.ToString)
    End Sub

    Private Sub pvMain_ExportPrimerList(ByVal sender As Object, ByVal e As System.EventArgs) Handles pvMain.ExportProject
        Dim stb As New System.Text.StringBuilder
        Dim l As Integer = lv_Chart.Items.Count.ToString.Length


        stb.AppendLine("-------- Project Information --------")
        stb.Append(pvMain.rtbSummary.Text.Replace(ControlChars.Lf, ControlChars.NewLine))
        stb.AppendLine()
        stb.AppendLine()
        stb.AppendLine()


        stb.AppendLine("-------- Starting Materials --------")
        For Each ci As ChartItem In lv_Chart.Items
            If ci.MolecularInfo.Source.Count = 0 Then
                stb.Append(ci.Index.ToString.PadLeft(l, "0") + " " + ci.MolecularInfo.Name)
                If ci.MolecularInfo.MolecularOperation = Nuctions.MolecularOperationEnum.Vector Then
                    stb.AppendLine(":")
                    If Not (ci.MolecularInfo.OperationDescription Is Nothing) Then
                        stb.AppendLine(ci.MolecularInfo.OperationDescription.Replace(ControlChars.Lf, ControlChars.NewLine))
                    Else
                        stb.AppendLine("N/A")
                    End If

                    stb.AppendLine()
                End If
            End If
        Next
        stb.AppendLine()
        stb.AppendLine()

        stb.AppendLine("-------- Enzyme Information --------")


        Dim ezlist As New List(Of String)

        For Each ci As ChartItem In lv_Chart.Items
            If ci.MolecularInfo.MolecularOperation = Nuctions.MolecularOperationEnum.Enzyme Then
                For Each ez As String In ci.MolecularInfo.Enzyme_Enzymes
                    If Not ezlist.Contains(ez) Then
                        ezlist.Add(ez)
                    End If
                Next
            End If
        Next
        ezlist.Sort()

        For Each ez As String In ezlist
            stb.Append(ez)
            stb.Append(" ")
        Next
        stb.AppendLine()

        Dim pmrDict As New Dictionary(Of String, String)
        Dim idxDict As New Dictionary(Of String, Integer)

        Dim pmK As String
        Dim pmR As String


        For Each ci As ChartItem In lv_Chart.Items
            If ci.MolecularInfo.MolecularOperation = Nuctions.MolecularOperationEnum.PCR Then
                pmK = ci.MolecularInfo.PCR_FPrimerName
                pmR = ci.MolecularInfo.PCR_ForwardPrimer

                If pmrDict.ContainsKey(pmK) Then
                    If Nuctions.TAGCFilter(pmrDict(pmK)) = Nuctions.TAGCFilter(pmR) Then

                    Else
                        ci.Selected = True
                        MsgBox("Different Primers have the same name At Item " + ci.Index.ToString.PadLeft(l, "0"), MsgBoxStyle.OkOnly, "Primer Error")
                        Exit Sub
                    End If
                ElseIf pmrDict.ContainsValue(pmR) Then
                    Dim sKey As String = "<Not Found>"
                    For Each key As String In pmrDict.Keys
                        If pmrDict(key) = pmR Then
                            sKey = key
                            Exit For

                        End If
                    Next
                    pmrDict.Add(pmK, "<See " + idxDict(sKey).ToString.PadLeft(l, "0") + " " + sKey + ">")
                    idxDict.Add(pmK, ci.Index)
                Else
                    pmrDict.Add(pmK, pmR)
                    idxDict.Add(pmK, ci.Index)
                End If

                pmK = ci.MolecularInfo.PCR_RPrimerName
                pmR = ci.MolecularInfo.PCR_ReversePrimer

                If pmrDict.ContainsKey(pmK) Then
                    If Nuctions.TAGCFilter(pmrDict(pmK)) = Nuctions.TAGCFilter(pmR) Then

                    Else
                        ci.Selected = True
                        MsgBox("Different Primers have the same name At Item " + ci.Index.ToString.PadLeft(l, "0"), MsgBoxStyle.OkOnly, "Primer Error")
                        Exit Sub
                    End If
                ElseIf pmrDict.ContainsValue(pmR) Then
                    Dim sKey As String = "<Not Found>"
                    For Each key As String In pmrDict.Keys
                        If pmrDict(key) = pmR Then
                            sKey = key
                            Exit For

                        End If
                    Next
                    pmrDict.Add(pmK, "<See " + idxDict(sKey).ToString.PadLeft(l, "0") + " " + sKey + ">")
                    idxDict.Add(pmK, ci.Index)
                Else
                    pmrDict.Add(pmK, pmR)
                    idxDict.Add(pmK, ci.Index)
                End If
            ElseIf ci.MolecularInfo.MolecularOperation = Nuctions.MolecularOperationEnum.Screen AndAlso ci.MolecularInfo.Screen_Mode = Nuctions.ScreenModeEnum.PCR Then
                pmK = ci.MolecularInfo.Screen_FName
                pmR = ci.MolecularInfo.Screen_FPrimer

                If pmrDict.ContainsKey(pmK) Then
                    If Nuctions.TAGCFilter(pmrDict(pmK)) = Nuctions.TAGCFilter(pmR) Then

                    Else
                        ci.Selected = True
                        MsgBox("Different Primers have the same name At Item " + ci.Index.ToString.PadLeft(l, "0"), MsgBoxStyle.OkOnly, "Primer Error")
                        Exit Sub
                    End If
                ElseIf pmrDict.ContainsValue(pmR) Then
                    Dim sKey As String = "<Not Found>"
                    For Each key As String In pmrDict.Keys
                        If pmrDict(key) = pmR Then
                            sKey = key
                            Exit For

                        End If
                    Next
                    pmrDict.Add(pmK, "<See " + idxDict(sKey).ToString.PadLeft(l, "0") + " " + sKey + ">")
                    idxDict.Add(pmK, ci.Index)
                Else
                    pmrDict.Add(pmK, pmR)
                    idxDict.Add(pmK, ci.Index)
                End If

                pmK = ci.MolecularInfo.Screen_RName
                pmR = ci.MolecularInfo.Screen_RPrimer

                If pmrDict.ContainsKey(pmK) Then
                    If Nuctions.TAGCFilter(pmrDict(pmK)) = Nuctions.TAGCFilter(pmR) Then

                    Else
                        ci.Selected = True
                        MsgBox("Different Primers have the same name At Item " + ci.Index.ToString.PadLeft(l, "0"), MsgBoxStyle.OkOnly, "Primer Error")
                        Exit Sub
                    End If
                ElseIf pmrDict.ContainsValue(pmR) Then
                    Dim sKey As String = "<Not Found>"
                    For Each key As String In pmrDict.Keys
                        If pmrDict(key) = pmR Then
                            sKey = key
                            Exit For

                        End If
                    Next
                    pmrDict.Add(pmK, "<See " + idxDict(sKey).ToString.PadLeft(l, "0") + " " + sKey + ">")
                    idxDict.Add(pmK, ci.Index)
                Else
                    pmrDict.Add(pmK, pmR)
                    idxDict.Add(pmK, ci.Index)
                End If
            End If
        Next
        stb.AppendLine()
        stb.AppendLine()
        stb.AppendLine("-------- Primer Information --------")
        Dim nts As Integer = 0
        Dim pms As Integer = 0

        For Each key As String In pmrDict.Keys
            stb.Append(idxDict(key).ToString.PadLeft(l, "0"))
            stb.Append(" ")
            stb.Append(key)
            stb.Append(":")
            If pmrDict(key).StartsWith("<See") Then
                stb.AppendLine()
                stb.AppendLine(pmrDict(key))
                stb.AppendLine()
            Else
                stb.Append(ControlChars.Tab)
                stb.Append("Tm:")
                stb.Append(Nuctions.CalculateTm(pmrDict(key), 80 * 0.001, 625 * 0.000000001).Tm.ToString("0.0"))
                stb.Append("/")
                stb.Append(Nuctions.CalculateTm(Nuctions.ParseInnerPrimer(pmrDict(key)), 80 * 0.001, 625 * 0.000000001).Tm.ToString("0.0"))
                stb.Append(ControlChars.Tab)
                stb.Append(pmrDict(key).Length.ToString)
                stb.Append("nt")
                stb.AppendLine()
                stb.Append(pmrDict(key))
                nts += Nuctions.TAGCFilter(pmrDict(key)).Length
                pms += 1
                stb.AppendLine()
                stb.AppendLine()
            End If
        Next

        stb.Append(">>Total: ")
        stb.Append(pms.ToString)
        stb.Append(" Primers ")
        stb.Append(nts.ToString)
        stb.Append(" Nucleotides")
        stb.AppendLine()
        stb.AppendLine()
        stb.AppendLine()
        stb.AppendLine("-------- Primer List For Synthesis --------")

        For Each key As String In pmrDict.Keys
            If pmrDict(key).StartsWith("<See") Then Continue For
            stb.Append(key)
            stb.Append(ControlChars.Tab)
            stb.Append(Nuctions.TAGCFilter(pmrDict(key)))
            stb.AppendLine()
        Next

        If sfdExport.ShowDialog = DialogResult.OK Then
            Dim fi As New IO.FileInfo(sfdExport.FileName)

            IO.File.WriteAllText(fi.FullName, stb.ToString)

            Dim fs As OperationView = lv_Chart
            Dim slist As New List(Of DNAInfo)
            For Each ci As ChartItem In lv_Chart.Items
                slist.Add(ci.MolecularInfo)
            Next
            fs.LoadSummary(slist, EnzymeCol)

            Dim di As New IO.DirectoryInfo(fi.FullName.Substring(0, fi.FullName.LastIndexOf(".")))
            di.Create()
            For Each dif As IO.FileInfo In di.GetFiles
                dif.Delete()
            Next
            fs.Draw()
            fs.SavePictureTo(di.FullName + "\Project Flowchart.emf")
            IO.File.WriteAllText(di.FullName + "\Project Info.txt", stb.ToString)
            fs.SaveFilesTo(di.FullName)
        End If

    End Sub

 

    Private Sub pvMain_RemarkFeature(ByVal sender As Object, ByVal e As System.EventArgs) Handles pvMain.RemarkFeature
        For Each ci As ChartItem In lv_Chart.Items
            For Each gf As Nuctions.GeneFile In ci.MolecularInfo.DNAs
                gf.Features.Clear()
            Next
            Nuctions.AddFeatures(ci.MolecularInfo.DNAs, FeatureCol)
            ci.Reload(ci.MolecularInfo, EnzymeCol)
        Next
        lv_Chart.Draw()
    End Sub

    Private Sub RecalculateAllChildrenToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RecalculateAllChildrenToolStripMenuItem.Click
        RecalculateAllChildren()
        lv_Chart.Draw()
    End Sub

    Public Sub UpdateView()
        lv_Chart.Draw()
    End Sub


    Private Sub RecalculateItem(ByVal ci As ChartItem)
        ci.MolecularInfo.Calculate()
        ci.Reload(ci.MolecularInfo, EnzymeCol)
    End Sub

    Public Sub RecalculateAllChildren()


        Dim cnLevel As New List(Of ChartItem)

        Dim ntLevel As New List(Of ChartItem)


        For Each ci As ChartItem In lv_Chart.SelectedItems
            ntLevel.Add(ci)
        Next

        While ntLevel.Count > 0
            cnLevel.Clear()
            cnLevel.AddRange(ntLevel)
            ntLevel.Clear()

            '排列下一层
            For Each ci As ChartItem In cnLevel
                RecalculateItem(ci)
            Next

            '再寻找下一层
            For Each si As ChartItem In lv_Chart.Items
                For Each ci As ChartItem In cnLevel
                    If si.MolecularInfo.Source.Contains(ci.MolecularInfo) Then
                        ntLevel.Add(si)
                        Exit For
                    End If
                Next
            Next
        End While

    End Sub

    Private Sub AutoArragneToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AutoArragneToolStripMenuItem.Click
        lv_Chart.AutoArragne()
    End Sub

    Private Sub AutoFitChildrenToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AutoFitChildrenToolStripMenuItem.Click
        lv_Chart.AutoFitChildren()
    End Sub

    Private Sub StepFitChildrenToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles StepFitChildrenToolStripMenuItem.Click
        lv_Chart.FitChildrenStepByStep()
    End Sub

    Private Sub pvMain_ExportSummary(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub WorkControl_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        lv_Chart.Menu = cms_ChartItem
    End Sub


    Dim vTarget As DNAInfo
    Dim vOldSource As List(Of DNAInfo)
    Public ReadOnly Property SourceMode() As Boolean
        Get
            Return lv_Chart.SourceMode
        End Get
    End Property
    Private Sub pvMain_RequireSource(ByVal sender As Object, ByVal e As SourceEventArgs) Handles pvMain.RequireSource
        vTarget = e.Target
        vOldSource = e.Target.Source
        e.Target.Source = New List(Of DNAInfo)
        e.Target.Source.AddRange(vOldSource)
        lv_Chart.SelectedItems.Clear()
        For Each ci As ChartItem In lv_Chart.Items
            If vTarget.Source.Contains(ci.MolecularInfo) Then lv_Chart.SelectedItems.Add(ci)
        Next
        lv_Chart.SourceMode = True
        'enter key to stop source mode
    End Sub

    Public Sub ExitMode()
        lv_Chart.SelectedItems.Clear()
        lv_Chart.SelectedItems.Add(pvMain.PrpC.RelatedChartItem)
        lv_Chart.SourceMode = False
        pvMain.PrpC.SetSource()
    End Sub
    Public Sub AcceptMode()
        If (vTarget Is Nothing) Or (Not lv_Chart.SourceMode) Then Exit Sub
        vTarget.Source.Clear()
        For Each ci As ChartItem In lv_Chart.SelectedItems
            vTarget.Source.Add(ci.MolecularInfo)
        Next
        lv_Chart.SelectedItems.Clear()
        lv_Chart.SelectedItems.Add(pvMain.PrpC.RelatedChartItem)
        lv_Chart.SourceMode = False
        pvMain.PrpC.SetSource()
        Changed = True
    End Sub

    Public Event GroupCopy(ByVal sender As Object, ByVal e As GroupCopyEventArgs)


    Private Sub tsmCopyGroup_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tsmCopyGroup.Click
        OnGroupCopy()
    End Sub

    Public Sub OnGroupCopy()
        Dim Group As New List(Of DNAInfo)
        For Each ci As ChartItem In Me.lv_Chart.SelectedItems
            Group.Add(ci.MolecularInfo)
        Next

        frmMain.GroupCopy = DuplicateGroup(Group)
    End Sub

    Public Function DuplicateGroup(ByVal cList As List(Of DNAInfo)) As List(Of DNAInfo)
        Dim Group As New List(Of DNAInfo)
        Dim DNADict As New Dictionary(Of DNAInfo, DNAInfo)

        Dim cl As DNAInfo
        For Each ci As DNAInfo In cList
            cl = ci.Clone
            cl.Source = New List(Of DNAInfo)
            cl.DNAs = New Collection
            For Each gf As Nuctions.GeneFile In ci.DNAs
                cl.DNAs.Add(gf.CloneWithoutFeatures)
            Next
            DNADict.Add(ci, cl)
        Next
        For Each di As DNAInfo In DNADict.Keys
            For Each si As DNAInfo In di.Source
                If DNADict.ContainsKey(si) Then
                    DNADict(di).Source.Add(DNADict(si))
                End If
            Next
        Next
        For Each di As DNAInfo In DNADict.Values
            Group.Add(di)
        Next
        Return Group
    End Function

    Public Sub GroupPaste()
        Dim cList As List(Of DNAInfo) = DuplicateGroup(frmMain.GroupCopy)
        If cList Is Nothing Then Exit Sub
        If cList.Count > 0 Then
            Dim px As Single = lv_Chart.MenuLocation.X

            Dim py As Single = lv_Chart.MenuLocation.Y

            Dim dx As Single = px - cList(0).DX
            Dim dy As Single = py - cList(0).DY

            Dim vSource As New List(Of DNAInfo)


            For Each ci As ChartItem In lv_Chart.SelectedItems
                vSource.Add(ci.MolecularInfo)

            Next


            For Each di As DNAInfo In cList
                di.DX += dx
                di.DY += dy
                Select Case di.MolecularOperation
                    Case Nuctions.MolecularOperationEnum.Vector
                    Case Else
                        If di.Source.Count = 0 Then di.Source.AddRange(vSource)
                End Select
                lv_Chart.Add(di, EnzymeCol)
            Next
            lv_Chart.Draw()
        End If
    End Sub
    Private Sub tsmPasteGroup_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tsmPasteGroup.Click
        GroupPaste()
        Changed = True
    End Sub

    Dim SwitchDistance As Integer

    Dim Switched As Boolean = False
    Public Sub SwitchSplitter()
        If Switched Then
            scMain.SplitterDistance = SwitchDistance
            Switched = False
        Else
            SwitchDistance = scMain.SplitterDistance
            scMain.SplitterDistance = 300
            Switched = True
        End If
    End Sub

End Class
