Public Class frmMain

    Public EnzymeCol As Nuctions.RestrictionEnzymes
    Public CodonCol As Nuctions.Translation
    Public StdFeatures As New List(Of Nuctions.Feature)
    Public RecombinationSiteDict As New Dictionary(Of String, Nuctions.RestrictionEnzyme)

    Public enzCollection As New Collection

    Private EmergencyExit As Boolean = False

    Dim enzFile As String
    Dim cdnFile As String

    Dim appPath As String = Application.StartupPath
    Dim sFilename As String = My.Application.Info.DirectoryPath + "\VecuteExt.lib"

    Public GroupCopy As List(Of DNAInfo)

#Region "����Tab"

    Public Sub NewTab()
        Dim WC As New WorkControl
        WC.Dock = DockStyle.Fill
        AddHandler WC.CloseWorkControl, AddressOf OnTabClose
        AddHandler WC.LoadWorkControl, AddressOf OnLoadTab
        Dim TP As New CustomTabPage
        WC.ParentTab = TP
        TP.Text = "New Experiment"
        TP.Controls.Add(WC)
        tcMainHost.TabPages.Add(TP)
    End Sub
    Public Sub LoadTabFromFile(ByVal filename As String)
        Try
            Dim wc As WorkControl = WorkControl.LoadFrom(filename)
            wc.Dock = DockStyle.Fill
            AddHandler wc.CloseWorkControl, AddressOf OnTabClose
            AddHandler wc.LoadWorkControl, AddressOf OnLoadTab
            Dim TP As New CustomTabPage
            wc.ParentTab = TP
            Dim fi As New IO.FileInfo(filename)
            TP.Text = fi.Name
            TP.Controls.Add(wc)
            If tcMainHost.TabPages.Count > 0 Then
                tcMainHost.TabPages.Insert(tcMainHost.SelectedIndex, TP)
                Dim SWC As WorkControl = SelectedWorkControl
                If SWC.ContentChanged = False And SWC.lv_Chart.Items.Count = 0 Then
                    CloseTab(SWC)
                    TP.Select()
                End If
            Else
                tcMainHost.TabPages.Add(TP)
            End If
        Catch ex As Exception
            MsgBox("Invalid File Format.", MsgBoxStyle.OkOnly)
        End Try
    End Sub
    Public Sub LoadTab()
        If ofdProject.ShowDialog = Windows.Forms.DialogResult.OK Then
            LoadTabFromFile(ofdProject.FileName)
        End If
    End Sub
    Public Sub OnTabClose(ByVal sender As Object, ByVal e As EventArgs)
        If TypeOf sender Is WorkControl Then
            Dim wc As WorkControl = sender
            RemoveHandler wc.CloseWorkControl, AddressOf OnTabClose
            RemoveHandler wc.LoadWorkControl, AddressOf OnLoadTab
            tcMainHost.TabPages.Remove(wc.ParentTab)
        End If
    End Sub
    Public Sub CloseTab(ByVal WC As WorkControl)
        RemoveHandler WC.CloseWorkControl, AddressOf OnTabClose
        RemoveHandler WC.LoadWorkControl, AddressOf OnLoadTab
        tcMainHost.TabPages.Remove(WC.ParentTab)
    End Sub
    Public Function TryCloseTab(ByVal TP As TabPage) As Boolean
        If Not TP Is Nothing Then
            If TypeOf TP.Controls(0) Is WorkControl Then
                Dim WC As WorkControl = TP.Controls(0)
                Return TryCloseTab(WC)
            Else
                Return True
            End If
        Else
            Return True
        End If
    End Function
    Public Function TryCloseTab(ByVal WC As WorkControl) As Boolean
        If Not WC Is Nothing Then
            If WC.ContentChanged Then
                Select Case MsgBox("Do you want to save the changes to ", MsgBoxStyle.YesNoCancel)
                    Case MsgBoxResult.Yes
                        WC.Save()
                        CloseTab(WC)
                        Return True
                    Case MsgBoxResult.No
                        CloseTab(WC)
                        Return True
                    Case MsgBoxResult.Cancel
                        Return False
                End Select
            Else
                CloseTab(WC)
                Return True
            End If
        Else
            Return True
        End If
    End Function

    Public Sub OnLoadTab(ByVal sender As Object, ByVal e As EventArgs)
        LoadTab()
    End Sub

#End Region

    Private Sub LoadRecombinationSites()
        Dim rec As String
        Dim cut As String
        Dim idx As Integer
        'loxP
        rec = Nuctions.TAGCFilter("ataa cttc gtat a atgtatgc t atac gaag ttat")
        cut = Nuctions.TAGCFilter("atgtatgc")
        idx = rec.IndexOf(cut)
        RecombinationSiteDict.Add("loxP", New Nuctions.RestrictionEnzyme("loxP", rec, idx + cut.Length, idx, "F"))


        'frt
        rec = Nuctions.TAGCFilter("gaag ttcc ta t actttctagaga a ta ggaa cttc")
        cut = Nuctions.TAGCFilter("actttctagaga")
        idx = rec.IndexOf(cut)
        RecombinationSiteDict.Add("frt", New Nuctions.RestrictionEnzyme("frt", rec, idx + cut.Length, idx, "F"))

        'lambda attB
        rec = Nuctions.TAGCFilter("TCAAGTTAGTATAAAAAAGCAGGCT")
        cut = Nuctions.TAGCFilter("TTAGTATAAAAAAGC")
        idx = rec.IndexOf(cut)
        RecombinationSiteDict.Add("LattB", New Nuctions.RestrictionEnzyme("LattB", rec, idx + cut.Length, idx, "B"))

        'lambda attP
        rec = Nuctions.TAGCFilter("CAAATAATGATTTTATTTTGACTGATAGTGACCTGTTCGTTGCAACAAATTGATAAGCAATGCTTTTTTATAATGCCAACTTAGTATAAAAAAGCTGAACGAGAAACGTAAAATGATATAAATATCAATATATTAAATTAGATTTTGCATAAAAAACAGACTACATAATACTGTAAAACACAACATATATGCAGTCACTATGAATCAACTACTTAGATGGTATTAGTGACCTGTA")
        cut = Nuctions.TAGCFilter("TTAGTATAAAAAAGC")
        idx = rec.IndexOf(cut)
        RecombinationSiteDict.Add("LattP", New Nuctions.RestrictionEnzyme("LattP", rec, idx + cut.Length, idx, "P"))

        'lambda attL
        rec = Nuctions.TAGCFilter("CAAATAATGATTTTATTTTGACTGATAGTGACCTGTTCGTTGCAACAAATTGATAAGCAATGCTTTTTTATAATGCCAACTTAGTATAAAAAAGCAGGCT")
        cut = Nuctions.TAGCFilter("TTAGTATAAAAAAGC")
        idx = rec.IndexOf(cut)
        RecombinationSiteDict.Add("LattL", New Nuctions.RestrictionEnzyme("LattL", rec, idx + cut.Length, idx, "L"))

        'lambda attR
        rec = Nuctions.TAGCFilter("TCAAGTTAGTATAAAAAAGCTGAACGAGAAACGTAAAATGATATAAATATCAATATATTAAATTAGATTTTGCATAAAAAACAGACTACATAATACTGTAAAACACAACATATATGCAGTCACTATGAATCAACTACTTAGATGGTATTAGTGACCTGTA")
        cut = Nuctions.TAGCFilter("TTAGTATAAAAAAGC")
        idx = rec.IndexOf(cut)
        RecombinationSiteDict.Add("LattR", New Nuctions.RestrictionEnzyme("LattR", rec, idx + cut.Length, idx, "R"))

        'lambda attB1
        rec = Nuctions.TAGCFilter("acaagtttgtacaaaaaagcaggct")
        cut = Nuctions.TAGCFilter("tttgtacaaaaaagc")
        idx = rec.IndexOf(cut)
        RecombinationSiteDict.Add("LattB1", New Nuctions.RestrictionEnzyme("LattB1", rec, idx + cut.Length, idx, "B"))

        'lambda attP1
        rec = Nuctions.TAGCFilter("caaataatgattttattttgactgatagtgacctgttcgttgcaacacattgatgagcaatgcttttttataatgccaactttgtacaaaaaagctgaacgagaaacgtaaaatgatataaatatcaatatattaaattagattttgcataaaaaacagactacataatactgtaaaacacaacatatccagtcactatgaatcaactacttagatggtattagtgacctgta")
        cut = Nuctions.TAGCFilter("tttgtacaaaaaagc")
        idx = rec.IndexOf(cut)
        RecombinationSiteDict.Add("LattP1", New Nuctions.RestrictionEnzyme("LattP1", rec, idx + cut.Length, idx, "P"))

        'lambda attL1
        rec = Nuctions.TAGCFilter("caaataatgattttattttgactgatagtgacctgttcgttgcaacaaattgataagcaatgcttttttataatgccaactttgtacaaaaaagcaggct")
        cut = Nuctions.TAGCFilter("tttgtacaaaaaagc")
        idx = rec.IndexOf(cut)
        RecombinationSiteDict.Add("LattL1", New Nuctions.RestrictionEnzyme("LattL1", rec, idx + cut.Length, idx, "L"))

        'lambda attR1
        rec = Nuctions.TAGCFilter("acaagtttgtacaaaaaagctgaacgagaaacgtaaaatgatataaatatcaatatattaaattagattttgcataaaaaacagactacataatactgtaaaacacaacatatccagtcactatg")
        cut = Nuctions.TAGCFilter("tttgtacaaaaaagc")
        idx = rec.IndexOf(cut)
        RecombinationSiteDict.Add("LattR1", New Nuctions.RestrictionEnzyme("LattR1", rec, idx + cut.Length, idx, "R"))

        'lambda attB2
        rec = Nuctions.TAGCFilter("accactttgtacaagaaagctgggt")
        cut = Nuctions.TAGCFilter("tttgtacaagaaagc")
        idx = rec.IndexOf(cut)
        RecombinationSiteDict.Add("LattB2", New Nuctions.RestrictionEnzyme("LattB2", rec, idx + cut.Length, idx, "B"))

        'lambda attP2
        rec = Nuctions.TAGCFilter("CAAATAATGATTTTATTTTGACTGATAGTGACCTGTTCGTTGCAACAAATTGATAAGCAATGCTTTCTTATAATGCCAACTTTGTACAAGAAAGCTGAACGAGAAACGTAAAATGATATAAATATCAATATATTAAATTAGATTTTGCATAAAAAACAGACTACATAATACTGTAAAACACAACATATCCAGTCACTATGAATCAACTACTTAGATGGTATTAGTGACCTGTA")
        cut = Nuctions.TAGCFilter("tttgtacaagaaagc")
        idx = rec.IndexOf(cut)
        RecombinationSiteDict.Add("LattP2", New Nuctions.RestrictionEnzyme("LattP2", rec, idx + cut.Length, idx, "P"))

        'lambda attL2
        rec = Nuctions.TAGCFilter("caaataatgattttattttgactgatagtgacctgttcgttgcaacaaattgataagcaatgctttcttataatgccaactttgtacaagaaagctgggt")
        cut = Nuctions.TAGCFilter("tttgtacaagaaagc")
        idx = rec.IndexOf(cut)
        RecombinationSiteDict.Add("LattL2", New Nuctions.RestrictionEnzyme("LattL2", rec, idx + cut.Length, idx, "L"))
        'lambda attR2
        rec = Nuctions.TAGCFilter("accactttgtacaagaaagctgaacgagaaacgtaaaatgatataaatatcaatatattaaattagattttgcataaaaaacagactacataatactgtaaaacacaacatatccagtcactatg")
        cut = Nuctions.TAGCFilter("tttgtacaagaaagc")
        idx = rec.IndexOf(cut)
        RecombinationSiteDict.Add("LattR2", New Nuctions.RestrictionEnzyme("LattR2", rec, idx + cut.Length, idx, "R"))

        'HK022 attB
        rec = Nuctions.TAGCFilter("ttaaattcacggtcggtgcactttaggtgaaaaaggttgagtcgcaaagcg")
        cut = Nuctions.TAGCFilter("ctttaggtgaa")
        idx = rec.IndexOf(cut)
        RecombinationSiteDict.Add("HattB", New Nuctions.RestrictionEnzyme("HattB", rec, idx + cut.Length, idx, "B"))
        'HK022 attP
        rec = Nuctions.TAGCFilter("tcaggtcactaatactatctaagtagttgattcatagtgactggatatgttgcgttttgtcgcattatgtagtctatcatttaaccacagattagtgtaatgcgatgatttttaagtgattaatgttattttgtcatcctttaggtgaataagttgtatatttaaaatctctttaattatcagtaaattaatgtaagtaggtcattattagtcaaaataaaatcatttgtc")
        cut = Nuctions.TAGCFilter("ctttaggtgaa")
        idx = rec.IndexOf(cut)
        RecombinationSiteDict.Add("HattP", New Nuctions.RestrictionEnzyme("HattP", rec, idx + cut.Length, idx, "P"))
        'HK022 attL
        rec = Nuctions.TAGCFilter("ttaaattcacggtcggtgcactttaggtgaataagttgtatatttaaaatctctttaattatcagtaaattaatgtaagtaggtcattattagtcaaaataaaatcatttgtcgatttcaattttgtc")
        cut = Nuctions.TAGCFilter("ctttaggtgaa")
        idx = rec.IndexOf(cut)
        RecombinationSiteDict.Add("HattL", New Nuctions.RestrictionEnzyme("HattL", rec, idx + cut.Length, idx, "L"))
        'HK022 attR
        rec = Nuctions.TAGCFilter("tcaggtcactaatactatctaagtagttgattcatagtgactggatatgttgcgttttgtcgcattatgtagtctatcatttaaccacagattagtgtaatgcgatgatttttaagtgattaatgttattttgtcatcctttaggtgaaaaaggttgagtcgcaaagcg")
        cut = Nuctions.TAGCFilter("ctttaggtgaa")
        idx = rec.IndexOf(cut)
        RecombinationSiteDict.Add("HattR", New Nuctions.RestrictionEnzyme("HattR", rec, idx + cut.Length, idx, "R"))

        'Phi80 attB
        rec = Nuctions.TAGCFilter("GAACACGTTTCAGTGAAACCATTTAAGAAAGTGTTCTGAATAGAGATTCAATATT")
        cut = Nuctions.TAGCFilter("ATTTAAGAAAGTGTT")
        idx = rec.IndexOf(cut)
        RecombinationSiteDict.Add("PattB", New Nuctions.RestrictionEnzyme("PattB", rec, idx + cut.Length, idx, "B"))

        'Phi80 attP
        rec = Nuctions.TAGCFilter("ACATTTTTGTTTTTGGGTACACAAAAGTGTACACAAAGTTGCCCACTCAAAGCTACACGCAATGTAACACTAGTTCGCAGAGTGTTATGGTTTACATCCTTGAAAGCCTGCTGGATAAGGGTTTAGCGTAACAGAACGTTTTTACGCGGAATTGTTCGTAATATGCCAAATGACAATTTAAGAAAGTGTTCTAATTTATTAGAAATTTGCACTTAAATCAAAAAGTTACGGACAATTCAACCACCAATCAATAAATTAAAGGGCACATTAAAGTACACAATATTTGTGCCCTTCTCTGTTTCTTTCCCGTTATCAGCTAGCTGGAAACTTTTTATACAGAGTTTAGAGCCCTACTCCATACGTTTTTGATACGCTTTGTCGTGATTCACC")
        cut = Nuctions.TAGCFilter("ATTTAAGAAAGTGTT")
        idx = rec.IndexOf(cut)
        RecombinationSiteDict.Add("PattP", New Nuctions.RestrictionEnzyme("PattP", rec, idx + cut.Length, idx, "P"))

        'Phi80 attL
        rec = Nuctions.TAGCFilter("GAACACGTTTCAGTGAAACCATTTAAGAAAGTGTTCTAATTTATTAGAAATTTGCACTTAAATCAAAAAGTTACGGACAATTCAACCACCAATCAATAAATTAAAGGGCACATTAAAGTACACAATATTTGTGCCCTTCTCTGTTTCTTTCCCGTTATCAGCTAGCTGGAAACTTTTTATACAGAGTTTAGAGCCCTACTCCATACGTTTTTGATACGCTTTGTCGTGATTCACC")
        cut = Nuctions.TAGCFilter("ATTTAAGAAAGTGTT")
        idx = rec.IndexOf(cut)
        RecombinationSiteDict.Add("PattL", New Nuctions.RestrictionEnzyme("PattL", rec, idx + cut.Length, idx, "L"))

        'Phi80 attR
        rec = Nuctions.TAGCFilter("ACATTTTTGTTTTTGGGTACACAAAAGTGTACACAAAGTTGCCCACTCAAAGCTACACGCAATGTAACACTAGTTCGCAGAGTGTTATGGTTTACATCCTTGAAAGCCTGCTGGATAAGGGTTTAGCGTAACAGAACGTTTTTACGCGGAATTGTTCGTAATATGCCAAATGACAATTTAAGAAAGTGTTCTGAATAGAGATTCAATATT")
        cut = Nuctions.TAGCFilter("ATTTAAGAAAGTGTT")
        idx = rec.IndexOf(cut)
        RecombinationSiteDict.Add("PattR", New Nuctions.RestrictionEnzyme("PattR", rec, idx + cut.Length, idx, "R"))

        'P21 attB

        'P21 attP

        'P21 attL

        'P21 attR

    End Sub

    Private Sub NewNToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NewNToolStripMenuItem.Click
        NewTab()
    End Sub

    Private Sub PCRToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PCRToolToolStripMenuItem.Click
        'PCR Kit
        Dim a As New frmPCR
        a.MdiParent = Me
        a.Show()

    End Sub

    Private Sub EnzymeSiteFinderToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles EnzymeSiteFinderToolStripMenuItem.Click
        Dim a As New frmNucleotideEnzyme
        a.MdiParent = Me
        a.Show()
    End Sub

    Private Sub EnzymeSpiderToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles EnzymeSpiderToolStripMenuItem.Click
        Dim a As New frm_EnzSpider

        a.Show()
    End Sub


    Private Sub tsb_TAGC_NF_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tsb_TAGC_NF.Click
        Dim seq As String = Clipboard.GetText
        seq = Nuctions.TAGCFilter(seq)
        Clipboard.SetText(seq)
    End Sub

    Private Sub tsb_TAGC_RC_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tsb_TAGC_RC.Click
        Dim seq As String = Clipboard.GetText
        seq = Nuctions.ReverseComplement(Nuctions.TAGCFilter(seq))
        Clipboard.SetText(seq)
    End Sub

    Private Sub tsb_TAGC_NR_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tsb_TAGC_NR.Click
        Dim seq As String = Clipboard.GetText
        seq = Nuctions.Reverse(Nuctions.TAGCFilter(seq))
        Clipboard.SetText(seq)
    End Sub

    Private Sub tsb_TAGC_FC_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tsb_TAGC_FC.Click
        Dim seq As String = Clipboard.GetText
        seq = Nuctions.Complement(Nuctions.TAGCFilter(seq))
        Clipboard.SetText(seq)
    End Sub

    Private Sub RestrictionEnzymesRToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RestrictionEnzymesRToolStripMenuItem.Click
        If ofdEnz.ShowDialog = Windows.Forms.DialogResult.OK Then
            enzFile = ofdEnz.FileName
            LoadEnzyme()
            SaveSettings()
        End If
    End Sub

    Private Sub TranslatingCodonsTToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TranslatingCodonsTToolStripMenuItem.Click
        If ofdCdn.ShowDialog = Windows.Forms.DialogResult.OK Then
            cdnFile = ofdCdn.FileName
            My.Settings.Context.Add("CodonFile", enzFile)
            CodonCol = Nuctions.LoadCodon(cdnFile)
            SaveSettings()
        End If
    End Sub

    Private Sub frmMain_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        If Not EmergencyExit Then
            'Save tabs
            For Each tp As TabPage In tcMainHost.TabPages
                If Not TryCloseTab(tp) Then e.Cancel = True : Exit Sub
            Next
            'Save setting files
            Dim enzs As New List(Of Nuctions.REBase)
            For Each enz As Nuctions.RestrictionEnzyme In EnzymeCol.RECollection
                enzs.Add(New Nuctions.REBase(enz))
            Next
            Dim XOS As New XmlObjectSerializer
            XOS.Diagnostic = True
            XOS.Add(enzs, "Enzymes")
            XOS.Add(StdFeatures, "Features")
            XOS.Add(CodonCol, "Codons")
            'DatabasePath = XOD.GetObjectByKey("DBPath")
            XOS.Add(DatabasePath, "DBPath")
            'XOS.Add(RecombinationSiteDict, "Recoms")
            XOS.SaveGZip(sFilename)
        End If
    End Sub

    Dim DatabasePath As String

    Public Function LoadDatabasePath() As Boolean

        If fbdDatabase.ShowDialog() = Windows.Forms.DialogResult.OK Then
            DatabasePath = fbdDatabase.SelectedPath
            Return True
        Else
            Return False
        End If
    End Function

    Public Sub RemoveDatabaseMenus()
        Dim tsi As ToolStripMenuItem
        For Each tsi In tssbDatabase.DropDownItems
            If tsi.DropDownItems.Count > 0 Then
                RemoveItems(tsi)
            Else
                RemoveHandler tsi.Click, AddressOf MenuLoadVector
            End If
        Next
        tssbDatabase.DropDownItems.Clear()
    End Sub
    Public Sub RemoveItems(ByVal tsmi As ToolStripMenuItem)
        Dim tsi As ToolStripMenuItem
        For Each tsi In tsmi.DropDownItems
            If tsi.DropDownItems.Count > 0 Then
                RemoveItems(tsi)
            Else
                RemoveHandler tsi.Click, AddressOf MenuLoadVector
            End If
        Next
    End Sub

    Public Sub LoadDatabase()
        Dim di As IO.DirectoryInfo
        di = New IO.DirectoryInfo(DatabasePath)

        Dim tsi As ToolStripMenuItem

        For Each fi As IO.FileInfo In di.GetFiles("*.gb")
            tsi = New ToolStripMenuItem(fi.Name)
            tsi.ToolTipText = fi.FullName
            AddHandler tsi.Click, AddressOf MenuLoadVector
            tssbDatabase.DropDownItems.Add(tsi)
        Next
        For Each sdi As IO.DirectoryInfo In di.GetDirectories()
            tsi = New ToolStripMenuItem(sdi.Name)
            tsi.ToolTipText = sdi.FullName
            tssbDatabase.DropDownItems.Add(tsi)
            AddDataItems(tsi, sdi)
        Next
    End Sub
    Public Sub AddDataItems(ByVal tsmi As ToolStripMenuItem, ByVal di As IO.DirectoryInfo)
        Dim tsi As ToolStripMenuItem
        For Each fi As IO.FileInfo In di.GetFiles("*.gb")
            tsi = New ToolStripMenuItem(fi.Name)
            tsi.ToolTipText = fi.FullName
            AddHandler tsi.Click, AddressOf MenuLoadVector
            tsmi.DropDownItems.Add(tsi)
        Next
        For Each sdi As IO.DirectoryInfo In di.GetDirectories()
            tsi = New ToolStripMenuItem(sdi.Name)
            tsi.ToolTipText = sdi.FullName
            tsmi.DropDownItems.Add(tsi)
            AddDataItems(tsi, di)
        Next
    End Sub

    Public Sub MenuLoadVector(ByVal sender As Object, ByVal e As EventArgs)
        If Not (SelectedWorkControl Is Nothing) Then
            If TypeOf sender Is ToolStripMenuItem Then
                Dim tsi As ToolStripMenuItem = sender
                If IO.File.Exists(tsi.ToolTipText) Then SelectedWorkControl.LoadVectorFromFile(tsi.ToolTipText)
            End If
        End If
    End Sub

    Private Sub frmMain_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        'Check the restriction enzymes settings and codon settings.
        If IO.File.Exists(sFilename) Then
            Dim XOD As New XmlObjectDeserializer
            Dim DVD As DeviceDictionary = XOD.LoadXml(XmlObjectDeserializer.GetXmlRootFromGZipFile(sFilename))
            XOD.Deserialize(DVD)
            CodonCol = XOD.GetObjectByKey("Codons")
            Dim enzs As New List(Of Nuctions.REBase)
            enzs = XOD.GetObjectByKey("Enzymes")
            EnzymeCol = New Nuctions.RestrictionEnzymes
            For Each eb As Nuctions.REBase In enzs
                EnzymeCol.AddRE(eb.Name, eb.GetRestrictionEnzyme)
            Next
            StdFeatures = XOD.GetObjectByKey("Features")
            DatabasePath = XOD.GetObjectByKey("DBPath")
            If DatabasePath Is Nothing Then
                While Not LoadDatabasePath()
                End While
            End If
            LoadDatabase()
            'RecombinationSiteDict = XOD.GetObjectByKey("Recoms")
            'temp
            '��ʱ����������������������λ��
            LoadRecombinationSites()
            NewTab()
        Else
            Dim lE As Boolean = True, lC As Boolean = True
            If lE Then
                If ofdEnz.ShowDialog = Windows.Forms.DialogResult.OK Then
                    enzFile = ofdEnz.FileName
                    LoadEnzyme()
                    SaveSettings()
                    lE = False
                End If
            End If
            If lC Then
                If ofdCdn.ShowDialog = Windows.Forms.DialogResult.OK Then
                    cdnFile = ofdCdn.FileName
                    CodonCol = Nuctions.LoadCodon(cdnFile)
                    SaveSettings()
                    lC = False
                End If
            End If
            If lE Or lC Then
                MsgBox("Program can not run without any of those definations! Exiting...")
                EmergencyExit = True
                Me.Close()
            Else
                NewTab()
            End If
        End If
    End Sub
    Private Sub SaveSettings()
        Dim SettingFile As New Xml.XmlDocument
        Dim sFilename As String = My.Application.Info.DirectoryPath + "\Vecute Settings.xml"
        Dim rootEml As Xml.XmlElement = SettingFile.CreateNode(Xml.XmlNodeType.Element, "ProgramSettings", "Stone's Vecute")
        rootEml.SetAttribute("EnzymeFile", enzFile)
        rootEml.SetAttribute("CodonFile", cdnFile)
        SettingFile.AppendChild(rootEml)
        SettingFile.Save(sFilename)
    End Sub
    Public ReadOnly Property CodonTraslation() As Nuctions.Translation
        Get
            Return Me.CodonCol
        End Get
    End Property
    Public ReadOnly Property EnzymeCollection()
        Get
            Return enzCollection
        End Get
    End Property
    Private Sub LoadEnzyme()
        EnzymeCol = Nuctions.LoadRestrictionEnzymes(enzFile)
        Dim e As Nuctions.RestrictionEnzyme
        For Each e In EnzymeCol.RECollection
            enzCollection.Add(e, e.Name)
        Next
    End Sub

    Private Sub SaveSToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SaveSToolStripMenuItem.Click
        SaveTab()
    End Sub

    Private Sub CloseCToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CloseCToolStripMenuItem.Click
        LoadTab()
    End Sub
    Public Sub OpenFile(ByVal vFileName As String)

    End Sub

    Private Sub SaveAsRToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SaveAsRToolStripMenuItem.Click
        Dim f As WorkControl = Me.SelectedWorkControl
        f.SaveAs()
    End Sub


    Private Sub SequenceMergerToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SequenceMergerToolStripMenuItem.Click
        Dim f As New pasteurMerger
        f.Owner = Me
        f.Show()
    End Sub

    Private Sub tsbTranslate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tsbTranslate.Click
        Dim seq As String = Clipboard.GetText
        seq = Nuctions.TAGCFilter(Nuctions.TAGCFilter(seq))
        Dim tsl As String = ""
        Dim i As Integer
        Dim t As Nuctions.Translation = Nuctions.LoadCodon(cdnFile)
        For i = 3 To seq.Length Step 3
            tsl += t.CodeTable(seq.Substring(i - 3, 3)).ShortName
        Next
        Clipboard.SetText(tsl)
    End Sub

    Private Sub SequenceViewerToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SequenceViewerToolStripMenuItem.Click
        Dim svw As New SequenceWindow
        Dim ofd As New OpenFileDialog
        ofd.Filter = "Genebank|*.gb"
        If ofd.ShowDialog = Windows.Forms.DialogResult.OK Then
            Dim gf As Nuctions.GeneFile = Nuctions.GeneFile.LoadFromGeneBankFile(ofd.FileName)
            Dim rec As New List(Of String)
            rec.Add("BamHI")
            rec.Add("SacI")
            rec.Add("EcoRI")
            rec.Add("HindIII")
            rec.Add("XhoI")
            rec.Add("SpeI")
            rec.Add("XbaI")
            rec.Add("SalI")
            svw.RestrictionSites = rec
            svw.GeneFile = gf
            svw.Show()
        End If
    End Sub

    Public Sub LoadVector()
        If SelectedWorkControl Is Nothing Then Exit Sub
        Dim wc As WorkControl = SelectedWorkControl
        If Not (wc Is Nothing) Then
            wc.LoadVector()
        End If
    End Sub
    Private Sub LoadVectorLToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LoadVectorLToolStripMenuItem.Click
        LoadVector()
    End Sub

    Public Property SelectedWorkControl() As WorkControl
        Get
            If tcMainHost.TabCount > 0 AndAlso tcMainHost.SelectedTab.Controls.Count > 0 AndAlso TypeOf tcMainHost.SelectedTab.Controls(0) Is WorkControl Then
                Return tcMainHost.SelectedTab.Controls(0)
            Else
                Return Nothing
            End If
        End Get
        Set(ByVal value As WorkControl)
            If tcMainHost.TabCount > 0 Then
                value.ParentTab.Select()
            End If
        End Set
    End Property

#Region "ˢ����ͼ"
    '�����ڸ��´����ʱ��ˢ����ͼ
    Private Sub ActivateDraw()

    End Sub

    Private Sub tcMainHost_DrawItem(ByVal sender As Object, ByVal e As System.Windows.Forms.DrawItemEventArgs) Handles tcMainHost.DrawItem

        If tcMainHost.TabPages.Count > e.Index Then
            Dim gp As New System.Drawing.Drawing2D.GraphicsPath
            Dim VO As New Vector2(e.Bounds.X, e.Bounds.Y)
            Dim VH As New Vector2(0, e.Bounds.Height)
            Dim VW As New Vector2(e.Bounds.Width, 0)

            e.DrawFocusRectangle()

            gp.AddCurve(New PointF() {VO + VH, VO + (VW.GetBase * VH.GetLength + VH) / 2, VO + VW.GetBase * VH.GetLength, VO + VW / 2, VO + VW, VO + VW + VH}, 0.5)
            gp.CloseFigure()
            Dim gb As New System.Drawing.Drawing2D.LinearGradientBrush(CType(VO, PointF), CType(VO + VH, PointF), Color.White, Color.OrangeRed)
            e.Graphics.InterpolationMode = Drawing2D.InterpolationMode.High
            e.Graphics.FillPath(gb, gp)
            e.Graphics.DrawPath(Pens.Red, gp)
            e.Graphics.DrawString(tcMainHost.TabPages(e.Index).Text, e.Font, Brushes.Black, e.Bounds.X + 6, e.Bounds.Y + 3)
        End If
    End Sub
    Private Sub tcMainHost_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tcMainHost.SelectedIndexChanged
        ActivateDraw()
    End Sub
    Private Sub frmMain_Activated(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Activated
        ActivateDraw()
    End Sub
#End Region

    Private CopiedGeneFiles As List(Of Nuctions.GeneFile)
    Public ReadOnly Property SelectedSequenceViewer() As SequenceViewer
        Get
            If tcMainHost.TabCount > 0 AndAlso tcMainHost.SelectedTab.Controls.Count > 0 AndAlso TypeOf tcMainHost.SelectedTab.Controls(0) Is SequenceViewer Then
                Return tcMainHost.SelectedTab.Controls(0)
            Else
                Return Nothing
            End If
        End Get
    End Property
    Private Sub frmMain_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Me.KeyDown

        Select Case e.KeyCode
            Case Keys.C
                If ModifierKeys = Keys.Control Then
                    If Not (SelectedWorkControl Is Nothing) Then

                        Dim str As String = Me.SelectedWorkControl.CopySelectedSequence()
                        If str.Length > 0 Then
                            Clipboard.SetText(str)
                        ElseIf Me.SelectedWorkControl.lv_Chart.Focused Then
                            '���Ը���ѡ�е�DNA
                            Dim gList As List(Of Nuctions.GeneFile) = SelectedWorkControl.TryCopyDNAs()
                            If gList.Count > 0 Then
                                Dim t As Type = GetType(List(Of Nuctions.GeneFile))
                                Clipboard.SetText(t.FullName)
                                CopiedGeneFiles = gList
                            End If
                        End If
                    ElseIf Not (SelectedSequenceViewer Is Nothing) Then
                        Dim str As String = Me.SelectedSequenceViewer.CopySelectedSequence()
                        If str.Length > 0 Then
                            Clipboard.SetText(str)
                        End If
                    End If

                End If
            Case Keys.Delete
                If SelectedWorkControl Is Nothing Then Exit Sub
                If ModifierKeys = Keys.Shift Then
                    Me.SelectedWorkControl.DeleteItem()
                End If
            Case Keys.V
                If SelectedWorkControl Is Nothing Then Exit Sub
                If ModifierKeys = Keys.Control Then
                    Dim files As String() = Clipboard.GetData(DataFormats.FileDrop)
                    If files Is Nothing Then
                        Dim obj As String = Clipboard.GetText

                        Dim t As Type = GetType(List(Of Nuctions.GeneFile))

                        If obj = t.FullName Then
                            SelectedWorkControl.TryPasteDNAs(CopiedGeneFiles)
                        End If

                    Else
                        For Each s As String In files
                            Dim fi As New IO.FileInfo(s)
                            If fi.Exists Then
                                Select Case fi.Extension.ToLower
                                    Case ".stone"
                                        LoadTabFromFile(fi.FullName)
                                    Case ".gb"
                                        SelectedWorkControl.LoadVectorFromFile(fi.FullName)
                                    Case ".txt"
                                        SelectedWorkControl.LoadSequenceFromFile(fi.FullName)
                                    Case ".seq"
                                        SelectedWorkControl.LoadSequenceFromFile(fi.FullName)
                                End Select
                            End If
                        Next
                    End If
                End If
            Case Keys.Enter
                If SelectedWorkControl Is Nothing Then Exit Sub
                If SelectedWorkControl.SourceMode Then
                    SelectedWorkControl.AcceptMode()
                End If
            Case Keys.Escape
                If SelectedWorkControl Is Nothing Then Exit Sub
                If SelectedWorkControl.SourceMode Then
                    SelectedWorkControl.ExitMode()
                End If
            Case Keys.F1
                If SelectedWorkControl Is Nothing Then Exit Sub
                SelectedWorkControl.SwitchSplitter()
        End Select
    End Sub

    Public Sub AddDNAViewTab(ByVal gf As Nuctions.GeneFile, ByVal ez As List(Of String))
        Dim tp As New CustomTabPage
        Dim sv As New SequenceViewer
        tcMainHost.TabPages.Add(tp)
        tp.Controls.Add(sv)
        tp.Text = gf.Name
        sv.Dock = DockStyle.Fill
        sv.RestrictionSites = ez
        sv.GeneFile = gf
        sv.ClearMode()
        tp.Select()
    End Sub



    Private Sub tsbRecalculate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tsbRecalculate.Click
        If SelectedWorkControl Is Nothing Then Exit Sub
        SelectedWorkControl.RecalculateAllChildren()
    End Sub

    Private Sub tsbNew_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tsbNew.Click
        NewTab()
    End Sub

    Private Sub tsbOpen_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tsbOpen.Click
        LoadTab()
    End Sub
    Public Sub SaveTab()
        If Not (SelectedWorkControl Is Nothing) Then
            Me.SelectedWorkControl.Save()
        ElseIf Not (SelectedSequenceViewer Is Nothing) Then
            sfdGene.InitialDirectory = DatabasePath
            If Not (SelectedSequenceViewer.GeneFile.Name Is Nothing) Then sfdGene.FileName = SelectedSequenceViewer.GeneFile.Name

            If sfdGene.ShowDialog = Windows.Forms.DialogResult.OK Then
                SelectedSequenceViewer.GeneFile.WriteToFile(sfdGene.FileName)
                Dim fi As New IO.FileInfo(sfdGene.FileName)
                SelectedSequenceViewer.GeneFile.WriteIndexFile(fi.FullName.Substring(0, fi.FullName.LastIndexOf(".")) + ".idx")
                If fi.FullName.IndexOf(DatabasePath) > -1 Then
                    RemoveDatabaseMenus()
                    LoadDatabase()
                End If
            End If
        End If
    End Sub
    Private Sub tsbSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tsbSave.Click
        SaveTab()
    End Sub

    Private Sub tsbVector_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tsbVector.Click
        If (Not SelectedWorkControl Is Nothing) Then
            SelectedWorkControl.LoadVector()
        End If
    End Sub

    Private Sub tsbOperation_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tsbEnzyme.Click, tsbPCR.Click, tsbModify.Click, tsbGel.Click, tsbLigate.Click, tsbRecombine.Click, _
    tsbRestrictionAnalysis.Click, tsbScreen.Click, tsbMerge.Click, tsbCompare.Click
        Dim obj As ToolStripButton = sender
        AddOperation(obj.Tag)
    End Sub
    Public Sub AddOperation(ByVal Method As Nuctions.MolecularOperationEnum)
        If SelectedWorkControl Is Nothing Then Exit Sub
        SelectedWorkControl.AddNewOperation(Method, True)
    End Sub

    Private Sub tsbCopy_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tsbCopy.Click
        If SelectedWorkControl Is Nothing Then Exit Sub
        SelectedWorkControl.OnGroupCopy()
    End Sub

    Private Sub tsbPaste_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tsbPaste.Click
        If SelectedWorkControl Is Nothing Then Exit Sub
        SelectedWorkControl.GroupPaste()
    End Sub

    Private Sub CopyGroupToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CopyGroupToolStripMenuItem.Click
        If SelectedWorkControl Is Nothing Then Exit Sub
        SelectedWorkControl.OnGroupCopy()
    End Sub

    Private Sub PasteGroupToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PasteGroupToolStripMenuItem.Click
        If SelectedWorkControl Is Nothing Then Exit Sub
        SelectedWorkControl.GroupPaste()
    End Sub

    Private Sub FunctionToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles EnzymeDigestionFToolStripMenuItem.Click, PCRToolStripMenuItem.Click, ModificationMToolStripMenuItem.Click, _
    GelElectrophoresisGToolStripMenuItem.Click, LigationToolStripMenuItem.Click, ScreenToolStripMenuItem.Click, RecombinationToolStripMenuItem.Click, RestrictionAnalysisToolStripMenuItem.Click, _
    MergeToolStripMenuItem.Click, SequenceComparisonToolStripMenuItem.Click

        Dim obj As ToolStripMenuItem = sender
        AddOperation(obj.Tag)
    End Sub

    Private Sub tsbDelete_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tsbDelete.Click
        If SelectedWorkControl Is Nothing Then Exit Sub
        SelectedWorkControl.DeleteItem()
    End Sub

    Private Sub tsbCut_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tsbCut.Click
        If SelectedWorkControl Is Nothing Then Exit Sub
        SelectedWorkControl.OnGroupCopy()
        SelectedWorkControl.DeleteItem(False)
        SelectedWorkControl.UpdateView()
    End Sub

    Private Sub tsbSearch_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tsbSearch.Click
        If Not (SelectedSequenceViewer Is Nothing) Then
            SelectedSequenceViewer.SearchSequence(tstbSearch.Text)
        End If
    End Sub

    Private Sub tsbDatabaseSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tsbDatabaseSave.Click
        If Not (SelectedWorkControl Is Nothing) Then
            If SelectedWorkControl.lv_Chart.SelectedItems.Count > 0 AndAlso SelectedWorkControl.lv_Chart.SelectedItems(0).MolecularInfo.DNAs.Count = 1 Then
                Dim gf As Nuctions.GeneFile = SelectedWorkControl.lv_Chart.SelectedItems(0).MolecularInfo.DNAs(1)
                sfdGene.InitialDirectory = DatabasePath
                If Not (gf.Name Is Nothing) Then sfdGene.FileName = gf.Name

                If sfdGene.ShowDialog = Windows.Forms.DialogResult.OK Then
                    gf.WriteToFile(sfdGene.FileName)
                    Dim fi As New IO.FileInfo(sfdGene.FileName)
                    gf.WriteIndexFile(fi.FullName.Substring(0, fi.FullName.LastIndexOf(".")) + ".idx")
                    If fi.FullName.IndexOf(DatabasePath) > -1 Then
                        RemoveDatabaseMenus()
                        LoadDatabase()
                    End If
                End If
            End If
        End If
    End Sub

    Private Sub tsbRemoveFeature_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tsbRemoveFeature.Click
        If Not (SelectedSequenceViewer Is Nothing) Then
            SelectedSequenceViewer.RemoveFeature()
        End If
    End Sub

    Private Sub tsbAddFeature_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tsbAddFeature.Click
        If Not (SelectedSequenceViewer Is Nothing) Then
            SelectedSequenceViewer.AddFeature()
        End If
    End Sub

    Private Sub tsbManageFeature_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tsbManageFeature.Click
        If Not (SelectedSequenceViewer Is Nothing) Then
            SelectedSequenceViewer.ManageFeature()
        End If
    End Sub

 
End Class
