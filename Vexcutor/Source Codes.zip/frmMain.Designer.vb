<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmMain
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmMain))
        Me.mainMenu = New System.Windows.Forms.MenuStrip
        Me.FileFToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.NewNToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.SaveSToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.CloseCToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.SaveAsRToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ExperimentToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.LoadVectorLToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.EnzymeDigestionFToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.PCRToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ModificationMToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.GelElectrophoresisGToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.LigationToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ScreenToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.RecombinationToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.RestrictionAnalysisToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.SequenceComparisonToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.MergeToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.SequenceComparisonToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolStripSeparator2 = New System.Windows.Forms.ToolStripSeparator
        Me.ExperimentLogLToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolStripSeparator3 = New System.Windows.Forms.ToolStripSeparator
        Me.CopyGroupToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.PasteGroupToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.DeleteItemDToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.FunctionsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.PCRToolToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.EnzymeSiteFinderToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.EnzymeSpiderToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.SequenceMergerToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.SequenceViewerToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.SettingsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.RestrictionEnzymesRToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.TranslatingCodonsTToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.tsFunctions = New System.Windows.Forms.ToolStrip
        Me.tsbNew = New System.Windows.Forms.ToolStripButton
        Me.tsbOpen = New System.Windows.Forms.ToolStripButton
        Me.tsbSave = New System.Windows.Forms.ToolStripButton
        Me.ToolStripSeparator1 = New System.Windows.Forms.ToolStripSeparator
        Me.tsbVector = New System.Windows.Forms.ToolStripButton
        Me.tsbEnzyme = New System.Windows.Forms.ToolStripButton
        Me.tsbPCR = New System.Windows.Forms.ToolStripButton
        Me.tsbModify = New System.Windows.Forms.ToolStripButton
        Me.tsbGel = New System.Windows.Forms.ToolStripButton
        Me.tsbLigate = New System.Windows.Forms.ToolStripButton
        Me.tsbScreen = New System.Windows.Forms.ToolStripButton
        Me.tsbRecombine = New System.Windows.Forms.ToolStripButton
        Me.tsbRestrictionAnalysis = New System.Windows.Forms.ToolStripButton
        Me.tsbMerge = New System.Windows.Forms.ToolStripButton
        Me.tsbCompare = New System.Windows.Forms.ToolStripButton
        Me.ToolStripSeparator5 = New System.Windows.Forms.ToolStripSeparator
        Me.tsbRecalculate = New System.Windows.Forms.ToolStripButton
        Me.ToolStripSeparator6 = New System.Windows.Forms.ToolStripSeparator
        Me.tsbCut = New System.Windows.Forms.ToolStripButton
        Me.tsbCopy = New System.Windows.Forms.ToolStripButton
        Me.tsbPaste = New System.Windows.Forms.ToolStripButton
        Me.tsbDelete = New System.Windows.Forms.ToolStripButton
        Me.tstbSearch = New System.Windows.Forms.ToolStripTextBox
        Me.tsbSearch = New System.Windows.Forms.ToolStripButton
        Me.ToolStripSeparator7 = New System.Windows.Forms.ToolStripSeparator
        Me.tsb_TAGC_NF = New System.Windows.Forms.ToolStripButton
        Me.tsb_TAGC_RC = New System.Windows.Forms.ToolStripButton
        Me.tsb_TAGC_NR = New System.Windows.Forms.ToolStripButton
        Me.tsb_TAGC_FC = New System.Windows.Forms.ToolStripButton
        Me.ToolStripSeparator4 = New System.Windows.Forms.ToolStripSeparator
        Me.tsbTranslate = New System.Windows.Forms.ToolStripButton
        Me.ToolStripSeparator8 = New System.Windows.Forms.ToolStripSeparator
        Me.tssbDatabase = New System.Windows.Forms.ToolStripSplitButton
        Me.tsbDatabaseSave = New System.Windows.Forms.ToolStripButton
        Me.tsbManageFeature = New System.Windows.Forms.ToolStripButton
        Me.tsbAddFeature = New System.Windows.Forms.ToolStripButton
        Me.tsbRemoveFeature = New System.Windows.Forms.ToolStripButton
        Me.ofdEnz = New System.Windows.Forms.OpenFileDialog
        Me.ofdCdn = New System.Windows.Forms.OpenFileDialog
        Me.sfdProject = New System.Windows.Forms.SaveFileDialog
        Me.ofdProject = New System.Windows.Forms.OpenFileDialog
        Me.IconList = New System.Windows.Forms.ImageList(Me.components)
        Me.SmallIconList = New System.Windows.Forms.ImageList(Me.components)
        Me.sfdGene = New System.Windows.Forms.SaveFileDialog
        Me.fbdDatabase = New System.Windows.Forms.FolderBrowserDialog
        Me.tcMainHost = New Vecute.TabContainer
        Me.mainMenu.SuspendLayout()
        Me.tsFunctions.SuspendLayout()
        Me.SuspendLayout()
        '
        'mainMenu
        '
        Me.mainMenu.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FileFToolStripMenuItem, Me.ExperimentToolStripMenuItem, Me.FunctionsToolStripMenuItem, Me.SettingsToolStripMenuItem})
        Me.mainMenu.Location = New System.Drawing.Point(0, 0)
        Me.mainMenu.Name = "mainMenu"
        Me.mainMenu.Size = New System.Drawing.Size(1224, 24)
        Me.mainMenu.TabIndex = 1
        Me.mainMenu.Text = "MenuStrip1"
        '
        'FileFToolStripMenuItem
        '
        Me.FileFToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.NewNToolStripMenuItem, Me.SaveSToolStripMenuItem, Me.CloseCToolStripMenuItem, Me.SaveAsRToolStripMenuItem})
        Me.FileFToolStripMenuItem.Name = "FileFToolStripMenuItem"
        Me.FileFToolStripMenuItem.Size = New System.Drawing.Size(59, 20)
        Me.FileFToolStripMenuItem.Text = "File(&F)"
        '
        'NewNToolStripMenuItem
        '
        Me.NewNToolStripMenuItem.Name = "NewNToolStripMenuItem"
        Me.NewNToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.N), System.Windows.Forms.Keys)
        Me.NewNToolStripMenuItem.Size = New System.Drawing.Size(207, 22)
        Me.NewNToolStripMenuItem.Text = "New(&N)"
        '
        'SaveSToolStripMenuItem
        '
        Me.SaveSToolStripMenuItem.Name = "SaveSToolStripMenuItem"
        Me.SaveSToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.S), System.Windows.Forms.Keys)
        Me.SaveSToolStripMenuItem.Size = New System.Drawing.Size(207, 22)
        Me.SaveSToolStripMenuItem.Text = "Save(&S)"
        '
        'CloseCToolStripMenuItem
        '
        Me.CloseCToolStripMenuItem.Name = "CloseCToolStripMenuItem"
        Me.CloseCToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.O), System.Windows.Forms.Keys)
        Me.CloseCToolStripMenuItem.Size = New System.Drawing.Size(207, 22)
        Me.CloseCToolStripMenuItem.Text = "Open(&O)"
        '
        'SaveAsRToolStripMenuItem
        '
        Me.SaveAsRToolStripMenuItem.Name = "SaveAsRToolStripMenuItem"
        Me.SaveAsRToolStripMenuItem.ShortcutKeys = CType(((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.Shift) _
                    Or System.Windows.Forms.Keys.S), System.Windows.Forms.Keys)
        Me.SaveAsRToolStripMenuItem.Size = New System.Drawing.Size(207, 22)
        Me.SaveAsRToolStripMenuItem.Text = "Save As(&R)"
        '
        'ExperimentToolStripMenuItem
        '
        Me.ExperimentToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.LoadVectorLToolStripMenuItem, Me.EnzymeDigestionFToolStripMenuItem, Me.PCRToolStripMenuItem, Me.ModificationMToolStripMenuItem, Me.GelElectrophoresisGToolStripMenuItem, Me.LigationToolStripMenuItem, Me.ScreenToolStripMenuItem, Me.RecombinationToolStripMenuItem, Me.RestrictionAnalysisToolStripMenuItem, Me.SequenceComparisonToolStripMenuItem, Me.MergeToolStripMenuItem, Me.SequenceComparisonToolStripMenuItem1, Me.ToolStripSeparator2, Me.ExperimentLogLToolStripMenuItem, Me.ToolStripSeparator3, Me.CopyGroupToolStripMenuItem, Me.PasteGroupToolStripMenuItem, Me.DeleteItemDToolStripMenuItem})
        Me.ExperimentToolStripMenuItem.Name = "ExperimentToolStripMenuItem"
        Me.ExperimentToolStripMenuItem.Size = New System.Drawing.Size(95, 20)
        Me.ExperimentToolStripMenuItem.Text = "Experiment(&E)"
        '
        'LoadVectorLToolStripMenuItem
        '
        Me.LoadVectorLToolStripMenuItem.Image = CType(resources.GetObject("LoadVectorLToolStripMenuItem.Image"), System.Drawing.Image)
        Me.LoadVectorLToolStripMenuItem.Name = "LoadVectorLToolStripMenuItem"
        Me.LoadVectorLToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.L), System.Windows.Forms.Keys)
        Me.LoadVectorLToolStripMenuItem.Size = New System.Drawing.Size(249, 22)
        Me.LoadVectorLToolStripMenuItem.Text = "Load Sequence(&L)"
        '
        'EnzymeDigestionFToolStripMenuItem
        '
        Me.EnzymeDigestionFToolStripMenuItem.Image = CType(resources.GetObject("EnzymeDigestionFToolStripMenuItem.Image"), System.Drawing.Image)
        Me.EnzymeDigestionFToolStripMenuItem.Name = "EnzymeDigestionFToolStripMenuItem"
        Me.EnzymeDigestionFToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.E), System.Windows.Forms.Keys)
        Me.EnzymeDigestionFToolStripMenuItem.Size = New System.Drawing.Size(249, 22)
        Me.EnzymeDigestionFToolStripMenuItem.Tag = "1"
        Me.EnzymeDigestionFToolStripMenuItem.Text = "Enzyme Digestion(&E)"
        '
        'PCRToolStripMenuItem
        '
        Me.PCRToolStripMenuItem.Image = CType(resources.GetObject("PCRToolStripMenuItem.Image"), System.Drawing.Image)
        Me.PCRToolStripMenuItem.Name = "PCRToolStripMenuItem"
        Me.PCRToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.R), System.Windows.Forms.Keys)
        Me.PCRToolStripMenuItem.Size = New System.Drawing.Size(249, 22)
        Me.PCRToolStripMenuItem.Tag = "2"
        Me.PCRToolStripMenuItem.Text = "PCR(&R)"
        '
        'ModificationMToolStripMenuItem
        '
        Me.ModificationMToolStripMenuItem.Image = Global.Vecute.My.Resources.Resources.Modify
        Me.ModificationMToolStripMenuItem.Name = "ModificationMToolStripMenuItem"
        Me.ModificationMToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.Q), System.Windows.Forms.Keys)
        Me.ModificationMToolStripMenuItem.Size = New System.Drawing.Size(249, 22)
        Me.ModificationMToolStripMenuItem.Tag = "3"
        Me.ModificationMToolStripMenuItem.Text = "Modification(&M)"
        '
        'GelElectrophoresisGToolStripMenuItem
        '
        Me.GelElectrophoresisGToolStripMenuItem.Image = Global.Vecute.My.Resources.Resources.Gel
        Me.GelElectrophoresisGToolStripMenuItem.Name = "GelElectrophoresisGToolStripMenuItem"
        Me.GelElectrophoresisGToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.G), System.Windows.Forms.Keys)
        Me.GelElectrophoresisGToolStripMenuItem.Size = New System.Drawing.Size(249, 22)
        Me.GelElectrophoresisGToolStripMenuItem.Tag = "4"
        Me.GelElectrophoresisGToolStripMenuItem.Text = "Gel Electrophoresis(&G)"
        '
        'LigationToolStripMenuItem
        '
        Me.LigationToolStripMenuItem.Image = Global.Vecute.My.Resources.Resources.Ligation
        Me.LigationToolStripMenuItem.Name = "LigationToolStripMenuItem"
        Me.LigationToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.W), System.Windows.Forms.Keys)
        Me.LigationToolStripMenuItem.Size = New System.Drawing.Size(249, 22)
        Me.LigationToolStripMenuItem.Tag = "5"
        Me.LigationToolStripMenuItem.Text = "Ligation(&W)"
        '
        'ScreenToolStripMenuItem
        '
        Me.ScreenToolStripMenuItem.Image = Global.Vecute.My.Resources.Resources.Screen2
        Me.ScreenToolStripMenuItem.Name = "ScreenToolStripMenuItem"
        Me.ScreenToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.T), System.Windows.Forms.Keys)
        Me.ScreenToolStripMenuItem.Size = New System.Drawing.Size(249, 22)
        Me.ScreenToolStripMenuItem.Tag = "6"
        Me.ScreenToolStripMenuItem.Text = "Screen(&T)"
        '
        'RecombinationToolStripMenuItem
        '
        Me.RecombinationToolStripMenuItem.Image = Global.Vecute.My.Resources.Resources.rec
        Me.RecombinationToolStripMenuItem.Name = "RecombinationToolStripMenuItem"
        Me.RecombinationToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.D), System.Windows.Forms.Keys)
        Me.RecombinationToolStripMenuItem.Size = New System.Drawing.Size(249, 22)
        Me.RecombinationToolStripMenuItem.Tag = "7"
        Me.RecombinationToolStripMenuItem.Text = "Recombination(&V)"
        '
        'RestrictionAnalysisToolStripMenuItem
        '
        Me.RestrictionAnalysisToolStripMenuItem.Image = Global.Vecute.My.Resources.Resources.REAna
        Me.RestrictionAnalysisToolStripMenuItem.Name = "RestrictionAnalysisToolStripMenuItem"
        Me.RestrictionAnalysisToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.H), System.Windows.Forms.Keys)
        Me.RestrictionAnalysisToolStripMenuItem.Size = New System.Drawing.Size(249, 22)
        Me.RestrictionAnalysisToolStripMenuItem.Tag = "8"
        Me.RestrictionAnalysisToolStripMenuItem.Text = "Restriction Analysis(&H)"
        '
        'SequenceComparisonToolStripMenuItem
        '
        Me.SequenceComparisonToolStripMenuItem.Image = Global.Vecute.My.Resources.Resources.SAN
        Me.SequenceComparisonToolStripMenuItem.Name = "SequenceComparisonToolStripMenuItem"
        Me.SequenceComparisonToolStripMenuItem.Size = New System.Drawing.Size(249, 22)
        Me.SequenceComparisonToolStripMenuItem.Text = "Sequence Comparison"
        '
        'MergeToolStripMenuItem
        '
        Me.MergeToolStripMenuItem.Image = Global.Vecute.My.Resources.Resources.SEQ
        Me.MergeToolStripMenuItem.Name = "MergeToolStripMenuItem"
        Me.MergeToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.B), System.Windows.Forms.Keys)
        Me.MergeToolStripMenuItem.Size = New System.Drawing.Size(249, 22)
        Me.MergeToolStripMenuItem.Tag = "9"
        Me.MergeToolStripMenuItem.Text = "Merge(&B)"
        '
        'SequenceComparisonToolStripMenuItem1
        '
        Me.SequenceComparisonToolStripMenuItem1.Image = Global.Vecute.My.Resources.Resources.SAN
        Me.SequenceComparisonToolStripMenuItem1.Name = "SequenceComparisonToolStripMenuItem1"
        Me.SequenceComparisonToolStripMenuItem1.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.U), System.Windows.Forms.Keys)
        Me.SequenceComparisonToolStripMenuItem1.Size = New System.Drawing.Size(249, 22)
        Me.SequenceComparisonToolStripMenuItem1.Text = "Sequence Comparison(&U)"
        '
        'ToolStripSeparator2
        '
        Me.ToolStripSeparator2.Name = "ToolStripSeparator2"
        Me.ToolStripSeparator2.Size = New System.Drawing.Size(246, 6)
        '
        'ExperimentLogLToolStripMenuItem
        '
        Me.ExperimentLogLToolStripMenuItem.Name = "ExperimentLogLToolStripMenuItem"
        Me.ExperimentLogLToolStripMenuItem.ShortcutKeys = System.Windows.Forms.Keys.F4
        Me.ExperimentLogLToolStripMenuItem.Size = New System.Drawing.Size(249, 22)
        Me.ExperimentLogLToolStripMenuItem.Text = "Export...(&R)"
        '
        'ToolStripSeparator3
        '
        Me.ToolStripSeparator3.Name = "ToolStripSeparator3"
        Me.ToolStripSeparator3.Size = New System.Drawing.Size(246, 6)
        '
        'CopyGroupToolStripMenuItem
        '
        Me.CopyGroupToolStripMenuItem.Image = CType(resources.GetObject("CopyGroupToolStripMenuItem.Image"), System.Drawing.Image)
        Me.CopyGroupToolStripMenuItem.Name = "CopyGroupToolStripMenuItem"
        Me.CopyGroupToolStripMenuItem.Size = New System.Drawing.Size(249, 22)
        Me.CopyGroupToolStripMenuItem.Text = "Copy Group(&C)"
        '
        'PasteGroupToolStripMenuItem
        '
        Me.PasteGroupToolStripMenuItem.Image = CType(resources.GetObject("PasteGroupToolStripMenuItem.Image"), System.Drawing.Image)
        Me.PasteGroupToolStripMenuItem.Name = "PasteGroupToolStripMenuItem"
        Me.PasteGroupToolStripMenuItem.Size = New System.Drawing.Size(249, 22)
        Me.PasteGroupToolStripMenuItem.Text = "Paste Group(&P)"
        '
        'DeleteItemDToolStripMenuItem
        '
        Me.DeleteItemDToolStripMenuItem.Image = CType(resources.GetObject("DeleteItemDToolStripMenuItem.Image"), System.Drawing.Image)
        Me.DeleteItemDToolStripMenuItem.Name = "DeleteItemDToolStripMenuItem"
        Me.DeleteItemDToolStripMenuItem.ShortcutKeys = System.Windows.Forms.Keys.Delete
        Me.DeleteItemDToolStripMenuItem.Size = New System.Drawing.Size(249, 22)
        Me.DeleteItemDToolStripMenuItem.Text = "Delete Item(&D)"
        '
        'FunctionsToolStripMenuItem
        '
        Me.FunctionsToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.PCRToolToolStripMenuItem, Me.EnzymeSiteFinderToolStripMenuItem, Me.EnzymeSpiderToolStripMenuItem, Me.SequenceMergerToolStripMenuItem, Me.SequenceViewerToolStripMenuItem})
        Me.FunctionsToolStripMenuItem.Name = "FunctionsToolStripMenuItem"
        Me.FunctionsToolStripMenuItem.Size = New System.Drawing.Size(83, 20)
        Me.FunctionsToolStripMenuItem.Text = "Programs(&P)"
        '
        'PCRToolToolStripMenuItem
        '
        Me.PCRToolToolStripMenuItem.Name = "PCRToolToolStripMenuItem"
        Me.PCRToolToolStripMenuItem.Size = New System.Drawing.Size(166, 22)
        Me.PCRToolToolStripMenuItem.Text = "PCR"
        '
        'EnzymeSiteFinderToolStripMenuItem
        '
        Me.EnzymeSiteFinderToolStripMenuItem.Name = "EnzymeSiteFinderToolStripMenuItem"
        Me.EnzymeSiteFinderToolStripMenuItem.Size = New System.Drawing.Size(166, 22)
        Me.EnzymeSiteFinderToolStripMenuItem.Text = "EnzymeSiteFinder"
        '
        'EnzymeSpiderToolStripMenuItem
        '
        Me.EnzymeSpiderToolStripMenuItem.Name = "EnzymeSpiderToolStripMenuItem"
        Me.EnzymeSpiderToolStripMenuItem.Size = New System.Drawing.Size(166, 22)
        Me.EnzymeSpiderToolStripMenuItem.Text = "EnzymeSpider"
        '
        'SequenceMergerToolStripMenuItem
        '
        Me.SequenceMergerToolStripMenuItem.Name = "SequenceMergerToolStripMenuItem"
        Me.SequenceMergerToolStripMenuItem.Size = New System.Drawing.Size(166, 22)
        Me.SequenceMergerToolStripMenuItem.Text = "SequenceMerger"
        '
        'SequenceViewerToolStripMenuItem
        '
        Me.SequenceViewerToolStripMenuItem.Name = "SequenceViewerToolStripMenuItem"
        Me.SequenceViewerToolStripMenuItem.Size = New System.Drawing.Size(166, 22)
        Me.SequenceViewerToolStripMenuItem.Text = "SequenceViewer"
        '
        'SettingsToolStripMenuItem
        '
        Me.SettingsToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.RestrictionEnzymesRToolStripMenuItem, Me.TranslatingCodonsTToolStripMenuItem})
        Me.SettingsToolStripMenuItem.Name = "SettingsToolStripMenuItem"
        Me.SettingsToolStripMenuItem.Size = New System.Drawing.Size(83, 20)
        Me.SettingsToolStripMenuItem.Text = "Settings(&S)"
        '
        'RestrictionEnzymesRToolStripMenuItem
        '
        Me.RestrictionEnzymesRToolStripMenuItem.Name = "RestrictionEnzymesRToolStripMenuItem"
        Me.RestrictionEnzymesRToolStripMenuItem.Size = New System.Drawing.Size(202, 22)
        Me.RestrictionEnzymesRToolStripMenuItem.Text = "Restriction Enzymes(&R)"
        '
        'TranslatingCodonsTToolStripMenuItem
        '
        Me.TranslatingCodonsTToolStripMenuItem.Name = "TranslatingCodonsTToolStripMenuItem"
        Me.TranslatingCodonsTToolStripMenuItem.Size = New System.Drawing.Size(202, 22)
        Me.TranslatingCodonsTToolStripMenuItem.Text = "Translating Codons(&T)"
        '
        'tsFunctions
        '
        Me.tsFunctions.GripMargin = New System.Windows.Forms.Padding(0)
        Me.tsFunctions.ImageScalingSize = New System.Drawing.Size(30, 30)
        Me.tsFunctions.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.tsbNew, Me.tsbOpen, Me.tsbSave, Me.ToolStripSeparator1, Me.tsbVector, Me.tsbEnzyme, Me.tsbPCR, Me.tsbModify, Me.tsbGel, Me.tsbLigate, Me.tsbScreen, Me.tsbRecombine, Me.tsbRestrictionAnalysis, Me.tsbMerge, Me.tsbCompare, Me.ToolStripSeparator5, Me.tsbRecalculate, Me.ToolStripSeparator6, Me.tsbCut, Me.tsbCopy, Me.tsbPaste, Me.tsbDelete, Me.tstbSearch, Me.tsbSearch, Me.ToolStripSeparator7, Me.tsb_TAGC_NF, Me.tsb_TAGC_RC, Me.tsb_TAGC_NR, Me.tsb_TAGC_FC, Me.ToolStripSeparator4, Me.tsbTranslate, Me.ToolStripSeparator8, Me.tssbDatabase, Me.tsbDatabaseSave, Me.tsbManageFeature, Me.tsbAddFeature, Me.tsbRemoveFeature})
        Me.tsFunctions.Location = New System.Drawing.Point(0, 24)
        Me.tsFunctions.Name = "tsFunctions"
        Me.tsFunctions.Size = New System.Drawing.Size(1224, 37)
        Me.tsFunctions.TabIndex = 3
        Me.tsFunctions.Text = "ToolStrip1"
        '
        'tsbNew
        '
        Me.tsbNew.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.tsbNew.Image = CType(resources.GetObject("tsbNew.Image"), System.Drawing.Image)
        Me.tsbNew.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.tsbNew.Name = "tsbNew"
        Me.tsbNew.Size = New System.Drawing.Size(34, 34)
        Me.tsbNew.Text = "New Experiment"
        '
        'tsbOpen
        '
        Me.tsbOpen.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.tsbOpen.Image = CType(resources.GetObject("tsbOpen.Image"), System.Drawing.Image)
        Me.tsbOpen.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.tsbOpen.Name = "tsbOpen"
        Me.tsbOpen.Size = New System.Drawing.Size(34, 34)
        Me.tsbOpen.Text = "Load Experiment"
        '
        'tsbSave
        '
        Me.tsbSave.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.tsbSave.Image = CType(resources.GetObject("tsbSave.Image"), System.Drawing.Image)
        Me.tsbSave.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.tsbSave.Name = "tsbSave"
        Me.tsbSave.Size = New System.Drawing.Size(34, 34)
        Me.tsbSave.Text = "Save Experiment"
        '
        'ToolStripSeparator1
        '
        Me.ToolStripSeparator1.Name = "ToolStripSeparator1"
        Me.ToolStripSeparator1.Size = New System.Drawing.Size(6, 37)
        '
        'tsbVector
        '
        Me.tsbVector.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.tsbVector.Image = CType(resources.GetObject("tsbVector.Image"), System.Drawing.Image)
        Me.tsbVector.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.tsbVector.Name = "tsbVector"
        Me.tsbVector.Size = New System.Drawing.Size(34, 34)
        Me.tsbVector.Text = "Load Vector"
        '
        'tsbEnzyme
        '
        Me.tsbEnzyme.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.tsbEnzyme.Image = CType(resources.GetObject("tsbEnzyme.Image"), System.Drawing.Image)
        Me.tsbEnzyme.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.tsbEnzyme.Name = "tsbEnzyme"
        Me.tsbEnzyme.Size = New System.Drawing.Size(34, 34)
        Me.tsbEnzyme.Tag = "1"
        Me.tsbEnzyme.Text = "Enzyme Digestion"
        '
        'tsbPCR
        '
        Me.tsbPCR.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.tsbPCR.Image = CType(resources.GetObject("tsbPCR.Image"), System.Drawing.Image)
        Me.tsbPCR.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.tsbPCR.Name = "tsbPCR"
        Me.tsbPCR.Size = New System.Drawing.Size(34, 34)
        Me.tsbPCR.Tag = "2"
        Me.tsbPCR.Text = "PCR"
        '
        'tsbModify
        '
        Me.tsbModify.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.tsbModify.Image = CType(resources.GetObject("tsbModify.Image"), System.Drawing.Image)
        Me.tsbModify.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.tsbModify.Name = "tsbModify"
        Me.tsbModify.Size = New System.Drawing.Size(34, 34)
        Me.tsbModify.Tag = "3"
        Me.tsbModify.Text = "Modification"
        '
        'tsbGel
        '
        Me.tsbGel.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.tsbGel.Image = CType(resources.GetObject("tsbGel.Image"), System.Drawing.Image)
        Me.tsbGel.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.tsbGel.Name = "tsbGel"
        Me.tsbGel.Size = New System.Drawing.Size(34, 34)
        Me.tsbGel.Tag = "4"
        Me.tsbGel.Text = "Gel Electrophoresis"
        '
        'tsbLigate
        '
        Me.tsbLigate.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.tsbLigate.Image = CType(resources.GetObject("tsbLigate.Image"), System.Drawing.Image)
        Me.tsbLigate.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.tsbLigate.Name = "tsbLigate"
        Me.tsbLigate.Size = New System.Drawing.Size(34, 34)
        Me.tsbLigate.Tag = "5"
        Me.tsbLigate.Text = "Ligation"
        '
        'tsbScreen
        '
        Me.tsbScreen.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.tsbScreen.Image = CType(resources.GetObject("tsbScreen.Image"), System.Drawing.Image)
        Me.tsbScreen.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.tsbScreen.Name = "tsbScreen"
        Me.tsbScreen.Size = New System.Drawing.Size(34, 34)
        Me.tsbScreen.Tag = "6"
        Me.tsbScreen.Text = "Screen"
        '
        'tsbRecombine
        '
        Me.tsbRecombine.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.tsbRecombine.Image = CType(resources.GetObject("tsbRecombine.Image"), System.Drawing.Image)
        Me.tsbRecombine.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.tsbRecombine.Name = "tsbRecombine"
        Me.tsbRecombine.Size = New System.Drawing.Size(34, 34)
        Me.tsbRecombine.Tag = "7"
        Me.tsbRecombine.Text = "Recombination"
        '
        'tsbRestrictionAnalysis
        '
        Me.tsbRestrictionAnalysis.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.tsbRestrictionAnalysis.Image = CType(resources.GetObject("tsbRestrictionAnalysis.Image"), System.Drawing.Image)
        Me.tsbRestrictionAnalysis.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.tsbRestrictionAnalysis.Name = "tsbRestrictionAnalysis"
        Me.tsbRestrictionAnalysis.Size = New System.Drawing.Size(34, 34)
        Me.tsbRestrictionAnalysis.Tag = "8"
        Me.tsbRestrictionAnalysis.Text = "Restriction Analysis"
        '
        'tsbMerge
        '
        Me.tsbMerge.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.tsbMerge.Image = CType(resources.GetObject("tsbMerge.Image"), System.Drawing.Image)
        Me.tsbMerge.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.tsbMerge.Name = "tsbMerge"
        Me.tsbMerge.Size = New System.Drawing.Size(34, 34)
        Me.tsbMerge.Tag = "9"
        Me.tsbMerge.Text = "Merge"
        '
        'tsbCompare
        '
        Me.tsbCompare.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.tsbCompare.Image = CType(resources.GetObject("tsbCompare.Image"), System.Drawing.Image)
        Me.tsbCompare.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.tsbCompare.Name = "tsbCompare"
        Me.tsbCompare.Size = New System.Drawing.Size(34, 34)
        Me.tsbCompare.Tag = "10"
        Me.tsbCompare.Text = "Compare"
        '
        'ToolStripSeparator5
        '
        Me.ToolStripSeparator5.Name = "ToolStripSeparator5"
        Me.ToolStripSeparator5.Size = New System.Drawing.Size(6, 37)
        '
        'tsbRecalculate
        '
        Me.tsbRecalculate.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.tsbRecalculate.Image = CType(resources.GetObject("tsbRecalculate.Image"), System.Drawing.Image)
        Me.tsbRecalculate.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.tsbRecalculate.Name = "tsbRecalculate"
        Me.tsbRecalculate.Size = New System.Drawing.Size(34, 34)
        Me.tsbRecalculate.Tag = ""
        Me.tsbRecalculate.Text = "ToolStripButton12"
        '
        'ToolStripSeparator6
        '
        Me.ToolStripSeparator6.Name = "ToolStripSeparator6"
        Me.ToolStripSeparator6.Size = New System.Drawing.Size(6, 37)
        '
        'tsbCut
        '
        Me.tsbCut.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.tsbCut.Image = CType(resources.GetObject("tsbCut.Image"), System.Drawing.Image)
        Me.tsbCut.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.tsbCut.Name = "tsbCut"
        Me.tsbCut.Size = New System.Drawing.Size(34, 34)
        Me.tsbCut.Text = "Cut Group"
        '
        'tsbCopy
        '
        Me.tsbCopy.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.tsbCopy.Image = CType(resources.GetObject("tsbCopy.Image"), System.Drawing.Image)
        Me.tsbCopy.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.tsbCopy.Name = "tsbCopy"
        Me.tsbCopy.Size = New System.Drawing.Size(34, 34)
        Me.tsbCopy.Text = "Copy Group"
        '
        'tsbPaste
        '
        Me.tsbPaste.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.tsbPaste.Image = CType(resources.GetObject("tsbPaste.Image"), System.Drawing.Image)
        Me.tsbPaste.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.tsbPaste.Name = "tsbPaste"
        Me.tsbPaste.Size = New System.Drawing.Size(34, 34)
        Me.tsbPaste.Text = "Paste Group"
        '
        'tsbDelete
        '
        Me.tsbDelete.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.tsbDelete.Image = CType(resources.GetObject("tsbDelete.Image"), System.Drawing.Image)
        Me.tsbDelete.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.tsbDelete.Name = "tsbDelete"
        Me.tsbDelete.Size = New System.Drawing.Size(34, 34)
        Me.tsbDelete.Text = "Delete"
        '
        'tstbSearch
        '
        Me.tstbSearch.Name = "tstbSearch"
        Me.tstbSearch.Size = New System.Drawing.Size(100, 37)
        '
        'tsbSearch
        '
        Me.tsbSearch.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.tsbSearch.Image = CType(resources.GetObject("tsbSearch.Image"), System.Drawing.Image)
        Me.tsbSearch.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.tsbSearch.Name = "tsbSearch"
        Me.tsbSearch.Size = New System.Drawing.Size(34, 34)
        Me.tsbSearch.Text = "Search"
        '
        'ToolStripSeparator7
        '
        Me.ToolStripSeparator7.Name = "ToolStripSeparator7"
        Me.ToolStripSeparator7.Size = New System.Drawing.Size(6, 37)
        '
        'tsb_TAGC_NF
        '
        Me.tsb_TAGC_NF.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.tsb_TAGC_NF.Image = CType(resources.GetObject("tsb_TAGC_NF.Image"), System.Drawing.Image)
        Me.tsb_TAGC_NF.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.tsb_TAGC_NF.Name = "tsb_TAGC_NF"
        Me.tsb_TAGC_NF.Size = New System.Drawing.Size(34, 34)
        Me.tsb_TAGC_NF.Text = "Normal"
        '
        'tsb_TAGC_RC
        '
        Me.tsb_TAGC_RC.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.tsb_TAGC_RC.Image = CType(resources.GetObject("tsb_TAGC_RC.Image"), System.Drawing.Image)
        Me.tsb_TAGC_RC.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.tsb_TAGC_RC.Name = "tsb_TAGC_RC"
        Me.tsb_TAGC_RC.Size = New System.Drawing.Size(34, 34)
        Me.tsb_TAGC_RC.Text = "ReverseComplented"
        '
        'tsb_TAGC_NR
        '
        Me.tsb_TAGC_NR.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.tsb_TAGC_NR.Image = CType(resources.GetObject("tsb_TAGC_NR.Image"), System.Drawing.Image)
        Me.tsb_TAGC_NR.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.tsb_TAGC_NR.Name = "tsb_TAGC_NR"
        Me.tsb_TAGC_NR.Size = New System.Drawing.Size(34, 34)
        Me.tsb_TAGC_NR.Text = "Reverse"
        '
        'tsb_TAGC_FC
        '
        Me.tsb_TAGC_FC.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.tsb_TAGC_FC.Image = CType(resources.GetObject("tsb_TAGC_FC.Image"), System.Drawing.Image)
        Me.tsb_TAGC_FC.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.tsb_TAGC_FC.Name = "tsb_TAGC_FC"
        Me.tsb_TAGC_FC.Size = New System.Drawing.Size(34, 34)
        Me.tsb_TAGC_FC.Text = "Complemented"
        '
        'ToolStripSeparator4
        '
        Me.ToolStripSeparator4.Name = "ToolStripSeparator4"
        Me.ToolStripSeparator4.Size = New System.Drawing.Size(6, 37)
        '
        'tsbTranslate
        '
        Me.tsbTranslate.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.tsbTranslate.Image = CType(resources.GetObject("tsbTranslate.Image"), System.Drawing.Image)
        Me.tsbTranslate.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.tsbTranslate.Name = "tsbTranslate"
        Me.tsbTranslate.Size = New System.Drawing.Size(34, 34)
        Me.tsbTranslate.Text = "Translate"
        '
        'ToolStripSeparator8
        '
        Me.ToolStripSeparator8.Name = "ToolStripSeparator8"
        Me.ToolStripSeparator8.Size = New System.Drawing.Size(6, 37)
        '
        'tssbDatabase
        '
        Me.tssbDatabase.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.tssbDatabase.Image = CType(resources.GetObject("tssbDatabase.Image"), System.Drawing.Image)
        Me.tssbDatabase.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.tssbDatabase.Name = "tssbDatabase"
        Me.tssbDatabase.Size = New System.Drawing.Size(46, 34)
        Me.tssbDatabase.Text = "Vector Database"
        '
        'tsbDatabaseSave
        '
        Me.tsbDatabaseSave.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.tsbDatabaseSave.Image = CType(resources.GetObject("tsbDatabaseSave.Image"), System.Drawing.Image)
        Me.tsbDatabaseSave.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.tsbDatabaseSave.Name = "tsbDatabaseSave"
        Me.tsbDatabaseSave.Size = New System.Drawing.Size(34, 34)
        Me.tsbDatabaseSave.Text = "Save To Database"
        '
        'tsbManageFeature
        '
        Me.tsbManageFeature.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.tsbManageFeature.Image = CType(resources.GetObject("tsbManageFeature.Image"), System.Drawing.Image)
        Me.tsbManageFeature.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.tsbManageFeature.Name = "tsbManageFeature"
        Me.tsbManageFeature.Size = New System.Drawing.Size(34, 34)
        Me.tsbManageFeature.Text = "Manage Feature"
        '
        'tsbAddFeature
        '
        Me.tsbAddFeature.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.tsbAddFeature.Image = CType(resources.GetObject("tsbAddFeature.Image"), System.Drawing.Image)
        Me.tsbAddFeature.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.tsbAddFeature.Name = "tsbAddFeature"
        Me.tsbAddFeature.Size = New System.Drawing.Size(34, 34)
        Me.tsbAddFeature.Text = "Add Feature"
        '
        'tsbRemoveFeature
        '
        Me.tsbRemoveFeature.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.tsbRemoveFeature.Image = CType(resources.GetObject("tsbRemoveFeature.Image"), System.Drawing.Image)
        Me.tsbRemoveFeature.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.tsbRemoveFeature.Name = "tsbRemoveFeature"
        Me.tsbRemoveFeature.Size = New System.Drawing.Size(34, 34)
        Me.tsbRemoveFeature.Text = "Remove Feature"
        '
        'ofdEnz
        '
        Me.ofdEnz.Filter = "Text File|*.txt"
        Me.ofdEnz.Title = "Open Enzyme Define File"
        '
        'ofdCdn
        '
        Me.ofdCdn.Filter = "Text File|*.txt"
        Me.ofdCdn.Title = "Open Codon Define File"
        '
        'sfdProject
        '
        Me.sfdProject.Filter = "Vecute Files|*.stone"
        '
        'ofdProject
        '
        Me.ofdProject.Filter = "Vecute Files|*.stone"
        '
        'IconList
        '
        Me.IconList.ImageStream = CType(resources.GetObject("IconList.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.IconList.TransparentColor = System.Drawing.Color.Transparent
        Me.IconList.Images.SetKeyName(0, "DNA")
        Me.IconList.Images.SetKeyName(1, "ENZ")
        Me.IconList.Images.SetKeyName(2, "PCR")
        Me.IconList.Images.SetKeyName(3, "MOD")
        Me.IconList.Images.SetKeyName(4, "GEL")
        Me.IconList.Images.SetKeyName(5, "LIG")
        Me.IconList.Images.SetKeyName(6, "TSF")
        Me.IconList.Images.SetKeyName(7, "REC")
        Me.IconList.Images.SetKeyName(8, "ANA")
        Me.IconList.Images.SetKeyName(9, "SEQ")
        Me.IconList.Images.SetKeyName(10, "SAN")
        '
        'SmallIconList
        '
        Me.SmallIconList.ImageStream = CType(resources.GetObject("SmallIconList.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.SmallIconList.TransparentColor = System.Drawing.Color.Transparent
        Me.SmallIconList.Images.SetKeyName(0, "DNA")
        Me.SmallIconList.Images.SetKeyName(1, "ENZ")
        Me.SmallIconList.Images.SetKeyName(2, "PCR")
        Me.SmallIconList.Images.SetKeyName(3, "MOD")
        Me.SmallIconList.Images.SetKeyName(4, "GEL")
        Me.SmallIconList.Images.SetKeyName(5, "LIG")
        Me.SmallIconList.Images.SetKeyName(6, "TSF")
        Me.SmallIconList.Images.SetKeyName(7, "REC")
        Me.SmallIconList.Images.SetKeyName(8, "ANA")
        Me.SmallIconList.Images.SetKeyName(9, "SEQ")
        Me.SmallIconList.Images.SetKeyName(10, "SAN")
        '
        'sfdGene
        '
        Me.sfdGene.Filter = "GeneBankFile|*.gb"
        '
        'fbdDatabase
        '
        Me.fbdDatabase.Description = "Choose Database Path"
        '
        'tcMainHost
        '
        Me.tcMainHost.Dock = System.Windows.Forms.DockStyle.Fill
        Me.tcMainHost.HotTrack = True
        Me.tcMainHost.Location = New System.Drawing.Point(0, 61)
        Me.tcMainHost.Margin = New System.Windows.Forms.Padding(0)
        Me.tcMainHost.Name = "tcMainHost"
        Me.tcMainHost.SelectedIndex = 0
        Me.tcMainHost.Size = New System.Drawing.Size(1224, 533)
        Me.tcMainHost.TabIndex = 4
        '
        'frmMain
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 14.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(1224, 594)
        Me.Controls.Add(Me.tcMainHost)
        Me.Controls.Add(Me.tsFunctions)
        Me.Controls.Add(Me.mainMenu)
        Me.Font = New System.Drawing.Font("Calibri", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.KeyPreview = True
        Me.MainMenuStrip = Me.mainMenu
        Me.Name = "frmMain"
        Me.Text = "Vecute Projects"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.mainMenu.ResumeLayout(False)
        Me.mainMenu.PerformLayout()
        Me.tsFunctions.ResumeLayout(False)
        Me.tsFunctions.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents mainMenu As System.Windows.Forms.MenuStrip
    Friend WithEvents FileFToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents NewNToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents FunctionsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PCRToolToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents EnzymeSiteFinderToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents EnzymeSpiderToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents tsFunctions As System.Windows.Forms.ToolStrip
    Friend WithEvents tsb_TAGC_NF As System.Windows.Forms.ToolStripButton
    Friend WithEvents tsb_TAGC_RC As System.Windows.Forms.ToolStripButton
    Friend WithEvents tsb_TAGC_NR As System.Windows.Forms.ToolStripButton
    Friend WithEvents tsb_TAGC_FC As System.Windows.Forms.ToolStripButton
    Friend WithEvents SettingsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents RestrictionEnzymesRToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TranslatingCodonsTToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ofdEnz As System.Windows.Forms.OpenFileDialog
    Friend WithEvents ofdCdn As System.Windows.Forms.OpenFileDialog
    Friend WithEvents SaveSToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CloseCToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents sfdProject As System.Windows.Forms.SaveFileDialog
    Friend WithEvents ofdProject As System.Windows.Forms.OpenFileDialog
    Friend WithEvents SaveAsRToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SequenceMergerToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator1 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents tsbTranslate As System.Windows.Forms.ToolStripButton
    Friend WithEvents SequenceViewerToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents tcMainHost As TabContainer
    Friend WithEvents ExperimentToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents LoadVectorLToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents EnzymeDigestionFToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DeleteItemDToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator2 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ToolStripSeparator3 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ExperimentLogLToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents IconList As System.Windows.Forms.ImageList
    Friend WithEvents SmallIconList As System.Windows.Forms.ImageList
    Friend WithEvents CopyGroupToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PasteGroupToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator4 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents tsbEnzyme As System.Windows.Forms.ToolStripButton
    Friend WithEvents tsbPCR As System.Windows.Forms.ToolStripButton
    Friend WithEvents tsbModify As System.Windows.Forms.ToolStripButton
    Friend WithEvents tsbGel As System.Windows.Forms.ToolStripButton
    Friend WithEvents tsbLigate As System.Windows.Forms.ToolStripButton
    Friend WithEvents tsbScreen As System.Windows.Forms.ToolStripButton
    Friend WithEvents tsbRecombine As System.Windows.Forms.ToolStripButton
    Friend WithEvents tsbVector As System.Windows.Forms.ToolStripButton
    Friend WithEvents tsbRestrictionAnalysis As System.Windows.Forms.ToolStripButton
    Friend WithEvents tsbMerge As System.Windows.Forms.ToolStripButton
    Friend WithEvents tsbCompare As System.Windows.Forms.ToolStripButton
    Friend WithEvents tsbRecalculate As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripSeparator5 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ToolStripSeparator6 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents tsbCopy As System.Windows.Forms.ToolStripButton
    Friend WithEvents tsbPaste As System.Windows.Forms.ToolStripButton
    Friend WithEvents tsbCut As System.Windows.Forms.ToolStripButton
    Friend WithEvents tsbDelete As System.Windows.Forms.ToolStripButton
    Friend WithEvents tsbSave As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripSeparator7 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents tsbNew As System.Windows.Forms.ToolStripButton
    Friend WithEvents tsbSearch As System.Windows.Forms.ToolStripButton
    Friend WithEvents tsbOpen As System.Windows.Forms.ToolStripButton
    Friend WithEvents PCRToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ModificationMToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents GelElectrophoresisGToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents LigationToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ScreenToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents RecombinationToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents RestrictionAnalysisToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents MergeToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SequenceComparisonToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SequenceComparisonToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents tstbSearch As System.Windows.Forms.ToolStripTextBox
    Friend WithEvents ToolStripSeparator8 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents tssbDatabase As System.Windows.Forms.ToolStripSplitButton
    Friend WithEvents tsbDatabaseSave As System.Windows.Forms.ToolStripButton
    Friend WithEvents tsbManageFeature As System.Windows.Forms.ToolStripButton
    Friend WithEvents tsbRemoveFeature As System.Windows.Forms.ToolStripButton
    Friend WithEvents tsbAddFeature As System.Windows.Forms.ToolStripButton
    Friend WithEvents sfdGene As System.Windows.Forms.SaveFileDialog
    Friend WithEvents fbdDatabase As System.Windows.Forms.FolderBrowserDialog

End Class
