﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class PropertyView
    Inherits System.Windows.Forms.UserControl

    'UserControl 重写 Dispose，以清理组件列表。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows 窗体设计器所必需的
    Private components As System.ComponentModel.IContainer

    '注意: 以下过程是 Windows 窗体设计器所必需的
    '可以使用 Windows 窗体设计器修改它。
    '不要使用代码编辑器修改它。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.tcMain = New Vecute.TabContainer
        Me.TabPage1 = New Vecute.CustomTabPage
        Me.rtbSummary = New System.Windows.Forms.RichTextBox
        Me.lbEnzymes = New System.Windows.Forms.Label
        Me.llLoadSequencingResultFile = New System.Windows.Forms.LinkLabel
        Me.llLoadSequenceFile = New System.Windows.Forms.LinkLabel
        Me.llLoadSequencingResult = New System.Windows.Forms.LinkLabel
        Me.llClose = New System.Windows.Forms.LinkLabel
        Me.llExportProject = New System.Windows.Forms.LinkLabel
        Me.llManageEnzymes = New System.Windows.Forms.LinkLabel
        Me.llRemarkFeature = New System.Windows.Forms.LinkLabel
        Me.llManageFeatures = New System.Windows.Forms.LinkLabel
        Me.llLoadSequence = New System.Windows.Forms.LinkLabel
        Me.llSaveExperimentAs = New System.Windows.Forms.LinkLabel
        Me.llSaveExperiment = New System.Windows.Forms.LinkLabel
        Me.llLoadExperiment = New System.Windows.Forms.LinkLabel
        Me.llLoadGeneFile = New System.Windows.Forms.LinkLabel
        Me.rtbSequence = New System.Windows.Forms.RichTextBox
        Me.TabPage2 = New Vecute.CustomTabPage
        Me.PrpC = New Vecute.PropertyControl
        Me.TabPage3 = New Vecute.CustomTabPage
        Me.MIV = New Vecute.MultipleItemView
        Me.TabPage4 = New Vecute.CustomTabPage
        Me.reView = New Vecute.RestrictionEnzymeView
        Me.TabPage5 = New Vecute.CustomTabPage
        Me.gvDNA = New Vecute.GroupViewer
        Me.TabPage6 = New Vecute.CustomTabPage
        Me.gvPCR = New Vecute.GroupViewer
        Me.TabPage7 = New Vecute.CustomTabPage
        Me.FMV = New Vecute.FeatureManageView
        Me.TabPage8 = New Vecute.CustomTabPage
        Me.FSV = New Vecute.FeatureScreenView
        Me.tcMain.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        Me.TabPage2.SuspendLayout()
        Me.TabPage3.SuspendLayout()
        Me.TabPage4.SuspendLayout()
        Me.TabPage5.SuspendLayout()
        Me.TabPage6.SuspendLayout()
        Me.TabPage7.SuspendLayout()
        Me.TabPage8.SuspendLayout()
        Me.SuspendLayout()
        '
        'tcMain
        '
        Me.tcMain.Controls.Add(Me.TabPage1)
        Me.tcMain.Controls.Add(Me.TabPage2)
        Me.tcMain.Controls.Add(Me.TabPage3)
        Me.tcMain.Controls.Add(Me.TabPage4)
        Me.tcMain.Controls.Add(Me.TabPage5)
        Me.tcMain.Controls.Add(Me.TabPage6)
        Me.tcMain.Controls.Add(Me.TabPage7)
        Me.tcMain.Controls.Add(Me.TabPage8)
        Me.tcMain.Dock = System.Windows.Forms.DockStyle.Fill
        Me.tcMain.Location = New System.Drawing.Point(0, 0)
        Me.tcMain.Name = "tcMain"
        Me.tcMain.SelectedIndex = 0
        Me.tcMain.Size = New System.Drawing.Size(1036, 408)
        Me.tcMain.TabIndex = 0
        '
        'TabPage1
        '
        Me.TabPage1.Controls.Add(Me.rtbSummary)
        Me.TabPage1.Controls.Add(Me.lbEnzymes)
        Me.TabPage1.Controls.Add(Me.llLoadSequencingResultFile)
        Me.TabPage1.Controls.Add(Me.llLoadSequenceFile)
        Me.TabPage1.Controls.Add(Me.llLoadSequencingResult)
        Me.TabPage1.Controls.Add(Me.llClose)
        Me.TabPage1.Controls.Add(Me.llExportProject)
        Me.TabPage1.Controls.Add(Me.llManageEnzymes)
        Me.TabPage1.Controls.Add(Me.llRemarkFeature)
        Me.TabPage1.Controls.Add(Me.llManageFeatures)
        Me.TabPage1.Controls.Add(Me.llLoadSequence)
        Me.TabPage1.Controls.Add(Me.llSaveExperimentAs)
        Me.TabPage1.Controls.Add(Me.llSaveExperiment)
        Me.TabPage1.Controls.Add(Me.llLoadExperiment)
        Me.TabPage1.Controls.Add(Me.llLoadGeneFile)
        Me.TabPage1.Controls.Add(Me.rtbSequence)
        Me.TabPage1.Location = New System.Drawing.Point(4, 25)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(1028, 379)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "Project Property"
        Me.TabPage1.UseVisualStyleBackColor = True
        '
        'rtbSummary
        '
        Me.rtbSummary.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.rtbSummary.Location = New System.Drawing.Point(5, 83)
        Me.rtbSummary.Name = "rtbSummary"
        Me.rtbSummary.Size = New System.Drawing.Size(1016, 48)
        Me.rtbSummary.TabIndex = 4
        Me.rtbSummary.Text = ""
        '
        'lbEnzymes
        '
        Me.lbEnzymes.AutoSize = True
        Me.lbEnzymes.Font = New System.Drawing.Font("Calibri", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbEnzymes.Location = New System.Drawing.Point(118, 63)
        Me.lbEnzymes.Name = "lbEnzymes"
        Me.lbEnzymes.Size = New System.Drawing.Size(66, 17)
        Me.lbEnzymes.TabIndex = 3
        Me.lbEnzymes.Text = "<Enzyme>"
        '
        'llLoadSequencingResultFile
        '
        Me.llLoadSequencingResultFile.AutoSize = True
        Me.llLoadSequencingResultFile.Font = New System.Drawing.Font("Calibri", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.llLoadSequencingResultFile.LinkColor = System.Drawing.Color.IndianRed
        Me.llLoadSequencingResultFile.Location = New System.Drawing.Point(221, 29)
        Me.llLoadSequencingResultFile.Name = "llLoadSequencingResultFile"
        Me.llLoadSequencingResultFile.Size = New System.Drawing.Size(162, 17)
        Me.llLoadSequencingResultFile.TabIndex = 2
        Me.llLoadSequencingResultFile.TabStop = True
        Me.llLoadSequencingResultFile.Text = "Load Sequencing Result File"
        '
        'llLoadSequenceFile
        '
        Me.llLoadSequenceFile.AutoSize = True
        Me.llLoadSequenceFile.Font = New System.Drawing.Font("Calibri", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.llLoadSequenceFile.LinkColor = System.Drawing.Color.IndianRed
        Me.llLoadSequenceFile.Location = New System.Drawing.Point(101, 29)
        Me.llLoadSequenceFile.Name = "llLoadSequenceFile"
        Me.llLoadSequenceFile.Size = New System.Drawing.Size(114, 17)
        Me.llLoadSequenceFile.TabIndex = 2
        Me.llLoadSequenceFile.TabStop = True
        Me.llLoadSequenceFile.Text = "Load Sequence File"
        '
        'llLoadSequencingResult
        '
        Me.llLoadSequencingResult.AutoSize = True
        Me.llLoadSequencingResult.Font = New System.Drawing.Font("Calibri", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.llLoadSequencingResult.LinkColor = System.Drawing.Color.DarkOrange
        Me.llLoadSequencingResult.Location = New System.Drawing.Point(104, 134)
        Me.llLoadSequencingResult.Name = "llLoadSequencingResult"
        Me.llLoadSequencingResult.Size = New System.Drawing.Size(140, 17)
        Me.llLoadSequencingResult.TabIndex = 2
        Me.llLoadSequencingResult.TabStop = True
        Me.llLoadSequencingResult.Text = "Load Sequencing Result"
        '
        'llClose
        '
        Me.llClose.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.llClose.AutoSize = True
        Me.llClose.Font = New System.Drawing.Font("Calibri", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.llClose.LinkColor = System.Drawing.Color.Red
        Me.llClose.Location = New System.Drawing.Point(984, 3)
        Me.llClose.Name = "llClose"
        Me.llClose.Size = New System.Drawing.Size(37, 17)
        Me.llClose.TabIndex = 2
        Me.llClose.TabStop = True
        Me.llClose.Text = "Close"
        '
        'llExportProject
        '
        Me.llExportProject.AutoSize = True
        Me.llExportProject.Font = New System.Drawing.Font("Calibri", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.llExportProject.LinkColor = System.Drawing.Color.DarkGoldenrod
        Me.llExportProject.Location = New System.Drawing.Point(347, 3)
        Me.llExportProject.Name = "llExportProject"
        Me.llExportProject.Size = New System.Drawing.Size(88, 17)
        Me.llExportProject.TabIndex = 2
        Me.llExportProject.TabStop = True
        Me.llExportProject.Text = "Export Project"
        '
        'llManageEnzymes
        '
        Me.llManageEnzymes.AutoSize = True
        Me.llManageEnzymes.Font = New System.Drawing.Font("Calibri", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.llManageEnzymes.LinkColor = System.Drawing.Color.MediumTurquoise
        Me.llManageEnzymes.Location = New System.Drawing.Point(5, 63)
        Me.llManageEnzymes.Name = "llManageEnzymes"
        Me.llManageEnzymes.Size = New System.Drawing.Size(107, 17)
        Me.llManageEnzymes.TabIndex = 2
        Me.llManageEnzymes.TabStop = True
        Me.llManageEnzymes.Text = "Manage Enzymes"
        '
        'llRemarkFeature
        '
        Me.llRemarkFeature.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.llRemarkFeature.AutoSize = True
        Me.llRemarkFeature.Font = New System.Drawing.Font("Calibri", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.llRemarkFeature.LinkColor = System.Drawing.Color.DodgerBlue
        Me.llRemarkFeature.Location = New System.Drawing.Point(917, 46)
        Me.llRemarkFeature.Name = "llRemarkFeature"
        Me.llRemarkFeature.Size = New System.Drawing.Size(104, 17)
        Me.llRemarkFeature.TabIndex = 2
        Me.llRemarkFeature.TabStop = True
        Me.llRemarkFeature.Text = "Remark Features"
        '
        'llManageFeatures
        '
        Me.llManageFeatures.AutoSize = True
        Me.llManageFeatures.Font = New System.Drawing.Font("Calibri", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.llManageFeatures.LinkColor = System.Drawing.Color.MediumTurquoise
        Me.llManageFeatures.Location = New System.Drawing.Point(5, 46)
        Me.llManageFeatures.Name = "llManageFeatures"
        Me.llManageFeatures.Size = New System.Drawing.Size(107, 17)
        Me.llManageFeatures.TabIndex = 2
        Me.llManageFeatures.TabStop = True
        Me.llManageFeatures.Text = "Manage Features"
        '
        'llLoadSequence
        '
        Me.llLoadSequence.AutoSize = True
        Me.llLoadSequence.Font = New System.Drawing.Font("Calibri", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.llLoadSequence.LinkColor = System.Drawing.Color.DarkOrange
        Me.llLoadSequence.Location = New System.Drawing.Point(6, 134)
        Me.llLoadSequence.Name = "llLoadSequence"
        Me.llLoadSequence.Size = New System.Drawing.Size(92, 17)
        Me.llLoadSequence.TabIndex = 2
        Me.llLoadSequence.TabStop = True
        Me.llLoadSequence.Text = "Load Sequence"
        '
        'llSaveExperimentAs
        '
        Me.llSaveExperimentAs.AutoSize = True
        Me.llSaveExperimentAs.Font = New System.Drawing.Font("Calibri", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.llSaveExperimentAs.LinkColor = System.Drawing.Color.DodgerBlue
        Me.llSaveExperimentAs.Location = New System.Drawing.Point(223, 3)
        Me.llSaveExperimentAs.Name = "llSaveExperimentAs"
        Me.llSaveExperimentAs.Size = New System.Drawing.Size(118, 17)
        Me.llSaveExperimentAs.TabIndex = 2
        Me.llSaveExperimentAs.TabStop = True
        Me.llSaveExperimentAs.Text = "Save Experiment As"
        '
        'llSaveExperiment
        '
        Me.llSaveExperiment.AutoSize = True
        Me.llSaveExperiment.Font = New System.Drawing.Font("Calibri", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.llSaveExperiment.LinkColor = System.Drawing.Color.LightSeaGreen
        Me.llSaveExperiment.Location = New System.Drawing.Point(115, 3)
        Me.llSaveExperiment.Name = "llSaveExperiment"
        Me.llSaveExperiment.Size = New System.Drawing.Size(102, 17)
        Me.llSaveExperiment.TabIndex = 2
        Me.llSaveExperiment.TabStop = True
        Me.llSaveExperiment.Text = "Save Experiment"
        '
        'llLoadExperiment
        '
        Me.llLoadExperiment.AutoSize = True
        Me.llLoadExperiment.Font = New System.Drawing.Font("Calibri", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.llLoadExperiment.LinkColor = System.Drawing.Color.Chartreuse
        Me.llLoadExperiment.Location = New System.Drawing.Point(6, 3)
        Me.llLoadExperiment.Name = "llLoadExperiment"
        Me.llLoadExperiment.Size = New System.Drawing.Size(103, 17)
        Me.llLoadExperiment.TabIndex = 2
        Me.llLoadExperiment.TabStop = True
        Me.llLoadExperiment.Text = "Load Experiment"
        '
        'llLoadGeneFile
        '
        Me.llLoadGeneFile.AutoSize = True
        Me.llLoadGeneFile.Font = New System.Drawing.Font("Calibri", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.llLoadGeneFile.LinkColor = System.Drawing.Color.IndianRed
        Me.llLoadGeneFile.Location = New System.Drawing.Point(5, 29)
        Me.llLoadGeneFile.Name = "llLoadGeneFile"
        Me.llLoadGeneFile.Size = New System.Drawing.Size(90, 17)
        Me.llLoadGeneFile.TabIndex = 2
        Me.llLoadGeneFile.TabStop = True
        Me.llLoadGeneFile.Text = "Load Gene File"
        '
        'rtbSequence
        '
        Me.rtbSequence.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.rtbSequence.Location = New System.Drawing.Point(5, 154)
        Me.rtbSequence.Name = "rtbSequence"
        Me.rtbSequence.Size = New System.Drawing.Size(1016, 219)
        Me.rtbSequence.TabIndex = 1
        Me.rtbSequence.Text = ""
        '
        'TabPage2
        '
        Me.TabPage2.BackColor = System.Drawing.Color.White
        Me.TabPage2.Controls.Add(Me.PrpC)
        Me.TabPage2.Location = New System.Drawing.Point(4, 25)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage2.Size = New System.Drawing.Size(1028, 379)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "Operation Property"
        Me.TabPage2.UseVisualStyleBackColor = True
        '
        'PrpC
        '
        Me.PrpC.ApplyMode = True
        Me.PrpC.BackColor = System.Drawing.Color.White
        Me.PrpC.Dock = System.Windows.Forms.DockStyle.Fill
        Me.PrpC.Location = New System.Drawing.Point(3, 3)
        Me.PrpC.MolecularOperation = Vecute.Nuctions.MolecularOperationEnum.Vector
        Me.PrpC.Name = "PrpC"
        Me.PrpC.RelatedChartItem = Nothing
        Me.PrpC.Size = New System.Drawing.Size(1022, 373)
        Me.PrpC.TabIndex = 0
        '
        'TabPage3
        '
        Me.TabPage3.BackColor = System.Drawing.Color.White
        Me.TabPage3.Controls.Add(Me.MIV)
        Me.TabPage3.Location = New System.Drawing.Point(4, 25)
        Me.TabPage3.Name = "TabPage3"
        Me.TabPage3.Size = New System.Drawing.Size(1028, 379)
        Me.TabPage3.TabIndex = 2
        Me.TabPage3.Text = "Multiple DNAs"
        Me.TabPage3.UseVisualStyleBackColor = True
        '
        'MIV
        '
        Me.MIV.BackColor = System.Drawing.Color.White
        Me.MIV.Dock = System.Windows.Forms.DockStyle.Fill
        Me.MIV.Location = New System.Drawing.Point(0, 0)
        Me.MIV.Name = "MIV"
        Me.MIV.Size = New System.Drawing.Size(1028, 379)
        Me.MIV.TabIndex = 0
        '
        'TabPage4
        '
        Me.TabPage4.Controls.Add(Me.reView)
        Me.TabPage4.Location = New System.Drawing.Point(4, 25)
        Me.TabPage4.Name = "TabPage4"
        Me.TabPage4.Size = New System.Drawing.Size(1028, 379)
        Me.TabPage4.TabIndex = 3
        Me.TabPage4.Text = "Enzymes"
        Me.TabPage4.UseVisualStyleBackColor = True
        '
        'reView
        '
        Me.reView.BackColor = System.Drawing.Color.White
        Me.reView.Dock = System.Windows.Forms.DockStyle.Fill
        Me.reView.Location = New System.Drawing.Point(0, 0)
        Me.reView.Name = "reView"
        Me.reView.Size = New System.Drawing.Size(1028, 379)
        Me.reView.TabIndex = 0
        '
        'TabPage5
        '
        Me.TabPage5.Controls.Add(Me.gvDNA)
        Me.TabPage5.Location = New System.Drawing.Point(4, 25)
        Me.TabPage5.Name = "TabPage5"
        Me.TabPage5.Size = New System.Drawing.Size(1028, 379)
        Me.TabPage5.TabIndex = 4
        Me.TabPage5.Text = "DNA"
        Me.TabPage5.UseVisualStyleBackColor = True
        '
        'gvDNA
        '
        Me.gvDNA.BackColor = System.Drawing.Color.White
        Me.gvDNA.Dock = System.Windows.Forms.DockStyle.Fill
        Me.gvDNA.Location = New System.Drawing.Point(0, 0)
        Me.gvDNA.Name = "gvDNA"
        Me.gvDNA.Size = New System.Drawing.Size(1028, 379)
        Me.gvDNA.TabIndex = 0
        '
        'TabPage6
        '
        Me.TabPage6.Controls.Add(Me.gvPCR)
        Me.TabPage6.Location = New System.Drawing.Point(4, 25)
        Me.TabPage6.Name = "TabPage6"
        Me.TabPage6.Size = New System.Drawing.Size(1028, 379)
        Me.TabPage6.TabIndex = 5
        Me.TabPage6.Text = "PCR"
        Me.TabPage6.UseVisualStyleBackColor = True
        '
        'gvPCR
        '
        Me.gvPCR.BackColor = System.Drawing.Color.White
        Me.gvPCR.Dock = System.Windows.Forms.DockStyle.Fill
        Me.gvPCR.Location = New System.Drawing.Point(0, 0)
        Me.gvPCR.Name = "gvPCR"
        Me.gvPCR.Size = New System.Drawing.Size(1028, 379)
        Me.gvPCR.TabIndex = 0
        '
        'TabPage7
        '
        Me.TabPage7.Controls.Add(Me.FMV)
        Me.TabPage7.Location = New System.Drawing.Point(4, 25)
        Me.TabPage7.Name = "TabPage7"
        Me.TabPage7.Size = New System.Drawing.Size(1028, 379)
        Me.TabPage7.TabIndex = 6
        Me.TabPage7.Text = "Features"
        Me.TabPage7.UseVisualStyleBackColor = True
        '
        'FMV
        '
        Me.FMV.BackColor = System.Drawing.Color.White
        Me.FMV.Dock = System.Windows.Forms.DockStyle.Fill
        Me.FMV.Location = New System.Drawing.Point(0, 0)
        Me.FMV.Name = "FMV"
        Me.FMV.Size = New System.Drawing.Size(1028, 379)
        Me.FMV.TabIndex = 0
        '
        'TabPage8
        '
        Me.TabPage8.Controls.Add(Me.FSV)
        Me.TabPage8.Location = New System.Drawing.Point(4, 25)
        Me.TabPage8.Name = "TabPage8"
        Me.TabPage8.Size = New System.Drawing.Size(1028, 379)
        Me.TabPage8.TabIndex = 7
        Me.TabPage8.Text = "Feature Screen"
        Me.TabPage8.UseVisualStyleBackColor = True
        '
        'FSV
        '
        Me.FSV.BackColor = System.Drawing.Color.White
        Me.FSV.Dock = System.Windows.Forms.DockStyle.Fill
        Me.FSV.Location = New System.Drawing.Point(0, 0)
        Me.FSV.Name = "FSV"
        Me.FSV.Size = New System.Drawing.Size(1028, 379)
        Me.FSV.TabIndex = 0
        '
        'PropertyView
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.Controls.Add(Me.tcMain)
        Me.Name = "PropertyView"
        Me.Size = New System.Drawing.Size(1036, 408)
        Me.tcMain.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        Me.TabPage1.PerformLayout()
        Me.TabPage2.ResumeLayout(False)
        Me.TabPage3.ResumeLayout(False)
        Me.TabPage4.ResumeLayout(False)
        Me.TabPage5.ResumeLayout(False)
        Me.TabPage6.ResumeLayout(False)
        Me.TabPage7.ResumeLayout(False)
        Me.TabPage8.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents tcMain As TabContainer
    Friend WithEvents PrpC As Vecute.PropertyControl
    Friend WithEvents rtbSequence As System.Windows.Forms.RichTextBox
    Friend WithEvents llLoadSequencingResultFile As System.Windows.Forms.LinkLabel
    Friend WithEvents llLoadSequenceFile As System.Windows.Forms.LinkLabel
    Friend WithEvents llLoadSequencingResult As System.Windows.Forms.LinkLabel
    Friend WithEvents llManageEnzymes As System.Windows.Forms.LinkLabel
    Friend WithEvents llManageFeatures As System.Windows.Forms.LinkLabel
    Friend WithEvents llLoadSequence As System.Windows.Forms.LinkLabel
    Friend WithEvents llLoadGeneFile As System.Windows.Forms.LinkLabel
    Friend WithEvents MIV As Vecute.MultipleItemView
    Friend WithEvents llExportProject As System.Windows.Forms.LinkLabel
    Friend WithEvents llSaveExperimentAs As System.Windows.Forms.LinkLabel
    Friend WithEvents llSaveExperiment As System.Windows.Forms.LinkLabel
    Friend WithEvents llLoadExperiment As System.Windows.Forms.LinkLabel
    Friend WithEvents llClose As System.Windows.Forms.LinkLabel
    Friend WithEvents TabPage1 As Vecute.CustomTabPage
    Friend WithEvents TabPage2 As Vecute.CustomTabPage
    Friend WithEvents TabPage3 As Vecute.CustomTabPage
    Friend WithEvents reView As Vecute.RestrictionEnzymeView
    Friend WithEvents gvDNA As Vecute.GroupViewer
    Friend WithEvents gvPCR As Vecute.GroupViewer
    Friend WithEvents FMV As Vecute.FeatureManageView
    Friend WithEvents FSV As Vecute.FeatureScreenView
    Friend WithEvents TabPage4 As Vecute.CustomTabPage
    Friend WithEvents TabPage5 As Vecute.CustomTabPage
    Friend WithEvents TabPage6 As Vecute.CustomTabPage
    Friend WithEvents TabPage7 As Vecute.CustomTabPage
    Friend WithEvents TabPage8 As Vecute.CustomTabPage
    Friend WithEvents lbEnzymes As System.Windows.Forms.Label
    Friend WithEvents llRemarkFeature As System.Windows.Forms.LinkLabel
    Friend WithEvents rtbSummary As System.Windows.Forms.RichTextBox

End Class
