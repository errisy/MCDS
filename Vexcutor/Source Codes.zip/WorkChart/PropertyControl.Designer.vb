﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class PropertyControl
    Inherits System.Windows.Forms.UserControl

    'UserControl 重写 Dispose，以清理组件列表。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows 窗体设计器所必需的
    Private components As System.ComponentModel.IContainer

    '注意: 以下过程是 Windows 窗体设计器所必需的
    '可以使用 Windows 窗体设计器修改它。
    '不要使用代码编辑器修改它。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle4 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Me.rtb_Description = New System.Windows.Forms.RichTextBox
        Me.ll_ViewDetails = New System.Windows.Forms.LinkLabel
        Me.DNAView = New System.Windows.Forms.ListView
        Me.ch_Name = New System.Windows.Forms.ColumnHeader
        Me.ch_Size = New System.Windows.Forms.ColumnHeader
        Me.cn_Cir = New System.Windows.Forms.ColumnHeader
        Me.ch_ENDS = New System.Windows.Forms.ColumnHeader
        Me.ch_Phos = New System.Windows.Forms.ColumnHeader
        Me.Prop_Name = New System.Windows.Forms.TextBox
        Me.Prop_Count = New System.Windows.Forms.LinkLabel
        Me.Label4 = New System.Windows.Forms.Label
        Me.Prop_Type = New System.Windows.Forms.LinkLabel
        Me.Label3 = New System.Windows.Forms.Label
        Me.Prop_Operation = New System.Windows.Forms.LinkLabel
        Me.Label2 = New System.Windows.Forms.Label
        Me.Label1 = New System.Windows.Forms.Label
        Me.TabControl_Operation = New System.Windows.Forms.TabControl
        Me.tpFile = New System.Windows.Forms.TabPage
        Me.File_FileName_LinkLabel = New System.Windows.Forms.LinkLabel
        Me.File_Path_Label = New System.Windows.Forms.Label
        Me.Label18 = New System.Windows.Forms.Label
        Me.Label5 = New System.Windows.Forms.Label
        Me.tpEnzyme = New System.Windows.Forms.TabPage
        Me.tbEnzymes = New System.Windows.Forms.TextBox
        Me.Enzyme_Enzymes_LinkLabel = New System.Windows.Forms.LinkLabel
        Me.Label12 = New System.Windows.Forms.Label
        Me.tpPCR = New System.Windows.Forms.TabPage
        Me.lblRCount = New System.Windows.Forms.Label
        Me.lblFCount = New System.Windows.Forms.Label
        Me.pafPCR = New Vecute.PrimerAnalysisFrame
        Me.btnBothPrimer = New System.Windows.Forms.Button
        Me.tbRP = New System.Windows.Forms.TextBox
        Me.PCR_ReversePrimer_TextBox = New System.Windows.Forms.TextBox
        Me.tbFP = New System.Windows.Forms.TextBox
        Me.PCR_ForwardPrimer_TextBox = New System.Windows.Forms.TextBox
        Me.tpModify = New System.Windows.Forms.TabPage
        Me.GroupBox1 = New System.Windows.Forms.GroupBox
        Me.Modify_PNK = New System.Windows.Forms.RadioButton
        Me.Modify_CIAP = New System.Windows.Forms.RadioButton
        Me.Modify_Klewnow = New System.Windows.Forms.RadioButton
        Me.Modify_T4 = New System.Windows.Forms.RadioButton
        Me.tpGel = New System.Windows.Forms.TabPage
        Me.pnlGel = New System.Windows.Forms.Panel
        Me.Gel_Maximum_Number = New System.Windows.Forms.NumericUpDown
        Me.Gel_Minimum_Number = New System.Windows.Forms.NumericUpDown
        Me.Label9 = New System.Windows.Forms.Label
        Me.Label8 = New System.Windows.Forms.Label
        Me.tpLigation = New System.Windows.Forms.TabPage
        Me.GroupBox3 = New System.Windows.Forms.GroupBox
        Me.rbLig3 = New System.Windows.Forms.RadioButton
        Me.rbLigM = New System.Windows.Forms.RadioButton
        Me.rbLig2 = New System.Windows.Forms.RadioButton
        Me.tpScreen = New System.Windows.Forms.TabPage
        Me.cbScreenCircular = New System.Windows.Forms.CheckBox
        Me.Screen_PCR_Panel = New System.Windows.Forms.Panel
        Me.Screen_PCR_nudMax = New System.Windows.Forms.NumericUpDown
        Me.Screen_PCR_nudMin = New System.Windows.Forms.NumericUpDown
        Me.Screen_PCR_lblMax = New System.Windows.Forms.Label
        Me.Screen_PCR_lblMin = New System.Windows.Forms.Label
        Me.Screen_PCR_RCF = New System.Windows.Forms.Button
        Me.tbSCRRP = New System.Windows.Forms.TextBox
        Me.Screen_PCR_R = New System.Windows.Forms.TextBox
        Me.tbSCRFP = New System.Windows.Forms.TextBox
        Me.Screen_PCR_F = New System.Windows.Forms.TextBox
        Me.Screen_PCR = New System.Windows.Forms.RadioButton
        Me.Screen_Freatures = New System.Windows.Forms.RadioButton
        Me.Screen_Features_LinkLabel = New System.Windows.Forms.LinkLabel
        Me.pnlFeature = New System.Windows.Forms.Panel
        Me.tpRec = New System.Windows.Forms.TabPage
        Me.GroupBox2 = New System.Windows.Forms.GroupBox
        Me.rbRecP21LR = New System.Windows.Forms.RadioButton
        Me.rbRecHK022LR = New System.Windows.Forms.RadioButton
        Me.rbRecP21BP = New System.Windows.Forms.RadioButton
        Me.rbRecHK022BP = New System.Windows.Forms.RadioButton
        Me.rbLoxP = New System.Windows.Forms.RadioButton
        Me.rbRecP22LR = New System.Windows.Forms.RadioButton
        Me.rbRecPhi80LR = New System.Windows.Forms.RadioButton
        Me.rbRecLambdaLR = New System.Windows.Forms.RadioButton
        Me.rbFRT = New System.Windows.Forms.RadioButton
        Me.rbRecLambda = New System.Windows.Forms.RadioButton
        Me.rbRecP22BP = New System.Windows.Forms.RadioButton
        Me.rbRecPhi80BP = New System.Windows.Forms.RadioButton
        Me.rbRecLambdaBP = New System.Windows.Forms.RadioButton
        Me.rbRecHomologous = New System.Windows.Forms.RadioButton
        Me.tpEnzymeAnalysis = New System.Windows.Forms.TabPage
        Me.dgvEnzymeAnalysis = New System.Windows.Forms.DataGridView
        Me.Column1 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column5 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column2 = New System.Windows.Forms.DataGridViewCheckBoxColumn
        Me.Column3 = New System.Windows.Forms.DataGridViewComboBoxColumn
        Me.Column4 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.cmsEnzyme = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.AddToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.RemoveToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.tpSequencingResult = New System.Windows.Forms.TabPage
        Me.cbMergeExtend = New System.Windows.Forms.CheckBox
        Me.cbMergeSignificant = New System.Windows.Forms.CheckBox
        Me.tpMerge = New System.Windows.Forms.TabPage
        Me.llApply = New System.Windows.Forms.LinkLabel
        Me.llCancel = New System.Windows.Forms.LinkLabel
        Me.cbRealSize = New System.Windows.Forms.CheckBox
        Me.ofdVector = New System.Windows.Forms.OpenFileDialog
        Me.GroupBox4 = New System.Windows.Forms.GroupBox
        Me.rbFinished = New System.Windows.Forms.RadioButton
        Me.rbInprogress = New System.Windows.Forms.RadioButton
        Me.rbUnstarted = New System.Windows.Forms.RadioButton
        Me.TabControl_Operation.SuspendLayout()
        Me.tpFile.SuspendLayout()
        Me.tpEnzyme.SuspendLayout()
        Me.tpPCR.SuspendLayout()
        CType(Me.pafPCR, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.tpModify.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.tpGel.SuspendLayout()
        CType(Me.Gel_Maximum_Number, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Gel_Minimum_Number, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.tpLigation.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.tpScreen.SuspendLayout()
        Me.Screen_PCR_Panel.SuspendLayout()
        CType(Me.Screen_PCR_nudMax, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Screen_PCR_nudMin, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.tpRec.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.tpEnzymeAnalysis.SuspendLayout()
        CType(Me.dgvEnzymeAnalysis, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.cmsEnzyme.SuspendLayout()
        Me.tpSequencingResult.SuspendLayout()
        Me.GroupBox4.SuspendLayout()
        Me.SuspendLayout()
        '
        'rtb_Description
        '
        Me.rtb_Description.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.rtb_Description.BackColor = System.Drawing.Color.Azure
        Me.rtb_Description.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.rtb_Description.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rtb_Description.Location = New System.Drawing.Point(9, 248)
        Me.rtb_Description.Name = "rtb_Description"
        Me.rtb_Description.Size = New System.Drawing.Size(497, 89)
        Me.rtb_Description.TabIndex = 27
        Me.rtb_Description.Text = ""
        '
        'll_ViewDetails
        '
        Me.ll_ViewDetails.AutoSize = True
        Me.ll_ViewDetails.Location = New System.Drawing.Point(512, 35)
        Me.ll_ViewDetails.Name = "ll_ViewDetails"
        Me.ll_ViewDetails.Size = New System.Drawing.Size(59, 12)
        Me.ll_ViewDetails.TabIndex = 24
        Me.ll_ViewDetails.TabStop = True
        Me.ll_ViewDetails.Text = "View DNAs"
        '
        'DNAView
        '
        Me.DNAView.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.DNAView.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.ch_Name, Me.ch_Size, Me.cn_Cir, Me.ch_ENDS, Me.ch_Phos})
        Me.DNAView.Location = New System.Drawing.Point(512, 50)
        Me.DNAView.Name = "DNAView"
        Me.DNAView.Size = New System.Drawing.Size(497, 287)
        Me.DNAView.TabIndex = 22
        Me.DNAView.UseCompatibleStateImageBehavior = False
        Me.DNAView.View = System.Windows.Forms.View.Details
        '
        'ch_Name
        '
        Me.ch_Name.Text = "DNA"
        Me.ch_Name.Width = 100
        '
        'ch_Size
        '
        Me.ch_Size.Text = "Size"
        '
        'cn_Cir
        '
        Me.cn_Cir.Text = "Shape"
        Me.cn_Cir.Width = 70
        '
        'ch_ENDS
        '
        Me.ch_ENDS.Text = "F End"
        Me.ch_ENDS.Width = 120
        '
        'ch_Phos
        '
        Me.ch_Phos.Text = "R End"
        Me.ch_Phos.Width = 120
        '
        'Prop_Name
        '
        Me.Prop_Name.Location = New System.Drawing.Point(41, 0)
        Me.Prop_Name.Name = "Prop_Name"
        Me.Prop_Name.Size = New System.Drawing.Size(175, 21)
        Me.Prop_Name.TabIndex = 21
        '
        'Prop_Count
        '
        Me.Prop_Count.AutoSize = True
        Me.Prop_Count.Font = New System.Drawing.Font("宋体", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
        Me.Prop_Count.LinkColor = System.Drawing.Color.Red
        Me.Prop_Count.Location = New System.Drawing.Point(415, 3)
        Me.Prop_Count.Name = "Prop_Count"
        Me.Prop_Count.Size = New System.Drawing.Size(47, 12)
        Me.Prop_Count.TabIndex = 16
        Me.Prop_Count.TabStop = True
        Me.Prop_Count.Text = "Number"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(374, 3)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(35, 12)
        Me.Label4.TabIndex = 13
        Me.Label4.Text = "Count"
        '
        'Prop_Type
        '
        Me.Prop_Type.AutoSize = True
        Me.Prop_Type.Font = New System.Drawing.Font("宋体", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
        Me.Prop_Type.LinkColor = System.Drawing.Color.Red
        Me.Prop_Type.Location = New System.Drawing.Point(257, 3)
        Me.Prop_Type.Name = "Prop_Type"
        Me.Prop_Type.Size = New System.Drawing.Size(89, 12)
        Me.Prop_Type.TabIndex = 18
        Me.Prop_Type.TabStop = True
        Me.Prop_Type.Text = "Mixture/Pure"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(222, 3)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(29, 12)
        Me.Label3.TabIndex = 12
        Me.Label3.Text = "Type"
        '
        'Prop_Operation
        '
        Me.Prop_Operation.AutoSize = True
        Me.Prop_Operation.Font = New System.Drawing.Font("宋体", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
        Me.Prop_Operation.LinkColor = System.Drawing.Color.Red
        Me.Prop_Operation.Location = New System.Drawing.Point(53, 24)
        Me.Prop_Operation.Name = "Prop_Operation"
        Me.Prop_Operation.Size = New System.Drawing.Size(103, 12)
        Me.Prop_Operation.TabIndex = 17
        Me.Prop_Operation.TabStop = True
        Me.Prop_Operation.Text = "Operation/File"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(6, 24)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(41, 12)
        Me.Label2.TabIndex = 15
        Me.Label2.Text = "Source"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(6, 3)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(29, 12)
        Me.Label1.TabIndex = 14
        Me.Label1.Text = "Name"
        '
        'TabControl_Operation
        '
        Me.TabControl_Operation.Controls.Add(Me.tpFile)
        Me.TabControl_Operation.Controls.Add(Me.tpEnzyme)
        Me.TabControl_Operation.Controls.Add(Me.tpPCR)
        Me.TabControl_Operation.Controls.Add(Me.tpModify)
        Me.TabControl_Operation.Controls.Add(Me.tpGel)
        Me.TabControl_Operation.Controls.Add(Me.tpLigation)
        Me.TabControl_Operation.Controls.Add(Me.tpScreen)
        Me.TabControl_Operation.Controls.Add(Me.tpRec)
        Me.TabControl_Operation.Controls.Add(Me.tpEnzymeAnalysis)
        Me.TabControl_Operation.Controls.Add(Me.tpSequencingResult)
        Me.TabControl_Operation.Controls.Add(Me.tpMerge)
        Me.TabControl_Operation.Location = New System.Drawing.Point(4, 39)
        Me.TabControl_Operation.Name = "TabControl_Operation"
        Me.TabControl_Operation.SelectedIndex = 0
        Me.TabControl_Operation.Size = New System.Drawing.Size(505, 210)
        Me.TabControl_Operation.TabIndex = 11
        '
        'tpFile
        '
        Me.tpFile.Controls.Add(Me.File_FileName_LinkLabel)
        Me.tpFile.Controls.Add(Me.File_Path_Label)
        Me.tpFile.Controls.Add(Me.Label18)
        Me.tpFile.Controls.Add(Me.Label5)
        Me.tpFile.Location = New System.Drawing.Point(4, 21)
        Me.tpFile.Name = "tpFile"
        Me.tpFile.Size = New System.Drawing.Size(497, 185)
        Me.tpFile.TabIndex = 6
        Me.tpFile.Text = "File"
        Me.tpFile.UseVisualStyleBackColor = True
        '
        'File_FileName_LinkLabel
        '
        Me.File_FileName_LinkLabel.AutoSize = True
        Me.File_FileName_LinkLabel.Location = New System.Drawing.Point(101, 27)
        Me.File_FileName_LinkLabel.Name = "File_FileName_LinkLabel"
        Me.File_FileName_LinkLabel.Size = New System.Drawing.Size(95, 12)
        Me.File_FileName_LinkLabel.TabIndex = 1
        Me.File_FileName_LinkLabel.TabStop = True
        Me.File_FileName_LinkLabel.Text = "[Filename text]"
        '
        'File_Path_Label
        '
        Me.File_Path_Label.AutoSize = True
        Me.File_Path_Label.Location = New System.Drawing.Point(101, 54)
        Me.File_Path_Label.Name = "File_Path_Label"
        Me.File_Path_Label.Size = New System.Drawing.Size(29, 12)
        Me.File_Path_Label.TabIndex = 0
        Me.File_Path_Label.Text = "Path"
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Location = New System.Drawing.Point(21, 54)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(29, 12)
        Me.Label18.TabIndex = 0
        Me.Label18.Text = "Path"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(22, 27)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(53, 12)
        Me.Label5.TabIndex = 0
        Me.Label5.Text = "Filename"
        '
        'tpEnzyme
        '
        Me.tpEnzyme.Controls.Add(Me.tbEnzymes)
        Me.tpEnzyme.Controls.Add(Me.Enzyme_Enzymes_LinkLabel)
        Me.tpEnzyme.Controls.Add(Me.Label12)
        Me.tpEnzyme.Location = New System.Drawing.Point(4, 21)
        Me.tpEnzyme.Name = "tpEnzyme"
        Me.tpEnzyme.Padding = New System.Windows.Forms.Padding(3)
        Me.tpEnzyme.Size = New System.Drawing.Size(497, 185)
        Me.tpEnzyme.TabIndex = 0
        Me.tpEnzyme.Text = "Enzyme"
        Me.tpEnzyme.UseVisualStyleBackColor = True
        '
        'tbEnzymes
        '
        Me.tbEnzymes.Location = New System.Drawing.Point(5, 51)
        Me.tbEnzymes.Name = "tbEnzymes"
        Me.tbEnzymes.Size = New System.Drawing.Size(486, 21)
        Me.tbEnzymes.TabIndex = 3
        '
        'Enzyme_Enzymes_LinkLabel
        '
        Me.Enzyme_Enzymes_LinkLabel.AutoSize = True
        Me.Enzyme_Enzymes_LinkLabel.Location = New System.Drawing.Point(3, 26)
        Me.Enzyme_Enzymes_LinkLabel.Name = "Enzyme_Enzymes_LinkLabel"
        Me.Enzyme_Enzymes_LinkLabel.Size = New System.Drawing.Size(107, 12)
        Me.Enzyme_Enzymes_LinkLabel.TabIndex = 2
        Me.Enzyme_Enzymes_LinkLabel.TabStop = True
        Me.Enzyme_Enzymes_LinkLabel.Text = "[Click to select]"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(6, 3)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(47, 12)
        Me.Label12.TabIndex = 1
        Me.Label12.Text = "Enzymes"
        '
        'tpPCR
        '
        Me.tpPCR.Controls.Add(Me.lblRCount)
        Me.tpPCR.Controls.Add(Me.lblFCount)
        Me.tpPCR.Controls.Add(Me.pafPCR)
        Me.tpPCR.Controls.Add(Me.btnBothPrimer)
        Me.tpPCR.Controls.Add(Me.tbRP)
        Me.tpPCR.Controls.Add(Me.PCR_ReversePrimer_TextBox)
        Me.tpPCR.Controls.Add(Me.tbFP)
        Me.tpPCR.Controls.Add(Me.PCR_ForwardPrimer_TextBox)
        Me.tpPCR.Location = New System.Drawing.Point(4, 21)
        Me.tpPCR.Name = "tpPCR"
        Me.tpPCR.Padding = New System.Windows.Forms.Padding(3)
        Me.tpPCR.Size = New System.Drawing.Size(497, 185)
        Me.tpPCR.TabIndex = 1
        Me.tpPCR.Text = "PCR"
        Me.tpPCR.UseVisualStyleBackColor = True
        '
        'lblRCount
        '
        Me.lblRCount.AutoSize = True
        Me.lblRCount.Location = New System.Drawing.Point(442, 22)
        Me.lblRCount.Name = "lblRCount"
        Me.lblRCount.Size = New System.Drawing.Size(11, 12)
        Me.lblRCount.TabIndex = 4
        Me.lblRCount.Text = "0"
        '
        'lblFCount
        '
        Me.lblFCount.AutoSize = True
        Me.lblFCount.Location = New System.Drawing.Point(442, 3)
        Me.lblFCount.Name = "lblFCount"
        Me.lblFCount.Size = New System.Drawing.Size(11, 12)
        Me.lblFCount.TabIndex = 4
        Me.lblFCount.Text = "0"
        '
        'pafPCR
        '
        Me.pafPCR.Location = New System.Drawing.Point(0, 40)
        Me.pafPCR.Name = "pafPCR"
        Me.pafPCR.ShowSequencing = False
        Me.pafPCR.Size = New System.Drawing.Size(497, 145)
        Me.pafPCR.TabIndex = 3
        Me.pafPCR.TabStop = False
        '
        'btnBothPrimer
        '
        Me.btnBothPrimer.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnBothPrimer.Location = New System.Drawing.Point(476, 0)
        Me.btnBothPrimer.Name = "btnBothPrimer"
        Me.btnBothPrimer.Size = New System.Drawing.Size(21, 40)
        Me.btnBothPrimer.TabIndex = 2
        Me.btnBothPrimer.Text = "PR"
        Me.btnBothPrimer.UseVisualStyleBackColor = True
        '
        'tbRP
        '
        Me.tbRP.Location = New System.Drawing.Point(0, 19)
        Me.tbRP.Name = "tbRP"
        Me.tbRP.Size = New System.Drawing.Size(68, 21)
        Me.tbRP.TabIndex = 1
        '
        'PCR_ReversePrimer_TextBox
        '
        Me.PCR_ReversePrimer_TextBox.Location = New System.Drawing.Point(67, 19)
        Me.PCR_ReversePrimer_TextBox.Name = "PCR_ReversePrimer_TextBox"
        Me.PCR_ReversePrimer_TextBox.Size = New System.Drawing.Size(368, 21)
        Me.PCR_ReversePrimer_TextBox.TabIndex = 1
        '
        'tbFP
        '
        Me.tbFP.Location = New System.Drawing.Point(0, 0)
        Me.tbFP.Name = "tbFP"
        Me.tbFP.Size = New System.Drawing.Size(68, 21)
        Me.tbFP.TabIndex = 1
        '
        'PCR_ForwardPrimer_TextBox
        '
        Me.PCR_ForwardPrimer_TextBox.Location = New System.Drawing.Point(67, 0)
        Me.PCR_ForwardPrimer_TextBox.Name = "PCR_ForwardPrimer_TextBox"
        Me.PCR_ForwardPrimer_TextBox.Size = New System.Drawing.Size(368, 21)
        Me.PCR_ForwardPrimer_TextBox.TabIndex = 1
        '
        'tpModify
        '
        Me.tpModify.Controls.Add(Me.GroupBox1)
        Me.tpModify.Location = New System.Drawing.Point(4, 21)
        Me.tpModify.Name = "tpModify"
        Me.tpModify.Size = New System.Drawing.Size(497, 185)
        Me.tpModify.TabIndex = 3
        Me.tpModify.Text = "Modify"
        Me.tpModify.UseVisualStyleBackColor = True
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.Modify_PNK)
        Me.GroupBox1.Controls.Add(Me.Modify_CIAP)
        Me.GroupBox1.Controls.Add(Me.Modify_Klewnow)
        Me.GroupBox1.Controls.Add(Me.Modify_T4)
        Me.GroupBox1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.GroupBox1.Location = New System.Drawing.Point(0, 0)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(497, 185)
        Me.GroupBox1.TabIndex = 2
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Modification Methods"
        '
        'Modify_PNK
        '
        Me.Modify_PNK.AutoSize = True
        Me.Modify_PNK.Location = New System.Drawing.Point(239, 42)
        Me.Modify_PNK.Name = "Modify_PNK"
        Me.Modify_PNK.Size = New System.Drawing.Size(113, 16)
        Me.Modify_PNK.TabIndex = 0
        Me.Modify_PNK.TabStop = True
        Me.Modify_PNK.Text = "PNK Phosphorate"
        Me.Modify_PNK.UseVisualStyleBackColor = True
        '
        'Modify_CIAP
        '
        Me.Modify_CIAP.AutoSize = True
        Me.Modify_CIAP.Location = New System.Drawing.Point(15, 42)
        Me.Modify_CIAP.Name = "Modify_CIAP"
        Me.Modify_CIAP.Size = New System.Drawing.Size(131, 16)
        Me.Modify_CIAP.TabIndex = 0
        Me.Modify_CIAP.TabStop = True
        Me.Modify_CIAP.Text = "CIAP Dephosphorate"
        Me.Modify_CIAP.UseVisualStyleBackColor = True
        '
        'Modify_Klewnow
        '
        Me.Modify_Klewnow.AutoSize = True
        Me.Modify_Klewnow.Location = New System.Drawing.Point(239, 20)
        Me.Modify_Klewnow.Name = "Modify_Klewnow"
        Me.Modify_Klewnow.Size = New System.Drawing.Size(185, 16)
        Me.Modify_Klewnow.TabIndex = 0
        Me.Modify_Klewnow.TabStop = True
        Me.Modify_Klewnow.Text = "Blunt with Klewnow Fragment"
        Me.Modify_Klewnow.UseVisualStyleBackColor = True
        '
        'Modify_T4
        '
        Me.Modify_T4.AutoSize = True
        Me.Modify_T4.Location = New System.Drawing.Point(15, 20)
        Me.Modify_T4.Name = "Modify_T4"
        Me.Modify_T4.Size = New System.Drawing.Size(191, 16)
        Me.Modify_T4.TabIndex = 0
        Me.Modify_T4.TabStop = True
        Me.Modify_T4.Text = "Blunt with T4 DNA polymerase"
        Me.Modify_T4.UseVisualStyleBackColor = True
        '
        'tpGel
        '
        Me.tpGel.Controls.Add(Me.pnlGel)
        Me.tpGel.Controls.Add(Me.Gel_Maximum_Number)
        Me.tpGel.Controls.Add(Me.Gel_Minimum_Number)
        Me.tpGel.Controls.Add(Me.Label9)
        Me.tpGel.Controls.Add(Me.Label8)
        Me.tpGel.Location = New System.Drawing.Point(4, 21)
        Me.tpGel.Name = "tpGel"
        Me.tpGel.Size = New System.Drawing.Size(497, 185)
        Me.tpGel.TabIndex = 2
        Me.tpGel.Text = "Gel"
        Me.tpGel.UseVisualStyleBackColor = True
        '
        'pnlGel
        '
        Me.pnlGel.Location = New System.Drawing.Point(0, 35)
        Me.pnlGel.Name = "pnlGel"
        Me.pnlGel.Size = New System.Drawing.Size(497, 150)
        Me.pnlGel.TabIndex = 2
        '
        'Gel_Maximum_Number
        '
        Me.Gel_Maximum_Number.Increment = New Decimal(New Integer() {50, 0, 0, 0})
        Me.Gel_Maximum_Number.Location = New System.Drawing.Point(302, 8)
        Me.Gel_Maximum_Number.Maximum = New Decimal(New Integer() {200000, 0, 0, 0})
        Me.Gel_Maximum_Number.Minimum = New Decimal(New Integer() {100, 0, 0, 0})
        Me.Gel_Maximum_Number.Name = "Gel_Maximum_Number"
        Me.Gel_Maximum_Number.Size = New System.Drawing.Size(120, 21)
        Me.Gel_Maximum_Number.TabIndex = 1
        Me.Gel_Maximum_Number.Value = New Decimal(New Integer() {1500, 0, 0, 0})
        '
        'Gel_Minimum_Number
        '
        Me.Gel_Minimum_Number.Increment = New Decimal(New Integer() {50, 0, 0, 0})
        Me.Gel_Minimum_Number.Location = New System.Drawing.Point(56, 8)
        Me.Gel_Minimum_Number.Maximum = New Decimal(New Integer() {200000, 0, 0, 0})
        Me.Gel_Minimum_Number.Minimum = New Decimal(New Integer() {100, 0, 0, 0})
        Me.Gel_Minimum_Number.Name = "Gel_Minimum_Number"
        Me.Gel_Minimum_Number.Size = New System.Drawing.Size(120, 21)
        Me.Gel_Minimum_Number.TabIndex = 1
        Me.Gel_Minimum_Number.Value = New Decimal(New Integer() {100, 0, 0, 0})
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(249, 10)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(47, 12)
        Me.Label9.TabIndex = 0
        Me.Label9.Text = "Maximum"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(3, 10)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(47, 12)
        Me.Label8.TabIndex = 0
        Me.Label8.Text = "Minimum"
        '
        'tpLigation
        '
        Me.tpLigation.Controls.Add(Me.GroupBox3)
        Me.tpLigation.Location = New System.Drawing.Point(4, 21)
        Me.tpLigation.Name = "tpLigation"
        Me.tpLigation.Size = New System.Drawing.Size(497, 185)
        Me.tpLigation.TabIndex = 7
        Me.tpLigation.Text = "Ligation"
        Me.tpLigation.UseVisualStyleBackColor = True
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.rbLig3)
        Me.GroupBox3.Controls.Add(Me.rbLigM)
        Me.GroupBox3.Controls.Add(Me.rbLig2)
        Me.GroupBox3.Dock = System.Windows.Forms.DockStyle.Fill
        Me.GroupBox3.Location = New System.Drawing.Point(0, 0)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(497, 185)
        Me.GroupBox3.TabIndex = 6
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Modification Methods"
        '
        'rbLig3
        '
        Me.rbLig3.AutoSize = True
        Me.rbLig3.Location = New System.Drawing.Point(15, 42)
        Me.rbLig3.Name = "rbLig3"
        Me.rbLig3.Size = New System.Drawing.Size(161, 16)
        Me.rbLig3.TabIndex = 0
        Me.rbLig3.TabStop = True
        Me.rbLig3.Text = "Three fragment ligation"
        Me.rbLig3.UseVisualStyleBackColor = True
        '
        'rbLigM
        '
        Me.rbLigM.AutoSize = True
        Me.rbLigM.Location = New System.Drawing.Point(15, 64)
        Me.rbLigM.Name = "rbLigM"
        Me.rbLigM.Size = New System.Drawing.Size(179, 16)
        Me.rbLigM.TabIndex = 0
        Me.rbLigM.TabStop = True
        Me.rbLigM.Text = "Multiple fragment ligation"
        Me.rbLigM.UseVisualStyleBackColor = True
        '
        'rbLig2
        '
        Me.rbLig2.AutoSize = True
        Me.rbLig2.Location = New System.Drawing.Point(15, 20)
        Me.rbLig2.Name = "rbLig2"
        Me.rbLig2.Size = New System.Drawing.Size(185, 16)
        Me.rbLig2.TabIndex = 0
        Me.rbLig2.TabStop = True
        Me.rbLig2.Text = "Normal two fragment ligatio"
        Me.rbLig2.UseVisualStyleBackColor = True
        '
        'tpScreen
        '
        Me.tpScreen.Controls.Add(Me.cbScreenCircular)
        Me.tpScreen.Controls.Add(Me.Screen_PCR_Panel)
        Me.tpScreen.Controls.Add(Me.Screen_PCR)
        Me.tpScreen.Controls.Add(Me.Screen_Freatures)
        Me.tpScreen.Controls.Add(Me.Screen_Features_LinkLabel)
        Me.tpScreen.Controls.Add(Me.pnlFeature)
        Me.tpScreen.Location = New System.Drawing.Point(4, 21)
        Me.tpScreen.Name = "tpScreen"
        Me.tpScreen.Size = New System.Drawing.Size(497, 185)
        Me.tpScreen.TabIndex = 5
        Me.tpScreen.Text = "Screen"
        Me.tpScreen.UseVisualStyleBackColor = True
        '
        'cbScreenCircular
        '
        Me.cbScreenCircular.AutoSize = True
        Me.cbScreenCircular.Location = New System.Drawing.Point(392, 4)
        Me.cbScreenCircular.Name = "cbScreenCircular"
        Me.cbScreenCircular.Size = New System.Drawing.Size(102, 16)
        Me.cbScreenCircular.TabIndex = 9
        Me.cbScreenCircular.Text = "Only Circular"
        Me.cbScreenCircular.UseVisualStyleBackColor = True
        '
        'Screen_PCR_Panel
        '
        Me.Screen_PCR_Panel.Controls.Add(Me.Screen_PCR_nudMax)
        Me.Screen_PCR_Panel.Controls.Add(Me.Screen_PCR_nudMin)
        Me.Screen_PCR_Panel.Controls.Add(Me.Screen_PCR_lblMax)
        Me.Screen_PCR_Panel.Controls.Add(Me.Screen_PCR_lblMin)
        Me.Screen_PCR_Panel.Controls.Add(Me.Screen_PCR_RCF)
        Me.Screen_PCR_Panel.Controls.Add(Me.tbSCRRP)
        Me.Screen_PCR_Panel.Controls.Add(Me.Screen_PCR_R)
        Me.Screen_PCR_Panel.Controls.Add(Me.tbSCRFP)
        Me.Screen_PCR_Panel.Controls.Add(Me.Screen_PCR_F)
        Me.Screen_PCR_Panel.Location = New System.Drawing.Point(3, 26)
        Me.Screen_PCR_Panel.Name = "Screen_PCR_Panel"
        Me.Screen_PCR_Panel.Size = New System.Drawing.Size(491, 64)
        Me.Screen_PCR_Panel.TabIndex = 8
        Me.Screen_PCR_Panel.Visible = False
        '
        'Screen_PCR_nudMax
        '
        Me.Screen_PCR_nudMax.Increment = New Decimal(New Integer() {50, 0, 0, 0})
        Me.Screen_PCR_nudMax.Location = New System.Drawing.Point(427, 8)
        Me.Screen_PCR_nudMax.Maximum = New Decimal(New Integer() {100000, 0, 0, 0})
        Me.Screen_PCR_nudMax.Minimum = New Decimal(New Integer() {100, 0, 0, 0})
        Me.Screen_PCR_nudMax.Name = "Screen_PCR_nudMax"
        Me.Screen_PCR_nudMax.Size = New System.Drawing.Size(61, 21)
        Me.Screen_PCR_nudMax.TabIndex = 21
        Me.Screen_PCR_nudMax.Value = New Decimal(New Integer() {100, 0, 0, 0})
        '
        'Screen_PCR_nudMin
        '
        Me.Screen_PCR_nudMin.Increment = New Decimal(New Integer() {50, 0, 0, 0})
        Me.Screen_PCR_nudMin.Location = New System.Drawing.Point(427, 35)
        Me.Screen_PCR_nudMin.Maximum = New Decimal(New Integer() {100000, 0, 0, 0})
        Me.Screen_PCR_nudMin.Minimum = New Decimal(New Integer() {100, 0, 0, 0})
        Me.Screen_PCR_nudMin.Name = "Screen_PCR_nudMin"
        Me.Screen_PCR_nudMin.Size = New System.Drawing.Size(61, 21)
        Me.Screen_PCR_nudMin.TabIndex = 22
        Me.Screen_PCR_nudMin.Value = New Decimal(New Integer() {100, 0, 0, 0})
        '
        'Screen_PCR_lblMax
        '
        Me.Screen_PCR_lblMax.AutoSize = True
        Me.Screen_PCR_lblMax.Location = New System.Drawing.Point(374, 10)
        Me.Screen_PCR_lblMax.Name = "Screen_PCR_lblMax"
        Me.Screen_PCR_lblMax.Size = New System.Drawing.Size(47, 12)
        Me.Screen_PCR_lblMax.TabIndex = 19
        Me.Screen_PCR_lblMax.Text = "Maximum"
        '
        'Screen_PCR_lblMin
        '
        Me.Screen_PCR_lblMin.AutoSize = True
        Me.Screen_PCR_lblMin.Location = New System.Drawing.Point(374, 40)
        Me.Screen_PCR_lblMin.Name = "Screen_PCR_lblMin"
        Me.Screen_PCR_lblMin.Size = New System.Drawing.Size(47, 12)
        Me.Screen_PCR_lblMin.TabIndex = 20
        Me.Screen_PCR_lblMin.Text = "Minimum"
        '
        'Screen_PCR_RCF
        '
        Me.Screen_PCR_RCF.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Screen_PCR_RCF.Location = New System.Drawing.Point(334, 10)
        Me.Screen_PCR_RCF.Name = "Screen_PCR_RCF"
        Me.Screen_PCR_RCF.Size = New System.Drawing.Size(34, 42)
        Me.Screen_PCR_RCF.TabIndex = 18
        Me.Screen_PCR_RCF.Text = "PR"
        Me.Screen_PCR_RCF.UseVisualStyleBackColor = True
        '
        'tbSCRRP
        '
        Me.tbSCRRP.Location = New System.Drawing.Point(3, 37)
        Me.tbSCRRP.Name = "tbSCRRP"
        Me.tbSCRRP.Size = New System.Drawing.Size(64, 21)
        Me.tbSCRRP.TabIndex = 16
        '
        'Screen_PCR_R
        '
        Me.Screen_PCR_R.Location = New System.Drawing.Point(73, 37)
        Me.Screen_PCR_R.Name = "Screen_PCR_R"
        Me.Screen_PCR_R.Size = New System.Drawing.Size(255, 21)
        Me.Screen_PCR_R.TabIndex = 16
        '
        'tbSCRFP
        '
        Me.tbSCRFP.Location = New System.Drawing.Point(3, 10)
        Me.tbSCRFP.Name = "tbSCRFP"
        Me.tbSCRFP.Size = New System.Drawing.Size(64, 21)
        Me.tbSCRFP.TabIndex = 15
        '
        'Screen_PCR_F
        '
        Me.Screen_PCR_F.Location = New System.Drawing.Point(73, 10)
        Me.Screen_PCR_F.Name = "Screen_PCR_F"
        Me.Screen_PCR_F.Size = New System.Drawing.Size(255, 21)
        Me.Screen_PCR_F.TabIndex = 15
        '
        'Screen_PCR
        '
        Me.Screen_PCR.AutoSize = True
        Me.Screen_PCR.Location = New System.Drawing.Point(107, 4)
        Me.Screen_PCR.Name = "Screen_PCR"
        Me.Screen_PCR.Size = New System.Drawing.Size(41, 16)
        Me.Screen_PCR.TabIndex = 7
        Me.Screen_PCR.Text = "PCR"
        Me.Screen_PCR.UseVisualStyleBackColor = True
        '
        'Screen_Freatures
        '
        Me.Screen_Freatures.AutoSize = True
        Me.Screen_Freatures.Checked = True
        Me.Screen_Freatures.Location = New System.Drawing.Point(6, 3)
        Me.Screen_Freatures.Name = "Screen_Freatures"
        Me.Screen_Freatures.Size = New System.Drawing.Size(71, 16)
        Me.Screen_Freatures.TabIndex = 7
        Me.Screen_Freatures.TabStop = True
        Me.Screen_Freatures.Text = "Features"
        Me.Screen_Freatures.UseVisualStyleBackColor = True
        '
        'Screen_Features_LinkLabel
        '
        Me.Screen_Features_LinkLabel.AutoSize = True
        Me.Screen_Features_LinkLabel.Location = New System.Drawing.Point(4, 32)
        Me.Screen_Features_LinkLabel.Name = "Screen_Features_LinkLabel"
        Me.Screen_Features_LinkLabel.Size = New System.Drawing.Size(107, 12)
        Me.Screen_Features_LinkLabel.TabIndex = 6
        Me.Screen_Features_LinkLabel.TabStop = True
        Me.Screen_Features_LinkLabel.Text = "[Click to select]"
        '
        'pnlFeature
        '
        Me.pnlFeature.Location = New System.Drawing.Point(3, 47)
        Me.pnlFeature.Name = "pnlFeature"
        Me.pnlFeature.Size = New System.Drawing.Size(491, 135)
        Me.pnlFeature.TabIndex = 10
        '
        'tpRec
        '
        Me.tpRec.Controls.Add(Me.GroupBox2)
        Me.tpRec.Location = New System.Drawing.Point(4, 21)
        Me.tpRec.Name = "tpRec"
        Me.tpRec.Size = New System.Drawing.Size(497, 185)
        Me.tpRec.TabIndex = 8
        Me.tpRec.Text = "Recombination"
        Me.tpRec.UseVisualStyleBackColor = True
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.rbRecP21LR)
        Me.GroupBox2.Controls.Add(Me.rbRecHK022LR)
        Me.GroupBox2.Controls.Add(Me.rbRecP21BP)
        Me.GroupBox2.Controls.Add(Me.rbRecHK022BP)
        Me.GroupBox2.Controls.Add(Me.rbLoxP)
        Me.GroupBox2.Controls.Add(Me.rbRecP22LR)
        Me.GroupBox2.Controls.Add(Me.rbRecPhi80LR)
        Me.GroupBox2.Controls.Add(Me.rbRecLambdaLR)
        Me.GroupBox2.Controls.Add(Me.rbFRT)
        Me.GroupBox2.Controls.Add(Me.rbRecLambda)
        Me.GroupBox2.Controls.Add(Me.rbRecP22BP)
        Me.GroupBox2.Controls.Add(Me.rbRecPhi80BP)
        Me.GroupBox2.Controls.Add(Me.rbRecLambdaBP)
        Me.GroupBox2.Controls.Add(Me.rbRecHomologous)
        Me.GroupBox2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.GroupBox2.Location = New System.Drawing.Point(0, 0)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(497, 185)
        Me.GroupBox2.TabIndex = 3
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Recombination Type"
        '
        'rbRecP21LR
        '
        Me.rbRecP21LR.AutoSize = True
        Me.rbRecP21LR.Location = New System.Drawing.Point(247, 86)
        Me.rbRecP21LR.Name = "rbRecP21LR"
        Me.rbRecP21LR.Size = New System.Drawing.Size(59, 16)
        Me.rbRecP21LR.TabIndex = 0
        Me.rbRecP21LR.TabStop = True
        Me.rbRecP21LR.Text = "P21 LR"
        Me.rbRecP21LR.UseVisualStyleBackColor = True
        '
        'rbRecHK022LR
        '
        Me.rbRecHK022LR.AutoSize = True
        Me.rbRecHK022LR.Location = New System.Drawing.Point(164, 86)
        Me.rbRecHK022LR.Name = "rbRecHK022LR"
        Me.rbRecHK022LR.Size = New System.Drawing.Size(71, 16)
        Me.rbRecHK022LR.TabIndex = 0
        Me.rbRecHK022LR.TabStop = True
        Me.rbRecHK022LR.Text = "HK022 LR"
        Me.rbRecHK022LR.UseVisualStyleBackColor = True
        '
        'rbRecP21BP
        '
        Me.rbRecP21BP.AutoSize = True
        Me.rbRecP21BP.Location = New System.Drawing.Point(247, 64)
        Me.rbRecP21BP.Name = "rbRecP21BP"
        Me.rbRecP21BP.Size = New System.Drawing.Size(59, 16)
        Me.rbRecP21BP.TabIndex = 0
        Me.rbRecP21BP.TabStop = True
        Me.rbRecP21BP.Text = "P21 BP"
        Me.rbRecP21BP.UseVisualStyleBackColor = True
        '
        'rbRecHK022BP
        '
        Me.rbRecHK022BP.AutoSize = True
        Me.rbRecHK022BP.Location = New System.Drawing.Point(164, 64)
        Me.rbRecHK022BP.Name = "rbRecHK022BP"
        Me.rbRecHK022BP.Size = New System.Drawing.Size(71, 16)
        Me.rbRecHK022BP.TabIndex = 0
        Me.rbRecHK022BP.TabStop = True
        Me.rbRecHK022BP.Text = "HK022 BP"
        Me.rbRecHK022BP.UseVisualStyleBackColor = True
        '
        'rbLoxP
        '
        Me.rbLoxP.AutoSize = True
        Me.rbLoxP.Location = New System.Drawing.Point(334, 86)
        Me.rbLoxP.Name = "rbLoxP"
        Me.rbLoxP.Size = New System.Drawing.Size(47, 16)
        Me.rbLoxP.TabIndex = 0
        Me.rbLoxP.TabStop = True
        Me.rbLoxP.Text = "loxP"
        Me.rbLoxP.UseVisualStyleBackColor = True
        '
        'rbRecP22LR
        '
        Me.rbRecP22LR.AutoSize = True
        Me.rbRecP22LR.Location = New System.Drawing.Point(334, 42)
        Me.rbRecP22LR.Name = "rbRecP22LR"
        Me.rbRecP22LR.Size = New System.Drawing.Size(59, 16)
        Me.rbRecP22LR.TabIndex = 0
        Me.rbRecP22LR.TabStop = True
        Me.rbRecP22LR.Text = "P22 LR"
        Me.rbRecP22LR.UseVisualStyleBackColor = True
        '
        'rbRecPhi80LR
        '
        Me.rbRecPhi80LR.AutoSize = True
        Me.rbRecPhi80LR.Location = New System.Drawing.Point(247, 42)
        Me.rbRecPhi80LR.Name = "rbRecPhi80LR"
        Me.rbRecPhi80LR.Size = New System.Drawing.Size(71, 16)
        Me.rbRecPhi80LR.TabIndex = 0
        Me.rbRecPhi80LR.TabStop = True
        Me.rbRecPhi80LR.Text = "Phi80 LR"
        Me.rbRecPhi80LR.UseVisualStyleBackColor = True
        '
        'rbRecLambdaLR
        '
        Me.rbRecLambdaLR.AutoSize = True
        Me.rbRecLambdaLR.Location = New System.Drawing.Point(164, 42)
        Me.rbRecLambdaLR.Name = "rbRecLambdaLR"
        Me.rbRecLambdaLR.Size = New System.Drawing.Size(77, 16)
        Me.rbRecLambdaLR.TabIndex = 0
        Me.rbRecLambdaLR.TabStop = True
        Me.rbRecLambdaLR.Text = "Lambda LR"
        Me.rbRecLambdaLR.UseVisualStyleBackColor = True
        '
        'rbFRT
        '
        Me.rbFRT.AutoSize = True
        Me.rbFRT.Location = New System.Drawing.Point(334, 64)
        Me.rbFRT.Name = "rbFRT"
        Me.rbFRT.Size = New System.Drawing.Size(41, 16)
        Me.rbFRT.TabIndex = 0
        Me.rbFRT.TabStop = True
        Me.rbFRT.Text = "FRT"
        Me.rbFRT.UseVisualStyleBackColor = True
        '
        'rbRecLambda
        '
        Me.rbRecLambda.AutoSize = True
        Me.rbRecLambda.Location = New System.Drawing.Point(15, 42)
        Me.rbRecLambda.Name = "rbRecLambda"
        Me.rbRecLambda.Size = New System.Drawing.Size(143, 16)
        Me.rbRecLambda.TabIndex = 0
        Me.rbRecLambda.TabStop = True
        Me.rbRecLambda.Text = "lambda recombination"
        Me.rbRecLambda.UseVisualStyleBackColor = True
        '
        'rbRecP22BP
        '
        Me.rbRecP22BP.AutoSize = True
        Me.rbRecP22BP.Location = New System.Drawing.Point(334, 20)
        Me.rbRecP22BP.Name = "rbRecP22BP"
        Me.rbRecP22BP.Size = New System.Drawing.Size(59, 16)
        Me.rbRecP22BP.TabIndex = 0
        Me.rbRecP22BP.TabStop = True
        Me.rbRecP22BP.Text = "P22 BP"
        Me.rbRecP22BP.UseVisualStyleBackColor = True
        '
        'rbRecPhi80BP
        '
        Me.rbRecPhi80BP.AutoSize = True
        Me.rbRecPhi80BP.Location = New System.Drawing.Point(247, 20)
        Me.rbRecPhi80BP.Name = "rbRecPhi80BP"
        Me.rbRecPhi80BP.Size = New System.Drawing.Size(71, 16)
        Me.rbRecPhi80BP.TabIndex = 0
        Me.rbRecPhi80BP.TabStop = True
        Me.rbRecPhi80BP.Text = "Phi80 BP"
        Me.rbRecPhi80BP.UseVisualStyleBackColor = True
        '
        'rbRecLambdaBP
        '
        Me.rbRecLambdaBP.AutoSize = True
        Me.rbRecLambdaBP.Location = New System.Drawing.Point(164, 20)
        Me.rbRecLambdaBP.Name = "rbRecLambdaBP"
        Me.rbRecLambdaBP.Size = New System.Drawing.Size(77, 16)
        Me.rbRecLambdaBP.TabIndex = 0
        Me.rbRecLambdaBP.TabStop = True
        Me.rbRecLambdaBP.Text = "Lambda BP"
        Me.rbRecLambdaBP.UseVisualStyleBackColor = True
        '
        'rbRecHomologous
        '
        Me.rbRecHomologous.AutoSize = True
        Me.rbRecHomologous.Location = New System.Drawing.Point(15, 20)
        Me.rbRecHomologous.Name = "rbRecHomologous"
        Me.rbRecHomologous.Size = New System.Drawing.Size(83, 16)
        Me.rbRecHomologous.TabIndex = 0
        Me.rbRecHomologous.TabStop = True
        Me.rbRecHomologous.Text = "Homologous"
        Me.rbRecHomologous.UseVisualStyleBackColor = True
        '
        'tpEnzymeAnalysis
        '
        Me.tpEnzymeAnalysis.Controls.Add(Me.dgvEnzymeAnalysis)
        Me.tpEnzymeAnalysis.Location = New System.Drawing.Point(4, 21)
        Me.tpEnzymeAnalysis.Name = "tpEnzymeAnalysis"
        Me.tpEnzymeAnalysis.Size = New System.Drawing.Size(497, 185)
        Me.tpEnzymeAnalysis.TabIndex = 9
        Me.tpEnzymeAnalysis.Text = "Enzyem Analysis"
        Me.tpEnzymeAnalysis.UseVisualStyleBackColor = True
        '
        'dgvEnzymeAnalysis
        '
        Me.dgvEnzymeAnalysis.AllowUserToAddRows = False
        Me.dgvEnzymeAnalysis.AllowUserToDeleteRows = False
        Me.dgvEnzymeAnalysis.AllowUserToOrderColumns = True
        Me.dgvEnzymeAnalysis.AllowUserToResizeRows = False
        Me.dgvEnzymeAnalysis.BackgroundColor = System.Drawing.Color.White
        DataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle3.Font = New System.Drawing.Font("宋体", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
        DataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgvEnzymeAnalysis.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle3
        Me.dgvEnzymeAnalysis.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvEnzymeAnalysis.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.Column1, Me.Column5, Me.Column2, Me.Column3, Me.Column4})
        Me.dgvEnzymeAnalysis.ContextMenuStrip = Me.cmsEnzyme
        DataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle4.Font = New System.Drawing.Font("宋体", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
        DataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.dgvEnzymeAnalysis.DefaultCellStyle = DataGridViewCellStyle4
        Me.dgvEnzymeAnalysis.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgvEnzymeAnalysis.GridColor = System.Drawing.Color.DarkViolet
        Me.dgvEnzymeAnalysis.Location = New System.Drawing.Point(0, 0)
        Me.dgvEnzymeAnalysis.Name = "dgvEnzymeAnalysis"
        Me.dgvEnzymeAnalysis.RowTemplate.Height = 23
        Me.dgvEnzymeAnalysis.Size = New System.Drawing.Size(497, 185)
        Me.dgvEnzymeAnalysis.TabIndex = 0
        '
        'Column1
        '
        Me.Column1.HeaderText = "Name"
        Me.Column1.Name = "Column1"
        Me.Column1.ReadOnly = True
        Me.Column1.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.Column1.Width = 130
        '
        'Column5
        '
        Me.Column5.HeaderText = "Region"
        Me.Column5.Name = "Column5"
        Me.Column5.ReadOnly = True
        Me.Column5.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.Column5.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        '
        'Column2
        '
        Me.Column2.HeaderText = "Use"
        Me.Column2.Name = "Column2"
        Me.Column2.Width = 40
        '
        'Column3
        '
        Me.Column3.HeaderText = "Method"
        Me.Column3.Items.AddRange(New Object() {"=", ">", "<"})
        Me.Column3.Name = "Column3"
        Me.Column3.Width = 60
        '
        'Column4
        '
        Me.Column4.HeaderText = "Value"
        Me.Column4.Name = "Column4"
        '
        'cmsEnzyme
        '
        Me.cmsEnzyme.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.AddToolStripMenuItem, Me.RemoveToolStripMenuItem})
        Me.cmsEnzyme.Name = "cmsEnzyme"
        Me.cmsEnzyme.Size = New System.Drawing.Size(161, 48)
        '
        'AddToolStripMenuItem
        '
        Me.AddToolStripMenuItem.Name = "AddToolStripMenuItem"
        Me.AddToolStripMenuItem.Size = New System.Drawing.Size(160, 22)
        Me.AddToolStripMenuItem.Text = "Select Sequence"
        '
        'RemoveToolStripMenuItem
        '
        Me.RemoveToolStripMenuItem.Name = "RemoveToolStripMenuItem"
        Me.RemoveToolStripMenuItem.Size = New System.Drawing.Size(160, 22)
        Me.RemoveToolStripMenuItem.Text = "Remove Sequence"
        '
        'tpSequencingResult
        '
        Me.tpSequencingResult.Controls.Add(Me.cbMergeExtend)
        Me.tpSequencingResult.Controls.Add(Me.cbMergeSignificant)
        Me.tpSequencingResult.Location = New System.Drawing.Point(4, 21)
        Me.tpSequencingResult.Name = "tpSequencingResult"
        Me.tpSequencingResult.Size = New System.Drawing.Size(497, 185)
        Me.tpSequencingResult.TabIndex = 10
        Me.tpSequencingResult.Text = "Merge"
        Me.tpSequencingResult.UseVisualStyleBackColor = True
        '
        'cbMergeExtend
        '
        Me.cbMergeExtend.AutoSize = True
        Me.cbMergeExtend.Location = New System.Drawing.Point(314, 16)
        Me.cbMergeExtend.Name = "cbMergeExtend"
        Me.cbMergeExtend.Size = New System.Drawing.Size(132, 16)
        Me.cbMergeExtend.TabIndex = 0
        Me.cbMergeExtend.Text = "Only Extend Length"
        Me.cbMergeExtend.UseVisualStyleBackColor = True
        '
        'cbMergeSignificant
        '
        Me.cbMergeSignificant.AutoSize = True
        Me.cbMergeSignificant.Location = New System.Drawing.Point(13, 16)
        Me.cbMergeSignificant.Name = "cbMergeSignificant"
        Me.cbMergeSignificant.Size = New System.Drawing.Size(156, 16)
        Me.cbMergeSignificant.TabIndex = 0
        Me.cbMergeSignificant.Text = "Only Significant Merge"
        Me.cbMergeSignificant.UseVisualStyleBackColor = True
        '
        'tpMerge
        '
        Me.tpMerge.Location = New System.Drawing.Point(4, 21)
        Me.tpMerge.Name = "tpMerge"
        Me.tpMerge.Size = New System.Drawing.Size(497, 185)
        Me.tpMerge.TabIndex = 11
        Me.tpMerge.Text = "Compare"
        Me.tpMerge.UseVisualStyleBackColor = True
        '
        'llApply
        '
        Me.llApply.AutoSize = True
        Me.llApply.Font = New System.Drawing.Font("Calibri", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.llApply.LinkColor = System.Drawing.Color.Red
        Me.llApply.Location = New System.Drawing.Point(510, 6)
        Me.llApply.Name = "llApply"
        Me.llApply.Size = New System.Drawing.Size(49, 19)
        Me.llApply.TabIndex = 28
        Me.llApply.TabStop = True
        Me.llApply.Text = "Apply"
        '
        'llCancel
        '
        Me.llCancel.ActiveLinkColor = System.Drawing.Color.Green
        Me.llCancel.AutoSize = True
        Me.llCancel.DisabledLinkColor = System.Drawing.Color.Green
        Me.llCancel.Font = New System.Drawing.Font("Calibri", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.llCancel.ForeColor = System.Drawing.Color.Green
        Me.llCancel.LinkColor = System.Drawing.Color.Green
        Me.llCancel.Location = New System.Drawing.Point(565, 6)
        Me.llCancel.Name = "llCancel"
        Me.llCancel.Size = New System.Drawing.Size(53, 19)
        Me.llCancel.TabIndex = 28
        Me.llCancel.TabStop = True
        Me.llCancel.Text = "Cancel"
        '
        'cbRealSize
        '
        Me.cbRealSize.AutoSize = True
        Me.cbRealSize.Location = New System.Drawing.Point(407, 23)
        Me.cbRealSize.Name = "cbRealSize"
        Me.cbRealSize.Size = New System.Drawing.Size(102, 16)
        Me.cbRealSize.TabIndex = 29
        Me.cbRealSize.Text = "100 pixel/Kbp"
        Me.cbRealSize.UseVisualStyleBackColor = True
        '
        'ofdVector
        '
        Me.ofdVector.Filter = "Sequence File|*.gb;*.txt;*.seq"
        '
        'GroupBox4
        '
        Me.GroupBox4.Controls.Add(Me.rbFinished)
        Me.GroupBox4.Controls.Add(Me.rbInprogress)
        Me.GroupBox4.Controls.Add(Me.rbUnstarted)
        Me.GroupBox4.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.GroupBox4.Location = New System.Drawing.Point(651, 0)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Size = New System.Drawing.Size(358, 47)
        Me.GroupBox4.TabIndex = 31
        Me.GroupBox4.TabStop = False
        Me.GroupBox4.Text = "Status"
        '
        'rbFinished
        '
        Me.rbFinished.AutoSize = True
        Me.rbFinished.Location = New System.Drawing.Point(195, 20)
        Me.rbFinished.Name = "rbFinished"
        Me.rbFinished.Size = New System.Drawing.Size(71, 16)
        Me.rbFinished.TabIndex = 0
        Me.rbFinished.TabStop = True
        Me.rbFinished.Tag = "2"
        Me.rbFinished.Text = "Finished"
        Me.rbFinished.UseVisualStyleBackColor = True
        '
        'rbInprogress
        '
        Me.rbInprogress.AutoSize = True
        Me.rbInprogress.Location = New System.Drawing.Point(100, 20)
        Me.rbInprogress.Name = "rbInprogress"
        Me.rbInprogress.Size = New System.Drawing.Size(89, 16)
        Me.rbInprogress.TabIndex = 0
        Me.rbInprogress.TabStop = True
        Me.rbInprogress.Tag = "1"
        Me.rbInprogress.Text = "In Progress"
        Me.rbInprogress.UseVisualStyleBackColor = True
        '
        'rbUnstarted
        '
        Me.rbUnstarted.AutoSize = True
        Me.rbUnstarted.Location = New System.Drawing.Point(5, 20)
        Me.rbUnstarted.Name = "rbUnstarted"
        Me.rbUnstarted.Size = New System.Drawing.Size(89, 16)
        Me.rbUnstarted.TabIndex = 0
        Me.rbUnstarted.TabStop = True
        Me.rbUnstarted.Tag = "0"
        Me.rbUnstarted.Text = "Not Started"
        Me.rbUnstarted.UseVisualStyleBackColor = True
        '
        'PropertyControl
        '
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None
        Me.BackColor = System.Drawing.Color.Snow
        Me.Controls.Add(Me.GroupBox4)
        Me.Controls.Add(Me.llApply)
        Me.Controls.Add(Me.cbRealSize)
        Me.Controls.Add(Me.rtb_Description)
        Me.Controls.Add(Me.llCancel)
        Me.Controls.Add(Me.DNAView)
        Me.Controls.Add(Me.ll_ViewDetails)
        Me.Controls.Add(Me.Prop_Name)
        Me.Controls.Add(Me.Prop_Type)
        Me.Controls.Add(Me.Prop_Count)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Prop_Operation)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.TabControl_Operation)
        Me.Controls.Add(Me.Label1)
        Me.Name = "PropertyControl"
        Me.Size = New System.Drawing.Size(1016, 344)
        Me.TabControl_Operation.ResumeLayout(False)
        Me.tpFile.ResumeLayout(False)
        Me.tpFile.PerformLayout()
        Me.tpEnzyme.ResumeLayout(False)
        Me.tpEnzyme.PerformLayout()
        Me.tpPCR.ResumeLayout(False)
        Me.tpPCR.PerformLayout()
        CType(Me.pafPCR, System.ComponentModel.ISupportInitialize).EndInit()
        Me.tpModify.ResumeLayout(False)
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.tpGel.ResumeLayout(False)
        Me.tpGel.PerformLayout()
        CType(Me.Gel_Maximum_Number, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Gel_Minimum_Number, System.ComponentModel.ISupportInitialize).EndInit()
        Me.tpLigation.ResumeLayout(False)
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        Me.tpScreen.ResumeLayout(False)
        Me.tpScreen.PerformLayout()
        Me.Screen_PCR_Panel.ResumeLayout(False)
        Me.Screen_PCR_Panel.PerformLayout()
        CType(Me.Screen_PCR_nudMax, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Screen_PCR_nudMin, System.ComponentModel.ISupportInitialize).EndInit()
        Me.tpRec.ResumeLayout(False)
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.tpEnzymeAnalysis.ResumeLayout(False)
        CType(Me.dgvEnzymeAnalysis, System.ComponentModel.ISupportInitialize).EndInit()
        Me.cmsEnzyme.ResumeLayout(False)
        Me.tpSequencingResult.ResumeLayout(False)
        Me.tpSequencingResult.PerformLayout()
        Me.GroupBox4.ResumeLayout(False)
        Me.GroupBox4.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents rtb_Description As System.Windows.Forms.RichTextBox
    Friend WithEvents ll_ViewDetails As System.Windows.Forms.LinkLabel
    Friend WithEvents DNAView As System.Windows.Forms.ListView
    Friend WithEvents ch_Name As System.Windows.Forms.ColumnHeader
    Friend WithEvents ch_Size As System.Windows.Forms.ColumnHeader
    Friend WithEvents cn_Cir As System.Windows.Forms.ColumnHeader
    Friend WithEvents ch_ENDS As System.Windows.Forms.ColumnHeader
    Friend WithEvents ch_Phos As System.Windows.Forms.ColumnHeader
    Friend WithEvents Prop_Name As System.Windows.Forms.TextBox
    Friend WithEvents Prop_Count As System.Windows.Forms.LinkLabel
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Prop_Type As System.Windows.Forms.LinkLabel
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Prop_Operation As System.Windows.Forms.LinkLabel
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents TabControl_Operation As System.Windows.Forms.TabControl
    Friend WithEvents tpFile As System.Windows.Forms.TabPage
    Friend WithEvents File_FileName_LinkLabel As System.Windows.Forms.LinkLabel
    Friend WithEvents File_Path_Label As System.Windows.Forms.Label
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents tpEnzyme As System.Windows.Forms.TabPage
    Friend WithEvents Enzyme_Enzymes_LinkLabel As System.Windows.Forms.LinkLabel
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents tpPCR As System.Windows.Forms.TabPage
    Friend WithEvents PCR_ReversePrimer_TextBox As System.Windows.Forms.TextBox
    Friend WithEvents PCR_ForwardPrimer_TextBox As System.Windows.Forms.TextBox
    Friend WithEvents tpModify As System.Windows.Forms.TabPage
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents Modify_PNK As System.Windows.Forms.RadioButton
    Friend WithEvents Modify_CIAP As System.Windows.Forms.RadioButton
    Friend WithEvents Modify_Klewnow As System.Windows.Forms.RadioButton
    Friend WithEvents Modify_T4 As System.Windows.Forms.RadioButton
    Friend WithEvents tpGel As System.Windows.Forms.TabPage
    Friend WithEvents Gel_Maximum_Number As System.Windows.Forms.NumericUpDown
    Friend WithEvents Gel_Minimum_Number As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents tpLigation As System.Windows.Forms.TabPage
    Friend WithEvents tpScreen As System.Windows.Forms.TabPage
    Friend WithEvents Screen_PCR_Panel As System.Windows.Forms.Panel
    Friend WithEvents Screen_PCR_nudMax As System.Windows.Forms.NumericUpDown
    Friend WithEvents Screen_PCR_nudMin As System.Windows.Forms.NumericUpDown
    Friend WithEvents Screen_PCR_lblMax As System.Windows.Forms.Label
    Friend WithEvents Screen_PCR_lblMin As System.Windows.Forms.Label
    Friend WithEvents Screen_PCR_RCF As System.Windows.Forms.Button
    Friend WithEvents Screen_PCR_R As System.Windows.Forms.TextBox
    Friend WithEvents Screen_PCR_F As System.Windows.Forms.TextBox
    Friend WithEvents Screen_PCR As System.Windows.Forms.RadioButton
    Friend WithEvents Screen_Freatures As System.Windows.Forms.RadioButton
    Friend WithEvents Screen_Features_LinkLabel As System.Windows.Forms.LinkLabel
    Friend WithEvents tpRec As System.Windows.Forms.TabPage
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents rbRecLambdaLR As System.Windows.Forms.RadioButton
    Friend WithEvents rbRecLambda As System.Windows.Forms.RadioButton
    Friend WithEvents rbRecLambdaBP As System.Windows.Forms.RadioButton
    Friend WithEvents rbRecHomologous As System.Windows.Forms.RadioButton
    Friend WithEvents rbRecP21LR As System.Windows.Forms.RadioButton
    Friend WithEvents rbRecHK022LR As System.Windows.Forms.RadioButton
    Friend WithEvents rbRecP21BP As System.Windows.Forms.RadioButton
    Friend WithEvents rbRecHK022BP As System.Windows.Forms.RadioButton
    Friend WithEvents rbRecP22LR As System.Windows.Forms.RadioButton
    Friend WithEvents rbRecPhi80LR As System.Windows.Forms.RadioButton
    Friend WithEvents rbRecP22BP As System.Windows.Forms.RadioButton
    Friend WithEvents rbRecPhi80BP As System.Windows.Forms.RadioButton
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents rbLig3 As System.Windows.Forms.RadioButton
    Friend WithEvents rbLigM As System.Windows.Forms.RadioButton
    Friend WithEvents rbLig2 As System.Windows.Forms.RadioButton
    Friend WithEvents llApply As System.Windows.Forms.LinkLabel
    Friend WithEvents llCancel As System.Windows.Forms.LinkLabel
    Friend WithEvents pafPCR As Vecute.PrimerAnalysisFrame
    Friend WithEvents btnBothPrimer As System.Windows.Forms.Button
    Friend WithEvents tbRP As System.Windows.Forms.TextBox
    Friend WithEvents tbFP As System.Windows.Forms.TextBox
    Friend WithEvents rbLoxP As System.Windows.Forms.RadioButton
    Friend WithEvents rbFRT As System.Windows.Forms.RadioButton
    Friend WithEvents cbScreenCircular As System.Windows.Forms.CheckBox
    Friend WithEvents tpEnzymeAnalysis As System.Windows.Forms.TabPage
    Friend WithEvents tpSequencingResult As System.Windows.Forms.TabPage
    Friend WithEvents tpMerge As System.Windows.Forms.TabPage
    Friend WithEvents dgvEnzymeAnalysis As System.Windows.Forms.DataGridView
    Friend WithEvents cmsEnzyme As System.Windows.Forms.ContextMenuStrip
    Friend WithEvents AddToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents RemoveToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Column1 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column5 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column2 As System.Windows.Forms.DataGridViewCheckBoxColumn
    Friend WithEvents Column3 As System.Windows.Forms.DataGridViewComboBoxColumn
    Friend WithEvents Column4 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents tbSCRRP As System.Windows.Forms.TextBox
    Friend WithEvents tbSCRFP As System.Windows.Forms.TextBox
    Friend WithEvents cbRealSize As System.Windows.Forms.CheckBox
    Friend WithEvents lblRCount As System.Windows.Forms.Label
    Friend WithEvents lblFCount As System.Windows.Forms.Label
    Friend WithEvents ofdVector As System.Windows.Forms.OpenFileDialog
    Friend WithEvents tbEnzymes As System.Windows.Forms.TextBox
    Friend WithEvents pnlGel As System.Windows.Forms.Panel
    Friend WithEvents pnlFeature As System.Windows.Forms.Panel
    Friend WithEvents cbMergeSignificant As System.Windows.Forms.CheckBox
    Friend WithEvents cbMergeExtend As System.Windows.Forms.CheckBox
    Friend WithEvents GroupBox4 As System.Windows.Forms.GroupBox
    Friend WithEvents rbFinished As System.Windows.Forms.RadioButton
    Friend WithEvents rbInprogress As System.Windows.Forms.RadioButton
    Friend WithEvents rbUnstarted As System.Windows.Forms.RadioButton

End Class
