﻿Public Class PropertyView
    Private vSelectItems As List(Of ChartItem)
    Private TPProperty As TabPage
    Private TPOperation As TabPage
    Private TPAnalysis As TabPage
    Private TPMultiple As TabPage
    Private TPEnzyme As TabPage
    Private TPDNA As TabPage
    Private TPPCR As TabPage
    Private TPFeature As TabPage
    Private TPFeatureScreen As TabPage

    Private WithEvents CPrpC As PropertyControl
    Private CMIV As MultipleItemView

    '事件列表
    Public Event LoadGeneFile(ByVal sender As Object, ByVal e As EventArgs)
    Public Event LoadSequenceFile(ByVal sender As Object, ByVal e As EventArgs)
    Public Event LoadSequencingResultFile(ByVal sender As Object, ByVal e As EventArgs)
    Public Event ExportProject(ByVal sender As Object, ByVal e As EventArgs)
    Public Event ManageFeatures(ByVal sender As Object, ByVal e As EventArgs)
    Public Event ManageEnzymes(ByVal sender As Object, ByVal e As RestrictionEnzymeView.RESiteEventArgs)

    Public Event LoadExperiment(ByVal sender As Object, ByVal e As EventArgs)
    Public Event SaveExperiment(ByVal sender As Object, ByVal e As EventArgs)
    Public Event SaveExperimentAs(ByVal sender As Object, ByVal e As EventArgs)
    Public Event Close(ByVal sender As Object, ByVal e As EventArgs)

    Public Event ValueChange(ByVal sender As Object, ByVal e As EventArgs)


    Public Sub New()

        ' 此调用是 Windows 窗体设计器所必需的。
        InitializeComponent()

        ' 在 InitializeComponent() 调用之后添加任何初始化。
        TPProperty = tcMain.TabPages(0)
        TPOperation = tcMain.TabPages(1)
        TPMultiple = tcMain.TabPages(2)
        TPEnzyme = tcMain.TabPages(3)
        TPDNA = tcMain.TabPages(4)
        TPPCR = tcMain.TabPages(5)
        TPFeature = tcMain.TabPages(6)
        TPFeatureScreen = tcMain.TabPages(7)

        tcMain.TabPages.Clear()
        tcMain.TabPages.Add(TPProperty)

        CPrpC = PrpC
        CPrpC.ParentTC = tcMain
        CMIV = MIV

    End Sub

    Public Property SelectItem() As List(Of ChartItem)
        Get
            Return vSelectItems
        End Get
        Set(ByVal value As List(Of ChartItem))
            If Not (value Is Nothing) Then

                Select Case value.Count
                    Case 0
                        If tcMain.TabPages.Contains(TPProperty) Then
                        Else
                            tcMain.TabPages.Add(TPProperty)
                            Dim rmlist As New List(Of CustomTabPage)
                            For Each tp As CustomTabPage In tcMain.TabPages
                                If Not (tp Is TPProperty) Then rmlist.Add(tp)
                            Next
                            For Each tp As CustomTabPage In rmlist
                                tcMain.TabPages.Remove(tp)
                            Next
                        End If
                    Case 1
                        If tcMain.TabPages.Contains(TPOperation) Then
                            If Not (PrpC.RelatedChartItem Is value(0)) Then
                                Dim rmlist As New List(Of CustomTabPage)
                                For Each tp As CustomTabPage In tcMain.TabPages
                                    If Not (tp Is TPOperation) Then rmlist.Add(tp)
                                Next
                                For Each tp As CustomTabPage In rmlist
                                    tcMain.TabPages.Remove(tp)
                                Next
                            End If
                            CPrpC.RelatedChartItem = value(0)
                        Else
                            tcMain.TabPages.Add(TPOperation)
                            Dim rmlist As New List(Of CustomTabPage)
                            For Each tp As CustomTabPage In tcMain.TabPages
                                If Not (tp Is TPOperation) Then rmlist.Add(tp)
                            Next
                            For Each tp As CustomTabPage In rmlist
                                tcMain.TabPages.Remove(tp)
                            Next
                            CPrpC.RelatedChartItem = value(0)
                        End If
                    Case Else
                        If tcMain.TabPages.Contains(TPMultiple) Then
                            Dim rmlist As New List(Of CustomTabPage)
                            For Each tp As CustomTabPage In tcMain.TabPages
                                If Not (tp Is TPMultiple) Then rmlist.Add(tp)
                            Next
                            For Each tp As CustomTabPage In rmlist
                                tcMain.TabPages.Remove(tp)
                            Next
                            CMIV.SetSelectedItems(value)
                        Else
                            tcMain.TabPages.Add(TPMultiple)
                            Dim rmlist As New List(Of CustomTabPage)
                            For Each tp As CustomTabPage In tcMain.TabPages
                                If Not (tp Is TPMultiple) Then rmlist.Add(tp)
                            Next
                            For Each tp As CustomTabPage In rmlist
                                tcMain.TabPages.Remove(tp)
                            Next
                            CMIV.SetSelectedItems(value)
                        End If
                End Select
            End If
        End Set
    End Property

#Region "对外事件"
    Private Sub llLoadGeneFile_LinkClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles llLoadGeneFile.LinkClicked
        RaiseEvent LoadGeneFile(Me, New EventArgs)
    End Sub

    Private Sub llLoadSequenceFile_LinkClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles llLoadSequenceFile.LinkClicked
        RaiseEvent LoadSequenceFile(Me, New EventArgs)

    End Sub

    Private Sub llLoadSequencingResultFile_LinkClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles llLoadSequencingResultFile.LinkClicked
        RaiseEvent LoadSequencingResultFile(Me, New EventArgs)

    End Sub

    Private Sub llManageFeatures_LinkClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles llManageFeatures.LinkClicked
        If tcMain.TabPages.Contains(TPFeature) Then

            FMV.LoadCurrentFeatures(Features)
            TPFeature.Select()
        Else
            tcMain.TabPages.Add(TPFeature)
            FMV.LoadCurrentFeatures(Features)
            TPFeature.Select()
        End If
    End Sub

    Private Sub llManageEnzymes_LinkClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles llManageEnzymes.LinkClicked
        'RaiseEvent ManageEnzymes(Me, New EventArgs)
        If Not tcMain.TabPages.Contains(TPEnzyme) Then
            reView.LoadEnzymeItems(frmMain.EnzymeCol, Enzymes)
            tcMain.TabPages.Add(TPEnzyme)
            TPEnzyme.Select()
        End If
    End Sub
    Public Sub CloseEnzymeTab()
        tcMain.TabPages.Remove(TPEnzyme)
    End Sub

    Private Sub llExportPrimerList_LinkClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles llExportProject.LinkClicked
        RaiseEvent ExportProject(Me, New EventArgs)
    End Sub
    Private Sub llLoadExperiment_LinkClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles llLoadExperiment.LinkClicked
        RaiseEvent LoadExperiment(Me, New EventArgs)
    End Sub

    Private Sub llSaveExperiment_LinkClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles llSaveExperiment.LinkClicked
        RaiseEvent SaveExperiment(Me, New EventArgs)
    End Sub

    Private Sub llSaveExperimentAs_LinkClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles llSaveExperimentAs.LinkClicked
        RaiseEvent SaveExperimentAs(Me, New EventArgs)
    End Sub

    Private Sub llClose_LinkClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles llClose.LinkClicked
        RaiseEvent Close(Me, New EventArgs)
    End Sub

    Private Sub CPrpC_RequireSource(ByVal sender As Object, ByVal e As SourceEventArgs) Handles CPrpC.RequireSource
        RaiseEvent RequireSource(sender, e)
    End Sub
    Private Sub CPrpC_ValueChange(ByVal sender As Object, ByVal e As System.EventArgs) Handles CPrpC.ValueChange
        RaiseEvent ValueChange(Me, New EventArgs)
    End Sub
#End Region



    Private Sub reView_CloseTab(ByVal sender As Object, ByVal e As System.EventArgs) Handles reView.CloseTab
        CloseEnzymeTab()
    End Sub

    Private Sub reView_SetRestrictSite(ByVal sender As Object, ByVal e As RestrictionEnzymeView.RESiteEventArgs) Handles reView.SetRestrictSite
        RaiseEvent ManageEnzymes(Me, e)
    End Sub

    Public Event RequireEnzymeSite(ByVal sender As Object, ByVal e As RestrictionEnzymeView.RESiteEventArgs)

    Public ReadOnly Property Enzymes() As List(Of String)
        Get
            Dim e As New RestrictionEnzymeView.RESiteEventArgs
            RaiseEvent RequireEnzymeSite(Me, e)
            Return e.RESites
        End Get
    End Property

    Public ReadOnly Property Features() As List(Of Nuctions.Feature)
        Get
            Dim e As New FeatureEventArgs
            RaiseEvent ReqireFeatures(Me, e)
            Return e.Features
        End Get
    End Property

    Private Sub PrpC_ReqireFeatures(ByVal sender As Object, ByVal e As FeatureEventArgs) Handles PrpC.ReqireFeatures
        e.Features = Features
    End Sub

    Private Sub PrpC_RequireDNAView(ByVal sender As Object, ByVal e As DNAViewEventArgs) Handles PrpC.RequireDNAView
        If tcMain.TabPages.Contains(TPDNA) Then
            gvDNA.ShowGeneFiles(e.vDNAs, Enzymes)
        Else
            tcMain.TabPages.Add(TPDNA)
            gvDNA.ShowGeneFiles(e.vDNAs, Enzymes)
        End If
    End Sub

    Private Sub PrpC_RequireFeatureScreenView(ByVal sender As Object, ByVal e As System.EventArgs) Handles PrpC.RequireFeatureScreenView
        If PrpC.RelatedChartItem Is Nothing Then Exit Sub
        If tcMain.TabPages.Contains(TPFeatureScreen) Then
            Dim ci As ChartItem = PrpC.RelatedChartItem
            FSV.SetFeaturesInfo(ci.MolecularInfo.Screen_Features, Me.Features)
            TPFeatureScreen.Select()
        Else
            Dim ci As ChartItem = PrpC.RelatedChartItem
            FSV.SetFeaturesInfo(ci.MolecularInfo.Screen_Features, Me.Features)
            tcMain.TabPages.Add(TPFeatureScreen)
            TPFeatureScreen.Select()
        End If

    End Sub

    Private Sub PrpC_RequirePCRView(ByVal sender As Object, ByVal e As PCRViewEventArgs) Handles PrpC.RequirePCRView
        If tcMain.TabPages.Contains(TPPCR) Then
            gvPCR.ShowPCR(e.vDNAs, Enzymes, e.Primers)
        Else
            tcMain.TabPages.Add(TPPCR)
            gvPCR.ShowPCR(e.vDNAs, Enzymes, e.Primers)
        End If
    End Sub

    Private Sub gvPCR_PCR(ByVal sender As Object, ByVal e As PCREventArgs) Handles gvPCR.PCR
        Select Case PrpC.RelatedChartItem.MolecularInfo.MolecularOperation
            Case Nuctions.MolecularOperationEnum.PCR
                Select Case e.Target
                    Case "F"
                        PrpC.PCR_ForwardPrimer_TextBox.Text = e.Primer
                        PrpC.tbFP.Text = e.Key
                    Case "R"
                        PrpC.PCR_ReversePrimer_TextBox.Text = e.Primer
                        PrpC.tbRP.Text = e.Key
                End Select
            Case Nuctions.MolecularOperationEnum.Screen
                Select Case e.Target
                    Case "F"
                        PrpC.Screen_PCR_F.Text = e.Primer
                        PrpC.tbSCRFP.Text = e.Key
                    Case "R"
                        PrpC.Screen_PCR_R.Text = e.Primer
                        PrpC.tbSCRRP.Text = e.Key
                End Select
        End Select

    End Sub

    Private Sub gvPCR_SelectSequence(ByVal sender As Object, ByVal e As SelectEventArgs) Handles gvPCR.SelectSequence

    End Sub

    Public Event ReqireFeatures(ByVal sender As Object, ByVal e As FeatureEventArgs)

    Private Sub FMV_CloseTab(ByVal sender As Object, ByVal e As System.EventArgs) Handles FMV.CloseTab
        If tcMain.TabPages.Contains(TPFeature) Then
            tcMain.TabPages.Remove(TPFeature)
        End If
    End Sub

    Private Sub FMV_UpdateFeature(ByVal sender As Object, ByVal e As FeatureEventArgs) Handles FMV.UpdateFeature
        RaiseEvent ManageFeatures(Me, e)
    End Sub

    '
    Private Sub FSV_CloseTab(ByVal sender As Object, ByVal e As System.EventArgs) Handles FSV.CloseTab
        If tcMain.TabPages.Contains(TPFeatureScreen) Then
            tcMain.TabPages.Remove(TPFeatureScreen)
        End If
    End Sub

    Private Sub FSV_UpdateFeatures(ByVal sender As Object, ByVal e As FeatureScreenEventArgs) Handles FSV.UpdateFeatures
        PrpC.SetFeatureScreen(e.FeatureScreenInfos)
    End Sub

    Private Sub PrpC_RequireSelectDNAView(ByVal sender As Object, ByVal e As DNAViewEventArgs) Handles PrpC.RequireSelectDNAView
 
        If tcMain.Contains(TPDNA) Then
            gvDNA.ShowSelect(e.vDNAs, Enzymes)
            TPDNA.Select()
        Else
            tcMain.TabPages.Add(TPDNA)
            gvDNA.ShowSelect(e.vDNAs, Enzymes)
            TPDNA.Select()
        End If
    End Sub

    Private Sub gvDNA_SelectSequence(ByVal sender As Object, ByVal e As SelectEventArgs) Handles gvDNA.SelectSequence
        PrpC.AddEnzymeAnalysisSequence(e.GeneFile, e.Region)
    End Sub

    Public Function CopySelectSequence() As String
        If tcMain.SelectedTab Is TPDNA Then
            Return gvDNA.CopySequence
        ElseIf tcMain.SelectedTab Is TPPCR Then
            Return gvPCR.CopySequence
        Else
            Return ""
        End If
    End Function

    Public Event LoadSequenceEvent(ByVal sender As Object, ByVal e As LoadSequenceEventArgs)

    Private Sub llLoadSequence_LinkClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles llLoadSequence.LinkClicked
        Dim lse As New LoadSequenceEventArgs
        lse.Sequence = Nuctions.TAGCFilter(rtbSequence.Text)
        RaiseEvent LoadSequenceEvent(Me, lse)
        rtbSequence.Clear()
    End Sub

    Public Event ExportSummary(ByVal sender As Object, ByVal e As EventArgs)

    Private Sub llSummary_LinkClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.LinkLabelLinkClickedEventArgs)
        RaiseEvent ExportSummary(Me, New EventArgs)
    End Sub

    Public Event RemarkFeature(ByVal sender As Object, ByVal e As EventArgs)
    Private Sub llRemarkFeature_LinkClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles llRemarkFeature.LinkClicked
        RaiseEvent RemarkFeature(Me, New EventArgs)
    End Sub

    Public Sub ShowEnzymes()
        Dim stb As New System.Text.StringBuilder
        For Each ez As String In Enzymes
            stb.Append(ez)
            stb.Append(" ")
        Next
        lbEnzymes.Text = stb.ToString
    End Sub
    Public Event RequireSource(ByVal sender As Object, ByVal e As SourceEventArgs)

End Class

Public Class LoadSequenceEventArgs
    Inherits EventArgs
    Public Sequence As String
End Class
