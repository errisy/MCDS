﻿Public Class GroupViewer
    Public Sub ShowGeneFiles(ByVal gList As List(Of Nuctions.GeneFile), ByVal vRE As List(Of String))
        tcViewers.TabPages.Clear()
        For Each g As Nuctions.GeneFile In gList
            Dim tp As New CustomTabPage
            Dim sv As New SequenceViewer
            sv.RestrictionSites = vRE
            tp.Controls.Add(sv)
            tp.Text = g.Name
            tcViewers.TabPages.Add(tp)
            sv.Dock = DockStyle.Fill
            sv.ViewMode()
            sv.GeneFile = g
        Next
    End Sub
    Public Sub ShowPCR(ByVal gList As List(Of Nuctions.GeneFile), ByVal vRE As List(Of String), ByVal Primers As Dictionary(Of String, String))
        tcViewers.TabPages.Clear()
        For Each g As Nuctions.GeneFile In gList
            Dim tp As New CustomTabPage
            Dim sv As New SequenceViewer
            sv.RestrictionSites = vRE
            tp.Controls.Add(sv)
            tp.Text = g.Name
            tcViewers.TabPages.Add(tp)
            sv.Dock = DockStyle.Fill
            sv.PCREvent = AddressOf PassPCR
            sv.GeneFile = g
            sv.PCRMode(Primers)
        Next
    End Sub
    Public Sub ShowSelect(ByVal gList As List(Of Nuctions.GeneFile), ByVal vRE As List(Of String))
        tcViewers.TabPages.Clear()
        For Each g As Nuctions.GeneFile In gList
            Dim tp As New CustomTabPage
            Dim sv As New SequenceViewer
            sv.RestrictionSites = vRE
            tp.Controls.Add(sv)
            tp.Text = g.Name
            tcViewers.TabPages.Add(tp)
            sv.Dock = DockStyle.Fill
            sv.SelectMode()
            sv.SelectEvent = AddressOf PassSelectSequence
            sv.GeneFile = g
        Next
    End Sub

    Public Event SelectSequence(ByVal sender As Object, ByVal e As SelectEventArgs)
    Public Event PCR(ByVal sender As Object, ByVal e As PCREventArgs)

    Public Sub PassSelectSequence(ByVal e As SelectEventArgs)
        RaiseEvent SelectSequence(Me, e)
    End Sub
    Public Sub PassPCR(ByVal e As PCREventArgs)
        RaiseEvent PCR(Me, e)
    End Sub

    Public Function CopySequence() As String
        Dim tp As TabPage = tcViewers.SelectedTab
        If tp Is Nothing Then
            Return ""
        Else
            Dim sv As SequenceViewer = tp.Controls(0)
            Return sv.CopySelectedSequence()
        End If
    End Function
End Class

Public Class DNAViewEventArgs
    Inherits EventArgs
    Public Sub New()

    End Sub
    Public vDNAs As New List(Of Nuctions.GeneFile)
    Public Sub New(ByVal nDNAs As List(Of Nuctions.GeneFile))
        vDNAs = nDNAs
    End Sub
End Class

Public Class PCRViewEventArgs
    Inherits EventArgs
    Public Sub New()

    End Sub
    Public vDNAs As New List(Of Nuctions.GeneFile)
    Public Sub New(ByVal nDNAs As List(Of Nuctions.GeneFile), ByVal vPrimers As Dictionary(Of String, String))
        vDNAs = nDNAs
        Primers = vPrimers
    End Sub
    Public Primers As New Dictionary(Of String, String)
End Class

Public Delegate Sub PCREvent(ByVal e As PCREventArgs)
Public Delegate Sub SelectEvent(ByVal e As SelectEventArgs)

Public Class PCREventArgs
    Inherits EventArgs
    Public Key As String
    Public Primer As String
    Public Target As String
    Public Sub New()
    End Sub
    Public Sub New(ByVal vKey As String, ByVal vPrimer As String, ByVal vTarget As String)
        Key = vKey
        Primer = vPrimer
        Target = vTarget
    End Sub
End Class

Public Class SelectEventArgs
    Inherits EventArgs
    Public GeneFile As Nuctions.GeneFile
    Public Region As String
    Public Sub New()
    End Sub
    Public Sub New(ByVal vGeneFile As Nuctions.GeneFile, ByVal vRegion As String)
        GeneFile = vGeneFile
        Region = vRegion
    End Sub
End Class
