﻿Public Class PropertyControl
    Public vRelatedChartItem As ChartItem
    Public vMolecularOperation As Nuctions.MolecularOperationEnum
    Private mApplyMode As Boolean = False
    Private Result As Windows.Forms.DialogResult = Windows.Forms.DialogResult.Cancel
    '设置radiobutton组
    Private RBLig As New RadioButtonMap
    Private RBRec As New RadioButtonMap
    Private TPLib As New Dictionary(Of Nuctions.MolecularOperationEnum, TabPage)

    '所属的TC控件组
    Public ParentTC As TabControl

    '所控制的酶切位点视图
    Private WithEvents EnzymeControl As New RestrictionEnzymeView
    Private EnzymeTabPage As New CustomTabPage

    Public Event ValueChange(ByVal sender As Object, ByVal e As EventArgs)

    Public Sub New()

        ' 此调用是 Windows 窗体设计器所必需的。
        InitializeComponent()

        ' 在 InitializeComponent() 调用之后添加任何初始化。
        RBLig.Add(LigationMethod.Normal2Fragment, rbLig2)
        RBLig.Add(LigationMethod.Consider3Fragment, rbLig3)
        RBLig.Add(LigationMethod.MultipleFragmentUnique, rbLigM)

        RBRec.Add(RecombinationMethod.Homologous, rbRecHomologous)
        RBRec.Add(RecombinationMethod.LambdaRecombination, rbRecLambda)
        RBRec.Add(RecombinationMethod.LambdaAttBP, rbRecLambdaBP)
        RBRec.Add(RecombinationMethod.LambdaAttLR, rbRecLambdaLR)
        RBRec.Add(RecombinationMethod.HK022AttBP, rbRecHK022BP)
        RBRec.Add(RecombinationMethod.HK022AttLR, rbRecHK022LR)
        RBRec.Add(RecombinationMethod.Phi80AttBP, rbRecPhi80BP)
        RBRec.Add(RecombinationMethod.Phi80AttLR, rbRecPhi80LR)
        RBRec.Add(RecombinationMethod.P21AttBP, rbRecP21BP)
        RBRec.Add(RecombinationMethod.P21AttLR, rbRecP21LR)
        RBRec.Add(RecombinationMethod.P22AttBP, rbRecP22BP)
        RBRec.Add(RecombinationMethod.P22AttLR, rbRecP22LR)
        RBRec.Add(RecombinationMethod.FRT, rbFRT)
        RBRec.Add(RecombinationMethod.LoxP, rbLoxP)

        For Each rb As RadioButton In RBRec.Values
            AddHandler rb.CheckedChanged, AddressOf Me.rbRec_CheckedChanged
        Next

        TPLib.Add(Nuctions.MolecularOperationEnum.Vector, TabControl_Operation.TabPages(Nuctions.MolecularOperationEnum.Vector))
        TPLib.Add(Nuctions.MolecularOperationEnum.Enzyme, TabControl_Operation.TabPages(Nuctions.MolecularOperationEnum.Enzyme))
        TPLib.Add(Nuctions.MolecularOperationEnum.PCR, TabControl_Operation.TabPages(Nuctions.MolecularOperationEnum.PCR))
        TPLib.Add(Nuctions.MolecularOperationEnum.Modify, TabControl_Operation.TabPages(Nuctions.MolecularOperationEnum.Modify))
        TPLib.Add(Nuctions.MolecularOperationEnum.Gel, TabControl_Operation.TabPages(Nuctions.MolecularOperationEnum.Gel))
        TPLib.Add(Nuctions.MolecularOperationEnum.Ligation, TabControl_Operation.TabPages(Nuctions.MolecularOperationEnum.Ligation))
        TPLib.Add(Nuctions.MolecularOperationEnum.Recombination, TabControl_Operation.TabPages(Nuctions.MolecularOperationEnum.Recombination))
        TPLib.Add(Nuctions.MolecularOperationEnum.Screen, TabControl_Operation.TabPages(Nuctions.MolecularOperationEnum.Screen))
        TPLib.Add(Nuctions.MolecularOperationEnum.EnzymeAnalysis, TabControl_Operation.TabPages(Nuctions.MolecularOperationEnum.EnzymeAnalysis))
        TPLib.Add(Nuctions.MolecularOperationEnum.Merge, TabControl_Operation.TabPages(Nuctions.MolecularOperationEnum.Merge))
        TPLib.Add(Nuctions.MolecularOperationEnum.Compare, TabControl_Operation.TabPages(Nuctions.MolecularOperationEnum.Compare))

        TabControl_Operation.TabPages.Clear()

        EnzymeTabPage.Controls.Add(EnzymeControl)
        With EnzymeTabPage
            .FontColor = Color.GreenYellow
            .SelectedFontColor = Color.Green
            .SelectedGrad1Color = Color.LightYellow
            .SelectedGrad2Color = Color.Pink
            .Grad1Color = Color.Tomato
            .Grad2Color = Color.Purple
            .SelectBorderColor = Color.Pink
            .BorderColor = Color.Purple
        End With
 
        EnzymeControl.Dock = DockStyle.Fill
        EnzymeTabPage.BackgroundImageLayout = ImageLayout.Stretch
        EnzymeTabPage.BackgroundImage = My.Resources.grad2
        EnzymeTabPage.Text = "Restriction Enzymes for Digestion"
    End Sub

    Public Property RelatedChartItem() As ChartItem
        Get
            Return vRelatedChartItem
        End Get
        Set(ByVal value As ChartItem)
            If value Is Nothing Then
                Me.TabControl_Operation.TabPages.Clear()
            Else
                Me.TabControl_Operation.TabPages.Clear()
                TabControl_Operation.TabPages.Add(TPLib(value.MolecularInfo.MolecularOperation))
                vRelatedChartItem = value
                '确定采取何种操作
                MolecularOperation = value.MolecularInfo.MolecularOperation
                '保留克隆用于取消操作
                DNACopy = value.MolecularInfo.Backup
                '加载信息

                Reload()
            End If
        End Set
    End Property

    <System.ComponentModel.Browsable(False)> Public Property MolecularOperation() As Nuctions.MolecularOperationEnum
        Get
            Return Me.vMolecularOperation
        End Get
        Set(ByVal value As Nuctions.MolecularOperationEnum)
            vMolecularOperation = value
            ''prepare the window for a specific operation
            'Me.TabControl_Operation.SelectedIndex = value
            Me.TabControl_Operation.TabPages.Clear()
            Me.TabControl_Operation.TabPages.Add(TPLib(value))
        End Set
    End Property

    Public Event RequireSource(ByVal sender As Object, ByVal e As SourceEventArgs)

    Private Sub Prop_Operation_LinkClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles Prop_Operation.LinkClicked
        'deal with source
        Select Case RelatedChartItem.MolecularInfo.MolecularOperation
            Case Nuctions.MolecularOperationEnum.Vector

            Case Else
                Prop_Operation.LinkColor = Color.Green
                Dim sea As New SourceEventArgs
                sea.Target = Me.RelatedChartItem.MolecularInfo
                RaiseEvent RequireSource(Me, sea)
        End Select

    End Sub

    Public Sub SetSource()
        Prop_Operation.LinkColor = Color.Red
        RefreshOperationView()
        ApplyMode = True
    End Sub

    Private Sub RefreshOperationView()
        Dim ui As DNAInfo
        Dim sourcetext As String = ""
        Select Case RelatedChartItem.MolecularInfo.MolecularOperation
            Case Nuctions.MolecularOperationEnum.Vector
                sourcetext = "[N/A]"
            Case Else
                For Each ui In Me.RelatedChartItem.MolecularInfo.Source
                    sourcetext &= ui.Name + ";"
                Next
                If sourcetext.Length = 0 Then sourcetext = "[Click to select]"
        End Select
        Me.Prop_Operation.Text = sourcetext
        Setting_finished = True
        Select Case RelatedChartItem.MolecularInfo.Progress
            Case ProgressEnum.Unstarted
                rbUnstarted.Checked = True
            Case ProgressEnum.Inprogress
                rbInprogress.Checked = True
            Case ProgressEnum.Finished
                rbFinished.Checked = True
        End Select
        Setting_finished = False
        'notify that there are suspended operations.
    End Sub

    Private Sub btn_OK_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        'check the name
        Accept()
    End Sub
    Private Sub ChangeValue()
        RaiseEvent ValueChange(Me, New EventArgs)
    End Sub
    Public Sub Accept()
        If ApplyMode Then
            Select Case Me.MolecularOperation
                Case Nuctions.MolecularOperationEnum.Enzyme
                    'get the vectors from source and analyze enzyme cutting.
                    Dim gf As Nuctions.GeneFile
                    Dim EARC As Nuctions.EnzymeAnalysis.EnzymeAnalysisResult
                    Dim earcCol As New Collection
                    Dim info As String
                    Dim infoQ As New Queue(Of String)
                    Dim dnaList As List(Of Nuctions.GeneFile)
                    Dim DNA As Nuctions.GeneFile

                    Dim SourceDNA As New Collection
                    For Each mi As DNAInfo In Me.RelatedChartItem.MolecularInfo.Source
                        For Each gf In mi.DNAs
                            SourceDNA.Add(gf)
                        Next
                    Next
                    For Each gf In SourceDNA
                        EARC = New Nuctions.EnzymeAnalysis.EnzymeAnalysisResult(Me.RelatedChartItem.MolecularInfo.Enzyme_Enzymes, gf)
                        For Each info In EARC.Confliction
                            infoQ.Enqueue(info)
                        Next
                        earcCol.Add(EARC)
                    Next
                    If infoQ.Count = 0 Then
                        If RelatedChartItem.MolecularInfo.DNAs.Count > 0 Then RelatedChartItem.MolecularInfo.DNAs.Clear()
                        For Each EARC In earcCol
                            dnaList = EARC.CutDNA()
                            For Each DNA In dnaList
                                Me.RelatedChartItem.MolecularInfo.DNAs.Add(DNA)
                            Next
                        Next
                        Nuctions.AddFeatures(Me.RelatedChartItem.MolecularInfo.DNAs, Features)
                        'refresh the DNA view:
                        RefreshDNAView()
                        Me.Result = Windows.Forms.DialogResult.OK
                        'Me.Prop_Name.Text = "(" + Me.RelatedChartItem.ListView.Items.Count.ToString() + ")"

                        Dim vn As String = ""

                        For Each ez As String In Me.RelatedChartItem.MolecularInfo.Enzyme_Enzymes
                            vn += ez + " "
                        Next
                        Me.Prop_Name.Text = vn
                        'Me.RelatedChartItem.MolecularInfo.OperationDescription = Me.rtb_Description.Text
                        Me.ApplyMode = False
                        ChangeValue()
                        Me.RelatedChartItem.MolecularInfo.Calculated = True

                    Else
                        infoQ.Enqueue("Failed to Cut the vectors")
                        Dim fER As New frmErrorReport
                        fER.ShowDialog(infoQ, Me)
                    End If
                Case Nuctions.MolecularOperationEnum.Gel
                    Dim gelErr As Boolean = False
                    Dim errQ As New Queue(Of String)
                    If Me.Gel_Minimum_Number.Value < 100 Then gelErr = True : errQ.Enqueue("Minimum Value should be over 100")
                    If Me.Gel_Minimum_Number.Value > Me.Gel_Maximum_Number.Value Then gelErr = True : errQ.Enqueue("Minimun Value should be smaller than Maximum Value")
                    If Not gelErr Then
                        Dim gf As Nuctions.GeneFile
                        Dim gfCol As New Collection

                        'get all the DNAs
                        For Each mi As DNAInfo In Me.RelatedChartItem.MolecularInfo.Source
                            For Each gf In mi.DNAs
                                gfCol.Add(gf)
                            Next
                        Next
                        Me.RelatedChartItem.MolecularInfo.Gel_Maximun = Me.Gel_Maximum_Number.Value
                        Me.RelatedChartItem.MolecularInfo.Gel_Minimum = Me.Gel_Minimum_Number.Value
                        Dim gelCol As List(Of Nuctions.GeneFile) = Nuctions.ScreenLength(gfCol, Me.RelatedChartItem.MolecularInfo.Gel_Minimum, Me.RelatedChartItem.MolecularInfo.Gel_Maximun)
                        If Me.RelatedChartItem.MolecularInfo.DNAs.Count > 0 Then Me.RelatedChartItem.MolecularInfo.DNAs.Clear()
                        For Each gf In gelCol
                            Me.RelatedChartItem.MolecularInfo.DNAs.Add(gf)
                        Next
                        Nuctions.AddFeatures(Me.RelatedChartItem.MolecularInfo.DNAs, Features)
                        RefreshDNAView()
                        Me.Prop_Name.Text = Me.Gel_Minimum_Number.Value.ToString + " to " + Me.Gel_Maximum_Number.Value.ToString
                        Me.Result = Windows.Forms.DialogResult.OK
                        'Me.RelatedChartItem.MolecularInfo.OperationDescription = Me.rtb_Description.Text
                        ApplyMode = False
                        ChangeValue()
                        Me.RelatedChartItem.MolecularInfo.Calculated = True

                    Else
                        Dim fErr As New frmErrorReport
                        fErr.ShowDialog(errQ, Me)
                    End If
                Case Nuctions.MolecularOperationEnum.Ligation
                    Dim gf As Nuctions.GeneFile
                    Dim gfCol As New List(Of Nuctions.GeneFile)

                    'get all the DNAs
                    For Each mi As DNAInfo In Me.RelatedChartItem.MolecularInfo.Source
                        For Each gf In mi.DNAs
                            gfCol.Add(gf)
                        Next
                    Next
                    'ligate

                    Me.RelatedChartItem.MolecularInfo.Ligation_TriFragment = RBLig.Value

                    Dim lgCol As List(Of Nuctions.GeneFile) = Nothing

                    Select Case Me.RelatedChartItem.MolecularInfo.Ligation_TriFragment
                        Case LigationMethod.Normal2Fragment
                            lgCol = Nuctions.LigateDNA(gfCol, False)

                        Case LigationMethod.Consider3Fragment
                            lgCol = Nuctions.LigateDNA(gfCol, True)
                        Case LigationMethod.MultipleFragmentUnique
                            lgCol = Nuctions.MultipleLinearLigate(gfCol)
                    End Select
                    'If cbML.Checked Then
                    '    lgCol = Nuctions.MultipleLinearLigate(gfCol)
                    'Else
                    '    lgCol = Nuctions.LigateDNA(gfCol, Me.RelatedChartItem.MolecularInfo.Ligation_TriFragment)
                    'End If
                    If Me.RelatedChartItem.MolecularInfo.DNAs.Count > 0 Then Me.RelatedChartItem.MolecularInfo.DNAs.Clear()
                    For Each gf In lgCol
                        Me.RelatedChartItem.MolecularInfo.DNAs.Add(gf)
                    Next
                    Nuctions.AddFeatures(Me.RelatedChartItem.MolecularInfo.DNAs, Features)
                    RefreshLigationView()
                    RefreshDNAView()
                    'Me.RelatedChartItem.MolecularInfo.OperationDescription = Me.rtb_Description.Text
                    Me.Result = Windows.Forms.DialogResult.OK
                    Me.ApplyMode = False
                    ChangeValue()
                    Me.RelatedChartItem.MolecularInfo.Calculated = True

                Case Nuctions.MolecularOperationEnum.Modify
                    If Me.Modify_CIAP.Checked Then Me.RelatedChartItem.MolecularInfo.Modify_Method = Nuctions.ModificationMethodEnum.CIAP
                    If Me.Modify_Klewnow.Checked Then Me.RelatedChartItem.MolecularInfo.Modify_Method = Nuctions.ModificationMethodEnum.Klewnow
                    If Me.Modify_PNK.Checked Then Me.RelatedChartItem.MolecularInfo.Modify_Method = Nuctions.ModificationMethodEnum.PNK
                    If Me.Modify_T4.Checked Then Me.RelatedChartItem.MolecularInfo.Modify_Method = Nuctions.ModificationMethodEnum.T4DNAP
                    Dim gf As Nuctions.GeneFile
                    Dim gfCol As New Collection
                    'get all the DNAs
                    For Each mi As DNAInfo In Me.RelatedChartItem.MolecularInfo.Source
                        For Each gf In mi.DNAs
                            gfCol.Add(gf)
                        Next
                    Next
                    Dim lgCol As List(Of Nuctions.GeneFile) = Nuctions.ModifyDNA(gfCol, Me.RelatedChartItem.MolecularInfo.Modify_Method)
                    If Me.RelatedChartItem.MolecularInfo.DNAs.Count > 0 Then Me.RelatedChartItem.MolecularInfo.DNAs.Clear()
                    For Each gf In lgCol
                        Me.RelatedChartItem.MolecularInfo.DNAs.Add(gf)
                    Next
                    Nuctions.AddFeatures(Me.RelatedChartItem.MolecularInfo.DNAs, Features)
                    Me.Result = Windows.Forms.DialogResult.OK
                    Me.ApplyMode = False
                    RefreshModifyView()
                    'Me.RelatedChartItem.MolecularInfo.OperationDescription = Me.rtb_Description.Text
                    RefreshDNAView()
                    ChangeValue()
                    Me.RelatedChartItem.MolecularInfo.Calculated = True

                Case Nuctions.MolecularOperationEnum.PCR
                    Dim errQ As New Queue(Of String)
                    Dim pcrErr As Boolean = False

                    'Me.RelatedChartItem.MolecularInfo.PCR_ForwardPrimer = FPrimer
                    'Me.RelatedChartItem.MolecularInfo.PCR_ReversePrimer = RPrimer
                    If tbFP.Text = tbRP.Text Then
                        tbFP.Text += "F"
                        tbRP.Text += "R"
                    End If
                    Dim fp As String = PCR_ForwardPrimer_TextBox.Text
                    Dim rp As String = PCR_ReversePrimer_TextBox.Text
                    Dim idx As Integer
                    idx = fp.LastIndexOf(">")
                    If idx > -1 Then
                        PCR_ForwardPrimer_TextBox.Text = Nuctions.TAGCFilter(fp.Substring(0, idx)) + ">" + Nuctions.TAGCFilter(fp.Substring(idx, fp.Length - idx))
                    Else
                        PCR_ForwardPrimer_TextBox.Text = Nuctions.TAGCFilter(PCR_ForwardPrimer_TextBox.Text)
                    End If
                    idx = rp.LastIndexOf(">")
                    If idx > -1 Then
                        PCR_ReversePrimer_TextBox.Text = Nuctions.TAGCFilter(rp.Substring(0, idx)) + ">" + Nuctions.TAGCFilter(rp.Substring(idx, rp.Length - idx))
                    Else
                        PCR_ReversePrimer_TextBox.Text = Nuctions.TAGCFilter(PCR_ReversePrimer_TextBox.Text)
                    End If
                    Me.RelatedChartItem.MolecularInfo.PCR_FPrimerName = tbFP.Text
                    Me.RelatedChartItem.MolecularInfo.PCR_ForwardPrimer = PCR_ForwardPrimer_TextBox.Text

                    Me.RelatedChartItem.MolecularInfo.PCR_RPrimerName = tbRP.Text
                    Me.RelatedChartItem.MolecularInfo.PCR_ReversePrimer = PCR_ReversePrimer_TextBox.Text

                    'Me.PCR_ForwardPrimer_TextBox.Text = FPrimer
                    'Me.PCR_ReversePrimer_TextBox.Text = RPrimer
                    'If FPrimer.Length < 12 Then pcrErr = True : errQ.Enqueue("Forward Primer is shorter than 12 bp")
                    'If RPrimer.Length < 12 Then pcrErr = True : errQ.Enqueue("Reverse Primer is shorter than 12 bp")
                    If Not pcrErr Then
                        Dim gf As Nuctions.GeneFile
                        Dim gfCol As New Collection

                        'get all the DNAs
                        For Each mi As DNAInfo In Me.RelatedChartItem.MolecularInfo.Source
                            For Each gf In mi.DNAs
                                gfCol.Add(gf)
                            Next
                        Next
                        Dim pmrList As New List(Of String)
                        pmrList.Add(Nuctions.TAGCFilter(Me.RelatedChartItem.MolecularInfo.PCR_ForwardPrimer))
                        pmrList.Add(Nuctions.TAGCFilter(Me.RelatedChartItem.MolecularInfo.PCR_ReversePrimer))
                        Dim gfList As List(Of Nuctions.GeneFile) = Nuctions.PCR(gfCol, pmrList)
                        If Me.RelatedChartItem.MolecularInfo.DNAs.Count > 0 Then Me.RelatedChartItem.MolecularInfo.DNAs.Clear()
                        For Each gf In gfList
                            Me.RelatedChartItem.MolecularInfo.DNAs.Add(gf)
                        Next
                        Nuctions.AddFeatures(Me.RelatedChartItem.MolecularInfo.DNAs, Features)
                        Me.Result = Windows.Forms.DialogResult.OK
                        RefreshDNAView()
                        ApplyMode = False
                        'Me.RelatedChartItem.MolecularInfo.OperationDescription = Me.rtb_Description.Text
                        ChangeValue()
                        Me.RelatedChartItem.MolecularInfo.Calculated = True

                    Else
                        Dim fErr As New frmErrorReport
                        fErr.ShowDialog(errQ, Me)
                    End If
                Case Nuctions.MolecularOperationEnum.Screen
                    Dim gf As Nuctions.GeneFile
                    Dim gfCol As New Collection

                    'get all the DNAs
                    If Me.Screen_Freatures.Checked Then
                        Me.RelatedChartItem.MolecularInfo.Screen_Mode = Nuctions.ScreenModeEnum.Features
                        For Each mi As DNAInfo In Me.RelatedChartItem.MolecularInfo.Source
                            For Each gf In mi.DNAs
                                gfCol.Add(gf)
                            Next
                        Next
                        Dim gfList As List(Of Nuctions.GeneFile) = Nuctions.ScreenFeature(gfCol, Me.RelatedChartItem.MolecularInfo.Screen_Features, Me.RelatedChartItem.MolecularInfo.Screen_OnlyCircular)
                        If Me.RelatedChartItem.MolecularInfo.DNAs.Count > 0 Then Me.RelatedChartItem.MolecularInfo.DNAs.Clear()
                        For Each gf In gfList
                            Me.RelatedChartItem.MolecularInfo.DNAs.Add(gf)
                        Next
                        'Screen needs not additional features
                        Nuctions.AddFeatures(Me.RelatedChartItem.MolecularInfo.DNAs, Features)
                        Me.Result = Windows.Forms.DialogResult.OK
                        Me.ApplyMode = False
                        RefreshScreenView()
                        Dim fts As New System.Text.StringBuilder
                        fts.Append("Screen for")
                        For Each fsi As FeatureScreenInfo In Me.RelatedChartItem.MolecularInfo.Screen_Features
                            fts.Append(" ")
                            fts.Append(fsi.Feature.Name)
                        Next
                        Me.Prop_Name.Text = fts.ToString
                        'Me.RelatedChartItem.MolecularInfo.OperationDescription = Me.rtb_Description.Text
                        RefreshDNAView()
                        ChangeValue()
                        Me.RelatedChartItem.MolecularInfo.Calculated = True

                    Else
                        Me.RelatedChartItem.MolecularInfo.Screen_Mode = Nuctions.ScreenModeEnum.PCR
                        Dim errQ As New Queue(Of String)
                        Dim scrErr As Boolean = False
                        Dim FPrimer As String = Nuctions.TAGCFilter(Me.Screen_PCR_F.Text)
                        Dim RPrimer As String = Nuctions.TAGCFilter(Me.Screen_PCR_R.Text)
                        Me.PCR_ForwardPrimer_TextBox.Text = FPrimer
                        Me.PCR_ReversePrimer_TextBox.Text = RPrimer
                        Me.RelatedChartItem.MolecularInfo.Screen_FName = tbSCRFP.Text
                        Me.RelatedChartItem.MolecularInfo.Screen_RName = tbSCRRP.Text
                        If FPrimer.Length < 12 Then scrErr = True : errQ.Enqueue("Forward Primer is shorter than 12 bp")
                        If RPrimer.Length < 12 Then scrErr = True : errQ.Enqueue("Reverse Primer is shorter than 12 bp")
                        If Me.Screen_PCR_nudMin.Value < 100 Then scrErr = True : errQ.Enqueue("Minimum Value should be over 100")
                        If Me.Screen_PCR_nudMin.Value > Me.Screen_PCR_nudMax.Value Then scrErr = True : errQ.Enqueue("Minimun Value should be smaller than Maximum Value")
                        'process the PCR Screen
                        With Me.RelatedChartItem.MolecularInfo
                            .Screen_FPrimer = FPrimer
                            .Screen_RPrimer = RPrimer
                            .Screen_PCRMax = Me.Screen_PCR_nudMax.Value
                            .Screen_PCRMin = Me.Screen_PCR_nudMin.Value
                            .Screen_Mode = Nuctions.ScreenModeEnum.PCR
                        End With
                        If scrErr Then
                        Else

                            For Each mi As DNAInfo In Me.RelatedChartItem.MolecularInfo.Source
                                For Each gf In mi.DNAs
                                    gfCol.Add(gf)
                                Next
                            Next
                            Dim gfList As List(Of Nuctions.GeneFile) = Nuctions.ScreenPCR(gfCol, Me.RelatedChartItem.MolecularInfo.Screen_FPrimer, Me.RelatedChartItem.MolecularInfo.Screen_RPrimer, Me.RelatedChartItem.MolecularInfo.Screen_PCRMax, Me.RelatedChartItem.MolecularInfo.Screen_PCRMin, Me.RelatedChartItem.MolecularInfo.Screen_OnlyCircular)
                            If Me.RelatedChartItem.MolecularInfo.DNAs.Count > 0 Then Me.RelatedChartItem.MolecularInfo.DNAs.Clear()
                            For Each gf In gfList
                                Me.RelatedChartItem.MolecularInfo.DNAs.Add(gf)
                            Next
                            Nuctions.AddFeatures(Me.RelatedChartItem.MolecularInfo.DNAs, Features)
                            Me.Result = Windows.Forms.DialogResult.OK
                            Me.ApplyMode = False
                            RefreshScreenView()
                            Dim fts As New System.Text.StringBuilder
                            fts.Append("Screen PCR ")
                            fts.Append(Me.Screen_PCR_nudMin.Value.ToString)
                            fts.Append(" to ")
                            fts.Append(Me.Screen_PCR_nudMax.Value.ToString)
                            Me.Prop_Name.Text = fts.ToString
                            'Me.RelatedChartItem.MolecularInfo.OperationDescription = Me.rtb_Description.Text
                            RefreshDNAView()
                            ChangeValue()
                            Me.RelatedChartItem.MolecularInfo.Calculated = True

                        End If
                    End If
                Case Nuctions.MolecularOperationEnum.Vector
                
                Case Nuctions.MolecularOperationEnum.Recombination
                    Me.RelatedChartItem.MolecularInfo.RecombinationMethod = RBRec.Value
                    Dim gList As New List(Of Nuctions.GeneFile)
                    For Each mi As DNAInfo In Me.RelatedChartItem.MolecularInfo.Source
                        For Each gf As Nuctions.GeneFile In mi.DNAs
                            gList.Add(gf.CloneWithoutFeatures)
                        Next
                    Next
                    Dim rList As List(Of Nuctions.GeneFile)
                    rList = Nuctions.Recombination(gList, Me.RelatedChartItem.MolecularInfo.RecombinationMethod)
                    Me.RelatedChartItem.MolecularInfo.DNAs.Clear()
                    For Each gf As Nuctions.GeneFile In rList
                        Me.RelatedChartItem.MolecularInfo.DNAs.Add(gf)
                    Next
                    Nuctions.AddFeatures(Me.RelatedChartItem.MolecularInfo.DNAs, Features)
                    Me.ApplyMode = False
                    RefreshDNAView()
                    ChangeValue()
                    Me.RelatedChartItem.MolecularInfo.Calculated = True
                Case Nuctions.MolecularOperationEnum.EnzymeAnalysis
                    Me.RelatedChartItem.MolecularInfo.EnzymeAnalysisParamters = ReadEnzymeAnalysisItems()
                    Me.RelatedChartItem.MolecularInfo.FetchedEnzymes = Nuctions.FindEnzymes(Me.RelatedChartItem.MolecularInfo.EnzymeAnalysisParamters)
                    Dim stb As New System.Text.StringBuilder
                    For Each enzm As String In Me.RelatedChartItem.MolecularInfo.FetchedEnzymes
                        stb.Append(enzm)
                        stb.Append(" ")
                    Next
                    Me.RelatedChartItem.MolecularInfo.OperationDescription = stb.ToString
                    rtb_Description.Text = Me.RelatedChartItem.MolecularInfo.OperationDescription
                    ApplyMode = False
                    ChangeValue()
                    Me.RelatedChartItem.MolecularInfo.Calculated = True
                Case Nuctions.MolecularOperationEnum.Merge
                    Me.RelatedChartItem.MolecularInfo.RecombinationMethod = RBRec.Value
                    Dim gList As New List(Of Nuctions.GeneFile)
                    For Each mi As DNAInfo In Me.RelatedChartItem.MolecularInfo.Source
                        For Each gf As Nuctions.GeneFile In mi.DNAs
                            gList.Add(gf.CloneWithoutFeatures)
                        Next
                    Next
                    Dim rList As List(Of Nuctions.GeneFile)
                    rList = Nuctions.MergeSequence(gList, RelatedChartItem.MolecularInfo.OnlySignificant, RelatedChartItem.MolecularInfo.OnlyExtend)
                    Me.RelatedChartItem.MolecularInfo.DNAs.Clear()
                    For Each gf As Nuctions.GeneFile In rList
                        Me.RelatedChartItem.MolecularInfo.DNAs.Add(gf)
                    Next
                    Nuctions.AddFeatures(Me.RelatedChartItem.MolecularInfo.DNAs, Features)
                    Me.ApplyMode = False
                    RefreshDNAView()
                    ChangeValue()
                    Me.RelatedChartItem.MolecularInfo.Calculated = True
            End Select
            RelatedChartItem.Reload(RelatedChartItem.MolecularInfo, Me.RelatedChartItem.Parent.EnzymeCol)
            Me.RelatedChartItem.Parent.Draw()
        Else
        End If
    End Sub

    Private DNACopy As DNAInfo

    Private Sub Reload()
        Dim ci As ChartItem = vRelatedChartItem
        'prevent the selection of itemself
        ci.MolecularInfo.Editing = True

        'General Information
        'Me.MolecularOperation = ci.MolecularInfo.MolecularOperation

        Dim sourcetext As String = ""
        For Each mi As DNAInfo In Me.RelatedChartItem.MolecularInfo.Source
            sourcetext &= mi.Name + ";"
        Next
        desSetting = True
        Me.rtb_Description.Text = Me.RelatedChartItem.MolecularInfo.OperationDescription
        desSetting = False
        pxkSetting = True
        cbRealSize.Checked = RelatedChartItem.MolecularInfo.RealSize
        pxkSetting = False
        If ci.MolecularInfo.Creating Then
            Me.Prop_Name.Text = ci.MolecularInfo.MolecularOperation.ToString + " " + " (" + sourcetext + ")"
            Me.Prop_Type.Text = "N/D"
            Me.Prop_Count.Text = "N/D"
            ApplyMode = True
        Else
            Me.Prop_Name.Text = ci.MolecularInfo.Name
            If ci.MolecularInfo.DNAs.Count > 1 Then
                Me.Prop_Type.Text = "Blend"
                Me.Prop_Count.Text = ci.MolecularInfo.DNAs.Count.ToString
            Else
                Me.Prop_Type.Text = "Pure"
                Me.Prop_Count.Text = ci.MolecularInfo.DNAs.Count.ToString
            End If
        End If

        'Special Information
        Select Case ci.MolecularInfo.MolecularOperation
            Case Nuctions.MolecularOperationEnum.Vector
                RefreshVectorView()
            Case Nuctions.MolecularOperationEnum.Enzyme
                RefreshEnzymeView()
            Case Nuctions.MolecularOperationEnum.Gel
                RefreshGelView()
            Case Nuctions.MolecularOperationEnum.Ligation
                RefreshLigationView()
            Case Nuctions.MolecularOperationEnum.Modify
                RefreshModifyView()
            Case Nuctions.MolecularOperationEnum.PCR
                RefreshPCRView()
            Case Nuctions.MolecularOperationEnum.Screen
                RefreshScreenView()
            Case Nuctions.MolecularOperationEnum.Recombination
                RefreshRecombinationView()
            Case Nuctions.MolecularOperationEnum.EnzymeAnalysis
                RefreshEnzymeAnalysisView()
            Case Nuctions.MolecularOperationEnum.Merge
                RefreshMerge()
        End Select
        RefreshOperationView()
        RefreshDNAView()
        'prevent the applymode if not creating
        If Not Me.RelatedChartItem.MolecularInfo.Creating Then Me.ApplyMode = False

        ApplyMode = Not RelatedChartItem.MolecularInfo.Calculated
    End Sub


    Public Sub RefreshRecombinationView()
        rbRecSetting = True
        RBRec.Value = Me.RelatedChartItem.MolecularInfo.RecombinationMethod
        rbRecSetting = False
    End Sub


    Private Sub Enzyme_Enzymes_LinkLabel_LinkClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles Enzyme_Enzymes_LinkLabel.LinkClicked
        EnzymeControl.LoadEnzymeItems(frmMain.EnzymeCol, RelatedChartItem.MolecularInfo.Enzyme_Enzymes)
        If Me.ParentTC.TabPages.Contains(EnzymeTabPage) Then
            ParentTC.SelectedTab = EnzymeTabPage
        Else
            Me.ParentTC.TabPages.Add(EnzymeTabPage)
            ParentTC.SelectedTab = EnzymeTabPage
        End If
    End Sub


    Public Sub SetEnzymes(ByVal SelCol As List(Of String))
        Me.RelatedChartItem.MolecularInfo.Enzyme_Enzymes = SelCol
        RefreshEnzymeView()
        ApplyMode = True
    End Sub

    Public Sub HideEnzymeTab()
        Me.ParentTC.TabPages.Remove(EnzymeTabPage)
    End Sub

    Private Sub RefreshEnzymeView()
        Dim ei As String
        Dim sourcetext As String = ""
        For Each ei In Me.RelatedChartItem.MolecularInfo.Enzyme_Enzymes
            sourcetext &= ei + " "
        Next
        enzSetting = True
        tbEnzymes.Text = sourcetext
        enzSetting = False
        If sourcetext.Length = 0 Then sourcetext = "[Click to select]"
        Me.Enzyme_Enzymes_LinkLabel.Text = sourcetext


        'notify that there are suspended operations.
    End Sub

    Public Property ApplyMode() As Boolean
        Get
            Return mApplyMode
        End Get
        Set(ByVal value As Boolean)
            mApplyMode = value
        End Set
    End Property

    Private Sub lv_DNA_DoubleClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles DNAView.DoubleClick
        For Each li As ListViewItem In DNAView.SelectedItems
            frmMain.AddDNAViewTab(li.Tag, RelatedChartItem.Parent.EnzymeCol)
        Next
    End Sub
    Private Sub RefreshDNAView()
        Dim dna As Nuctions.GeneFile
        Dim ci As ListViewItem
        If DNAView.Items.Count > 0 Then DNAView.Items.Clear()
        For Each dna In Me.RelatedChartItem.MolecularInfo.DNAs
            ci = New ListViewItem
            ci.Name = dna.Name
            ci.Text = dna.Name
            ci.Tag = dna
            ci.ImageIndex = Me.RelatedChartItem.MolecularInfo.MolecularOperation
            ci.SubItems.Add(dna.Sequence.Length.ToString)
            ci.SubItems.Add(IIf(dna.Iscircular, "Circular", "Linear"))
            ci.SubItems.Add(dna.End_F)
            ci.SubItems.Add(dna.End_R)
            DNAView.Items.Add(ci)
        Next
        Me.Prop_Count.Text = Me.RelatedChartItem.MolecularInfo.DNAs.Count.ToString
        Me.Prop_Type.Text = IIf(Me.RelatedChartItem.MolecularInfo.DNAs.Count > 1, "Blend", "Pure")
    End Sub
    Private Sub RefreshVectorView()
        If (Not (Me.RelatedChartItem.MolecularInfo.File_Filename Is Nothing)) AndAlso Me.RelatedChartItem.MolecularInfo.File_Filename.Length > 0 OrElse IO.File.Exists(Me.RelatedChartItem.MolecularInfo.File_Filename) Then
            Try
                Dim fn As IO.FileInfo = New IO.FileInfo(Me.RelatedChartItem.MolecularInfo.File_Filename)
                Me.File_FileName_LinkLabel.Text = fn.Name
                Me.File_Path_Label.Text = fn.FullName
            Catch ex As Exception

            End Try
        Else
            Me.File_FileName_LinkLabel.Text = "<No File>"
            Me.File_Path_Label.Text = "<No File>"
        End If
    End Sub
    Private Sub RefreshLigationView()
        RBLig.Value = Me.RelatedChartItem.MolecularInfo.Ligation_TriFragment
    End Sub
    Private Sub RefreshScreenView()
        If Me.RelatedChartItem.MolecularInfo.Screen_Mode = Nuctions.ScreenModeEnum.Features Then
            Me.Screen_Freatures.Checked = True
            Me.Screen_Features_LinkLabel.Visible = True
            Me.pnlFeature.Visible = True
            Me.Screen_PCR_Panel.Visible = False
        Else
            Me.Screen_PCR.Checked = True
            Me.Screen_Features_LinkLabel.Visible = False
            Me.Screen_PCR_Panel.Visible = True
            Me.pnlFeature.Visible = False
        End If
        Dim stb As New System.Text.StringBuilder
        For Each ei As FeatureScreenInfo In Me.RelatedChartItem.MolecularInfo.Screen_Features
            stb.Append(ei.Feature.Label + "(" + ei.ScreenMethod.ToString + ");")
        Next
        Dim scrtxt As String = stb.ToString
        If scrtxt.Length = 0 Then
            Me.Screen_Features_LinkLabel.Text = "[Click to select]"
        Else
            Me.Screen_Features_LinkLabel.Text = scrtxt
        End If
        scrSetting = True
        cbScreenCircular.Checked = Me.RelatedChartItem.MolecularInfo.Screen_OnlyCircular
        scrSetting = False
        Me.Screen_PCR_F.Text = Me.RelatedChartItem.MolecularInfo.Screen_FPrimer
        Me.tbSCRFP.Text = Me.RelatedChartItem.MolecularInfo.Screen_FName
        Me.Screen_PCR_R.Text = Me.RelatedChartItem.MolecularInfo.Screen_RPrimer
        Me.tbSCRRP.Text = Me.RelatedChartItem.MolecularInfo.Screen_RName
        Me.Screen_PCR_nudMax.Value = Me.RelatedChartItem.MolecularInfo.Screen_PCRMax
        Me.Screen_PCR_nudMin.Value = Me.RelatedChartItem.MolecularInfo.Screen_PCRMin

        Dim ftList As New List(Of Nuctions.Feature)
        Dim gList As New List(Of Nuctions.GeneFile)
        For Each di As DNAInfo In RelatedChartItem.MolecularInfo.Source
            For Each gf As Nuctions.GeneFile In di.DNAs
                gList.Add(gf)
            Next
        Next

        For Each ft As Nuctions.Feature In Features
            For Each gf As Nuctions.GeneFile In gList
                If gf.Matches(ft.Sequence).Count > 0 Or gf.Matches(ft.RCSequence).Count > 0 Then
                    ftList.Add(ft)
                    Exit For
                End If
            Next
        Next

        Dim ll As LinkLabel
        For Each ll In pnlFeature.Controls
            RemoveHandler ll.LinkClicked, AddressOf OnClickFeature
        Next
        pnlFeature.Controls.Clear()
        Dim i As Integer = 0
        For Each ft As Nuctions.Feature In ftList
            ll = New LinkLabel
            ll.Text = ft.Name
            ll.Tag = ft
            ll.Location = New Point((i Mod 5) * 100, (i \ 5) * 20)
            pnlFeature.Controls.Add(ll)
            AddHandler ll.LinkClicked, AddressOf OnClickFeature
            i += 1
        Next
    End Sub
    Private Sub OnClickFeature(ByVal sender As Object, ByVal e As EventArgs)
        Dim obj As LinkLabel = sender
        Dim ft As Nuctions.Feature = obj.Tag
        Dim Added As Boolean = False
        Dim fsi As FeatureScreenInfo = Nothing

        For Each ei As FeatureScreenInfo In Me.RelatedChartItem.MolecularInfo.Screen_Features
            If ei.Feature Is ft Then
                Added = True
                fsi = ei
                Exit For
            End If
        Next
        If Not Added Then
            fsi = New FeatureScreenInfo
            fsi.Feature = ft
            fsi.ScreenMethod = FeatureScreenEnum.Once
            Me.RelatedChartItem.MolecularInfo.Screen_Features.Add(fsi)
        ElseIf Not (fsi Is Nothing) Then
            Me.RelatedChartItem.MolecularInfo.Screen_Features.Remove(fsi)
        End If
        ApplyMode = True
        Accept()
    End Sub
    Private Sub RefreshModifyView()
        Select Case Me.RelatedChartItem.MolecularInfo.Modify_Method
            Case Nuctions.ModificationMethodEnum.CIAP
                Me.Modify_CIAP.Checked = True
            Case Nuctions.ModificationMethodEnum.Klewnow
                Me.Modify_Klewnow.Checked = True
            Case Nuctions.ModificationMethodEnum.PNK
                Me.Modify_PNK.Checked = True
            Case Nuctions.ModificationMethodEnum.T4DNAP
                Me.Modify_T4.Checked = True
        End Select
    End Sub
    Private Sub RefreshPCRView()
        If Me.RelatedChartItem.MolecularInfo.PCR_FPrimerName Is Nothing OrElse Me.RelatedChartItem.MolecularInfo.PCR_FPrimerName.Length = 0 Then
            Me.RelatedChartItem.MolecularInfo.PCR_FPrimerName = "F"
        End If
        If Me.RelatedChartItem.MolecularInfo.PCR_RPrimerName Is Nothing OrElse Me.RelatedChartItem.MolecularInfo.PCR_RPrimerName.Length = 0 Then
            Me.RelatedChartItem.MolecularInfo.PCR_RPrimerName = "R"
        End If
        Me.PCR_ForwardPrimer_TextBox.Text = Me.RelatedChartItem.MolecularInfo.PCR_ForwardPrimer
        tbFP.Text = Me.RelatedChartItem.MolecularInfo.PCR_FPrimerName
        Me.PCR_ReversePrimer_TextBox.Text = Me.RelatedChartItem.MolecularInfo.PCR_ReversePrimer
        tbRP.Text = Me.RelatedChartItem.MolecularInfo.PCR_RPrimerName
        StartAnalyzePrimers()
    End Sub
    Private Sub StartAnalyzePrimers()
        Dim pmrlist As New Dictionary(Of String, String)
        Dim pfk As String
        Dim prk As String
        If tbFP.Text = tbRP.Text Then
            pfk = tbFP.Text + "F"
            prk = tbRP.Text + "R"
        Else
            pfk = tbFP.Text
            prk = tbRP.Text
        End If
        pmrlist.Add(pfk, Nuctions.TAGCFilter(PCR_ForwardPrimer_TextBox.Text))
        pmrlist.Add(prk, Nuctions.TAGCFilter(PCR_ReversePrimer_TextBox.Text))
        Dim glist As New List(Of Nuctions.GeneFile)
        For Each sr As DNAInfo In Me.RelatedChartItem.MolecularInfo.Source
            For Each gf As Nuctions.GeneFile In sr.DNAs
                glist.Add(gf)
            Next
        Next
        anaPlist = pmrlist
        anaGlist = glist
        Try
            If thr Is Nothing Then
                thr = New Threading.Thread(AddressOf AnalyzePrimers)
                thr.Start()
            Else
                thr.Abort()
                thr = New Threading.Thread(AddressOf AnalyzePrimers)
                thr.Start()
            End If
        Catch ex As Exception

        End Try

    End Sub

    Dim thr As Threading.Thread
    Dim anaPlist As Dictionary(Of String, String)
    Dim anaGlist As List(Of Nuctions.GeneFile)


    Private Sub AnalyzePrimers()
        pafPCR.AnalyzePrimers(anaPlist, anaGlist, 80 * 0.001, 625 * 0.000000001)
    End Sub

    Private Sub RefreshGelView()
        Me.Gel_Maximum_Number.Value = Me.RelatedChartItem.MolecularInfo.Gel_Maximun
        Me.Gel_Minimum_Number.Value = Me.RelatedChartItem.MolecularInfo.Gel_Minimum
        '自动列出一系列不同长度的选项
        pnlGel.Controls.Clear()
        Dim ll As LinkLabel
        For Each ll In pnlGel.Controls
            RemoveHandler ll.LinkClicked, AddressOf OnSelectGelLength
        Next
        Dim i As Integer = 0
        Dim nList As New List(Of Integer)
        For Each di As DNAInfo In Me.RelatedChartItem.MolecularInfo.Source
            For Each dna As Nuctions.GeneFile In di.DNAs
                If dna.Length >= 100 And dna.Length <= 200000 And (Not nList.Contains(dna.Length)) Then nList.Add(dna.Length)
            Next
        Next
        nList.Sort()
        For Each j As Integer In nList
            ll = New LinkLabel
            ll.Text = j.ToString
            pnlGel.Controls.Add(ll)
            ll.Location = New Point((i Mod 5) * 100, (i \ 5) * 20)
            i += 1
            AddHandler ll.LinkClicked, AddressOf OnSelectGelLength
        Next
    End Sub
    Private Sub OnSelectGelLength(ByVal sender As Object, ByVal e As EventArgs)
        Dim ll As LinkLabel = sender
        Dim ln As Integer = CInt(ll.Text)
        If ln >= 100 And ln <= 200000 Then
            Me.Gel_Maximum_Number.Value = ln
            Me.Gel_Minimum_Number.Value = ln
        End If
        Accept()
    End Sub

    Public Event RequireFeatureScreenView(ByVal sender As Object, ByVal e As EventArgs)

    Private Sub Screen_Features_LinkLabel_LinkClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles Screen_Features_LinkLabel.LinkClicked
        RaiseEvent RequireFeatureScreenView(Me, New EventArgs)
    End Sub
    Public Sub SetFeatureScreen(ByVal fList As List(Of FeatureScreenInfo))

        Dim stb As New System.Text.StringBuilder
        Me.RelatedChartItem.MolecularInfo.Screen_Features = fList
        For Each ei As FeatureScreenInfo In Me.RelatedChartItem.MolecularInfo.Screen_Features
            stb.Append(ei.Feature.Label + "(" + ei.ScreenMethod.ToString + ");")
        Next
        Dim scrtxt As String = stb.ToString
        If scrtxt.Length = 0 Then
            Me.Screen_Features_LinkLabel.Text = "[Click to select]"
        Else
            Me.Screen_Features_LinkLabel.Text = scrtxt
        End If
        ApplyMode = True
    End Sub

    Private EnzRgx As New System.Text.RegularExpressions.Regex("\[([\w]+)\]")

    Private Sub PCR_ForwardPrimer_TextBox_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles PCR_ForwardPrimer_TextBox.KeyDown
        If EnzRgx.IsMatch(PCR_ForwardPrimer_TextBox.Text) Then
            For Each m As System.Text.RegularExpressions.Match In EnzRgx.Matches(PCR_ForwardPrimer_TextBox.Text)
                For Each re As Nuctions.RestrictionEnzyme In frmMain.EnzymeCol.RECollection
                    If re.Name.ToLower = m.Groups(1).Value.ToLower Then
                        PCR_ForwardPrimer_TextBox.Text = PCR_ForwardPrimer_TextBox.Text.Replace(m.Groups(0).Value, re.Sequence)
                        PCR_ForwardPrimer_TextBox.SelectionStart = m.Index + re.Sequence.Length
                    End If
                Next
            Next
        End If
    End Sub

    Private Sub PCR_ReversePrimer_TextBox_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles PCR_ReversePrimer_TextBox.KeyDown
        If EnzRgx.IsMatch(PCR_ReversePrimer_TextBox.Text) Then
            For Each m As System.Text.RegularExpressions.Match In EnzRgx.Matches(PCR_ReversePrimer_TextBox.Text)
                For Each re As Nuctions.RestrictionEnzyme In frmMain.EnzymeCol.RECollection
                    If re.Name.ToLower = m.Groups(1).Value.ToLower Then
                        PCR_ReversePrimer_TextBox.Text = PCR_ReversePrimer_TextBox.Text.Replace(m.Groups(0).Value, re.Sequence)
                        PCR_ReversePrimer_TextBox.SelectionStart = m.Index + re.Sequence.Length
                    End If
                Next
            Next
        End If
    End Sub



    Private Sub ll_ViewLarge_LinkClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.LinkLabelLinkClickedEventArgs)
        DNAView.View = View.LargeIcon
    End Sub

    Public Event RequireDNAView(ByVal sender As Object, ByVal e As DNAViewEventArgs)
    Public Event RequirePCRView(ByVal sender As Object, ByVal e As PCRViewEventArgs)

    Private Sub ll_ViewDetails_LinkClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles ll_ViewDetails.LinkClicked
        '在酶切位点分析模式下 不能查看DNA
        If Me.RelatedChartItem.MolecularInfo.MolecularOperation = Nuctions.MolecularOperationEnum.EnzymeAnalysis Then Exit Sub
        Dim glist As New List(Of Nuctions.GeneFile)
        For Each g As Nuctions.GeneFile In RelatedChartItem.MolecularInfo.DNAs
            glist.Add(g)
        Next
        RaiseEvent RequireDNAView(Me, New DNAViewEventArgs(glist))
    End Sub

    Private Sub btn_RCF_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnBothPrimer.Click
        Dim glist As New List(Of Nuctions.GeneFile)
        For Each di As DNAInfo In RelatedChartItem.MolecularInfo.Source
            For Each g As Nuctions.GeneFile In di.DNAs
                glist.Add(g)
            Next
        Next
        Dim primers As New Dictionary(Of String, String)

        If tbFP.Text = tbRP.Text Then
            tbFP.Text += "F"
            tbRP.Text += "R"
        End If
        Dim fp As String = PCR_ForwardPrimer_TextBox.Text
        Dim rp As String = PCR_ReversePrimer_TextBox.Text
        Dim idx As Integer
        idx = fp.LastIndexOf(">")
        If idx > -1 Then
            PCR_ForwardPrimer_TextBox.Text = Nuctions.TAGCFilter(fp.Substring(0, idx)) + ">" + Nuctions.TAGCFilter(fp.Substring(idx, fp.Length - idx))
        End If
        idx = rp.LastIndexOf(">")
        If idx > -1 Then
            PCR_ReversePrimer_TextBox.Text = Nuctions.TAGCFilter(rp.Substring(0, idx)) + ">" + Nuctions.TAGCFilter(rp.Substring(idx, rp.Length - idx))
        End If
        primers.Add(tbFP.Text, PCR_ForwardPrimer_TextBox.Text)
        primers.Add(tbRP.Text, PCR_ReversePrimer_TextBox.Text)

        RaiseEvent RequirePCRView(Me, New PCRViewEventArgs(glist, primers))
    End Sub

    Private Sub frmProperty_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles MyBase.KeyDown
        Select Case e.KeyCode
            Case Keys.F1
                Me.Prop_Name.Focus()
                Me.Prop_Name.SelectAll()
            Case Keys.F2
                Me.rtb_Description.Focus()
                Me.rtb_Description.SelectAll()
            Case Keys.Enter
                If Control.ModifierKeys = Keys.Control Then
                    Accept()
                End If
            Case Keys.Escape
                'Me.Close()
        End Select
    End Sub


    Private Sub Screen_Freatures_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Screen_Freatures.CheckedChanged
        Me.Screen_Features_LinkLabel.Visible = True
        Me.Screen_PCR_Panel.Visible = False
        Me.pnlFeature.Visible = True
        ApplyMode = True
    End Sub

    Private Sub Screen_PCR_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Screen_PCR.CheckedChanged
        Me.Screen_PCR_Panel.Visible = True
        Me.Screen_Features_LinkLabel.Visible = False
        Me.pnlFeature.Visible = False
        ApplyMode = True
    End Sub

    Private Sub Screen_PCR_RCF_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Screen_PCR_RCF.Click
        Dim glist As New List(Of Nuctions.GeneFile)
        For Each di As DNAInfo In RelatedChartItem.MolecularInfo.Source
            For Each g As Nuctions.GeneFile In di.DNAs
                glist.Add(g)
            Next
        Next
        Dim primers As New Dictionary(Of String, String)

        If tbSCRFP.Text = tbSCRRP.Text Then
            tbSCRFP.Text += "F"
            tbSCRFP.Text += "R"
        End If
        Dim fp As String = Screen_PCR_F.Text
        Dim rp As String = Screen_PCR_R.Text
        Dim idx As Integer
        idx = fp.LastIndexOf(">")
        If idx > -1 Then
            PCR_ForwardPrimer_TextBox.Text = Nuctions.TAGCFilter(fp.Substring(0, idx)) + ">" + Nuctions.TAGCFilter(fp.Substring(idx, fp.Length - idx))
        End If
        idx = rp.LastIndexOf(">")
        If idx > -1 Then
            PCR_ReversePrimer_TextBox.Text = Nuctions.TAGCFilter(rp.Substring(0, idx)) + ">" + Nuctions.TAGCFilter(rp.Substring(idx, rp.Length - idx))
        End If
        primers.Add(tbSCRFP.Text, Screen_PCR_F.Text)
        primers.Add(tbSCRRP.Text, Screen_PCR_R.Text)

        Me.RelatedChartItem.MolecularInfo.PCR_RPrimerName = PCR_ForwardPrimer_TextBox.Text
        RaiseEvent RequirePCRView(Me, New PCRViewEventArgs(glist, primers))
    End Sub

    Private Sub Screen_PCR_F_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Screen_PCR_F.TextChanged
        Me.ApplyMode = True
    End Sub

    Private Sub Screen_PCR_R_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Screen_PCR_R.TextChanged
        Me.ApplyMode = True
    End Sub

    Private Sub Screen_PCR_nudMax_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Screen_PCR_nudMax.ValueChanged
        Me.ApplyMode = True
    End Sub

    Private Sub Screen_PCR_nudMin_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Screen_PCR_nudMin.ValueChanged
        Me.ApplyMode = True
    End Sub

    Private Sub llApply_LinkClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles llApply.LinkClicked
        mApplyMode = True
        Accept()
    End Sub

    Private Sub llCancel_LinkClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles llCancel.LinkClicked
        Cancel()
    End Sub

    Public Sub Cancel()
        If DNACopy Is Nothing Then Exit Sub
        RelatedChartItem.MolecularInfo.Recover(DNACopy)
        RelatedChartItem.Reload(RelatedChartItem.MolecularInfo, Me.RelatedChartItem.Parent.EnzymeCol)
        Reload()
    End Sub
    Private Sub Prop_Name_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Prop_Name.TextChanged
        RelatedChartItem.MolecularInfo.Name = Prop_Name.Text
        ChangeValue()
    End Sub

    Private Sub Gel_Minimum_Number_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Gel_Minimum_Number.ValueChanged, Gel_Maximum_Number.ValueChanged
        ApplyMode = True
    End Sub

    Private Sub PropertyControl_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        DNAView.SmallImageList = frmMain.SmallIconList
    End Sub

    Private Sub EnzymeControl_CloseTab(ByVal sender As Object, ByVal e As System.EventArgs) Handles EnzymeControl.CloseTab
        HideEnzymeTab()
    End Sub

    Private Sub EnzymeControl_SetRestrictSite(ByVal sender As Object, ByVal e As RestrictionEnzymeView.RESiteEventArgs) Handles EnzymeControl.SetRestrictSite
        SetEnzymes(e.RESites)
    End Sub

    Private rbRecSetting As Boolean = False
    Private Sub rbRec_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)
        If rbRecSetting Then Exit Sub
        ApplyMode = True
    End Sub

    Protected Overrides Sub Finalize()
        For Each rb As RadioButton In RBRec.Values
            RemoveHandler rb.CheckedChanged, AddressOf Me.rbRec_CheckedChanged
        Next
        MyBase.Finalize()
    End Sub

    Private scrSetting As Boolean = False

    Private Sub cbScreenCircular_CheckedChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cbScreenCircular.CheckedChanged
        If scrSetting Then Exit Sub
        Me.RelatedChartItem.MolecularInfo.Screen_OnlyCircular = cbScreenCircular.Checked
        Me.ApplyMode = True
    End Sub

    Public Event RequireSelectDNAView(ByVal sender As Object, ByVal e As DNAViewEventArgs)

    Private Sub AddToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AddToolStripMenuItem.Click
        Dim glist As New List(Of Nuctions.GeneFile)

        For Each dnai As DNAInfo In Me.RelatedChartItem.MolecularInfo.Source
            For Each gf As Nuctions.GeneFile In dnai.DNAs
                glist.Add(gf)
            Next
        Next
        RaiseEvent RequireSelectDNAView(Me, New DNAViewEventArgs(glist))
    End Sub

    Public Sub AddEnzymeAnalysisSequence(ByVal gf As Nuctions.GeneFile, ByVal vRegion As String)
        Dim i As Integer = dgvEnzymeAnalysis.Rows.Add
        Dim row As DataGridViewRow
        row = dgvEnzymeAnalysis.Rows(i)
        row.Tag = gf
        row.Cells(0).Value = gf.Name
        row.Cells(1).Value = vRegion
        row.Cells(2).Value = True
        row.Cells(3).Value = "="
        row.Cells(4).Value = "0"
        ApplyMode = True
    End Sub

    Public Sub RefreshEnzymeAnalysisView()
        eaSetting = True
        dgvEnzymeAnalysis.Rows.Clear()
        For Each eai As EnzymeAnalysisItem In Me.RelatedChartItem.MolecularInfo.EnzymeAnalysisParamters
            Dim i As Integer = dgvEnzymeAnalysis.Rows.Add
            Dim row As DataGridViewRow
            row = dgvEnzymeAnalysis.Rows(i)
            row.Tag = eai.GeneFile
            row.Cells(0).Value = eai.GeneFile.Name
            row.Cells(1).Value = eai.Region
            row.Cells(2).Value = eai.Use
            Select Case eai.Method
                Case EnzymeAnalysisEnum.Equal
                    row.Cells(3).Value = "="
                Case EnzymeAnalysisEnum.Greater
                    row.Cells(3).Value = ">"
                Case EnzymeAnalysisEnum.Less
                    row.Cells(3).Value = "<"
            End Select
            row.Cells(4).Value = eai.Value.ToString
        Next
        eaSetting = False
    End Sub

    Public Function ReadEnzymeAnalysisItems() As List(Of EnzymeAnalysisItem)
        Dim row As DataGridViewRow
        Dim eai As EnzymeAnalysisItem
        Dim eList As New List(Of EnzymeAnalysisItem)
        For Each row In dgvEnzymeAnalysis.Rows
            eai = New EnzymeAnalysisItem
            eai.GeneFile = row.Tag
            eai.Region = row.Cells(1).Value
            eai.Use = row.Cells(2).Value
            Select Case row.Cells(3).Value
                Case "="
                    eai.Method = EnzymeAnalysisEnum.Equal
                Case ">"
                    eai.Method = EnzymeAnalysisEnum.Greater
                Case "<"
                    eai.Method = EnzymeAnalysisEnum.Less
            End Select
            Dim i As Integer
            Try
                i = CInt(row.Cells(4).Value)
            Catch ex As Exception
                row.Cells(4).Value = 0
                i = 0
            End Try
            eai.Value = i
            eList.Add(eai)
        Next
        Return eList
    End Function

    Dim eaSetting As Boolean = False
    Private Sub dgvEnzymeAnalysis_CellContentClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles dgvEnzymeAnalysis.CellValueChanged
        If eaSetting Then Exit Sub
        ApplyMode = True
    End Sub

    Private Sub RemoveToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RemoveToolStripMenuItem.Click
        If dgvEnzymeAnalysis.SelectedRows.Count > 0 Then
            Dim rmList As New List(Of DataGridViewRow)
            For Each row As DataGridViewRow In dgvEnzymeAnalysis.SelectedRows
                rmList.Add(row)
            Next
            For Each row As DataGridViewRow In rmList
                dgvEnzymeAnalysis.Rows.Remove(row)
            Next
        End If
    End Sub

    Public Event ReqireFeatures(ByVal sender As Object, ByVal e As FeatureEventArgs)
    Public ReadOnly Property Features() As List(Of Nuctions.Feature)
        Get
            Dim fe As New FeatureEventArgs
            RaiseEvent ReqireFeatures(Me, fe)
            Return fe.Features
        End Get
    End Property

    Private Sub rbLig2_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles rbLig2.CheckedChanged, rbLig3.CheckedChanged, rbLigM.CheckedChanged
        ApplyMode = True
    End Sub

    Private Sub tbSCRFP_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles tbSCRFP.KeyDown
        If e.KeyCode = Keys.Enter Then
            Dim tb As TextBox = Screen_PCR_F
            Dim sd As TextBox = sender
            Select Case sd.Text.ToLower
                Case "m13f"
                    tb.Text = ">TGTAAAACGACGGCCAGT"
                    sd.Text = "M13F"
                Case "m13r"
                    tb.Text = ">CAGGAAACAGCTATGACC"
                    sd.Text = "M13R"
                Case "m13-20"
                    tb.Text = ">GTAAAACGACGGCCAGT"
                    sd.Text = "M13-20"
                Case "m13-26"
                    tb.Text = ">CAGGAAACAGCTATGAC"
                    sd.Text = "M13-26"
                Case "m13-40"
                    tb.Text = ">GTTTTCCCAGTCACGAC"
                    sd.Text = "M13-40"
                Case "m13-46"
                    tb.Text = ">GCCAGGGTTTTCCCAGTCACGA"
                    sd.Text = "M13-46"
                Case "m13-47"
                    tb.Text = ">CGCCAGGGTTTTCCCAGTCACGAC"
                    sd.Text = "M13-47"
                Case "m13-48"
                    tb.Text = ">AGCGGATAACAATTTCACACAGGA"
                    sd.Text = "M13-48"
                Case "m13-96"
                    tb.Text = ">CCCTCATAGTTAGCGTAACG"
                    sd.Text = "M13-96"
                Case "t7pro", "t7 promoter"
                    tb.Text = ">TAATACGACTCACTATAGGG"
                    sd.Text = "T7Pro"
                Case "t7ter", "t7 terminator"
                    tb.Text = ">TGCTAGTTATTGCTCAGCGG"
                    sd.Text = "T7Ter"
                Case "sp6"
                    tb.Text = ">CATACGATTTAGGTGACACTATAG"
                    sd.Text = "SP6"
                Case "t7"
                    tb.Text = ">TAATACGACTCACTATAGGGAGA"
                    sd.Text = "T7"
                Case "t3"
                    tb.Text = ">GCGCGAAATTAACCCTCACTAAAG"
                    sd.Text = "T3"
                Case Else
                    For Each ci As ChartItem In Me.RelatedChartItem.Parent.Items
                        If ci Is RelatedChartItem Then Continue For
                        If ci.MolecularInfo.MolecularOperation = Nuctions.MolecularOperationEnum.PCR Then
                            If ci.MolecularInfo.PCR_FPrimerName.ToLower = sd.Text.ToLower Then tb.Text = ci.MolecularInfo.PCR_ForwardPrimer : sd.Text = ci.MolecularInfo.PCR_FPrimerName
                            If ci.MolecularInfo.PCR_RPrimerName.ToLower = sd.Text.ToLower Then tb.Text = ci.MolecularInfo.PCR_ReversePrimer : sd.Text = ci.MolecularInfo.PCR_RPrimerName
                        ElseIf ci.MolecularInfo.MolecularOperation = Nuctions.MolecularOperationEnum.Screen And ci.MolecularInfo.Screen_Mode = Nuctions.ScreenModeEnum.PCR Then
                            If ci.MolecularInfo.Screen_FName.ToLower = sd.Text.ToLower Then tb.Text = ci.MolecularInfo.Screen_FPrimer : sd.Text = ci.MolecularInfo.Screen_FName
                            If ci.MolecularInfo.Screen_RName.ToLower = sd.Text.ToLower Then tb.Text = ci.MolecularInfo.Screen_RPrimer : sd.Text = ci.MolecularInfo.Screen_RName
                        End If
                    Next
            End Select
        End If
    End Sub

    Private Sub tbSCRFP_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tbSCRFP.TextChanged
        ApplyMode = True
    End Sub

    Private Sub tbSCRRP_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles tbSCRRP.KeyDown
        If e.KeyCode = Keys.Enter Then
            Dim tb As TextBox = Screen_PCR_R
            Dim sd As TextBox = sender
            Select Case sd.Text.ToLower
                Case "m13f"
                    tb.Text = ">TGTAAAACGACGGCCAGT"
                    sd.Text = "M13F"
                Case "m13r"
                    tb.Text = ">CAGGAAACAGCTATGACC"
                    sd.Text = "M13R"
                Case "m13-20"
                    tb.Text = ">GTAAAACGACGGCCAGT"
                    sd.Text = "M13-20"
                Case "m13-26"
                    tb.Text = ">CAGGAAACAGCTATGAC"
                    sd.Text = "M13-26"
                Case "m13-40"
                    tb.Text = ">GTTTTCCCAGTCACGAC"
                    sd.Text = "M13-40"
                Case "m13-46"
                    tb.Text = ">GCCAGGGTTTTCCCAGTCACGA"
                    sd.Text = "M13-46"
                Case "m13-47"
                    tb.Text = ">CGCCAGGGTTTTCCCAGTCACGAC"
                    sd.Text = "M13-47"
                Case "m13-48"
                    tb.Text = ">AGCGGATAACAATTTCACACAGGA"
                    sd.Text = "M13-48"
                Case "m13-96"
                    tb.Text = ">CCCTCATAGTTAGCGTAACG"
                    sd.Text = "M13-96"
                Case "t7pro", "t7 promoter"
                    tb.Text = ">TAATACGACTCACTATAGGG"
                    sd.Text = "T7Pro"
                Case "t7ter", "t7 terminator"
                    tb.Text = ">TGCTAGTTATTGCTCAGCGG"
                    sd.Text = "T7Ter"
                Case "sp6"
                    tb.Text = ">CATACGATTTAGGTGACACTATAG"
                    sd.Text = "SP6"
                Case "t7"
                    tb.Text = ">TAATACGACTCACTATAGGGAGA"
                    sd.Text = "T7"
                Case "t3"
                    tb.Text = ">GCGCGAAATTAACCCTCACTAAAG"
                    sd.Text = "T3"
                Case Else
                    For Each ci As ChartItem In Me.RelatedChartItem.Parent.Items
                        If ci Is RelatedChartItem Then Continue For
                        If ci.MolecularInfo.MolecularOperation = Nuctions.MolecularOperationEnum.PCR Then
                            If ci.MolecularInfo.PCR_FPrimerName.ToLower = sd.Text.ToLower Then tb.Text = ci.MolecularInfo.PCR_ForwardPrimer : sd.Text = ci.MolecularInfo.PCR_FPrimerName
                            If ci.MolecularInfo.PCR_RPrimerName.ToLower = sd.Text.ToLower Then tb.Text = ci.MolecularInfo.PCR_ReversePrimer : sd.Text = ci.MolecularInfo.PCR_RPrimerName
                        ElseIf ci.MolecularInfo.MolecularOperation = Nuctions.MolecularOperationEnum.Screen And ci.MolecularInfo.Screen_Mode = Nuctions.ScreenModeEnum.PCR Then
                            If ci.MolecularInfo.Screen_FName.ToLower = sd.Text.ToLower Then tb.Text = ci.MolecularInfo.Screen_FPrimer : sd.Text = ci.MolecularInfo.Screen_FName
                            If ci.MolecularInfo.Screen_RName.ToLower = sd.Text.ToLower Then tb.Text = ci.MolecularInfo.Screen_RPrimer : sd.Text = ci.MolecularInfo.Screen_RName
                        End If
                    Next
            End Select
        End If
    End Sub

    Private Sub tbSCRRP_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tbSCRRP.TextChanged
        ApplyMode = True
    End Sub

    Dim desSetting As Boolean = False
    Private Sub rtb_Description_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles rtb_Description.TextChanged
        If desSetting Then Exit Sub
        If RelatedChartItem.MolecularInfo.MolecularOperation = Nuctions.MolecularOperationEnum.EnzymeAnalysis Then Exit Sub
        Me.RelatedChartItem.MolecularInfo.OperationDescription = rtb_Description.Text
    End Sub

    Dim pxkSetting As Boolean = False
    Private Sub cbRealSize_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cbRealSize.CheckedChanged
        If pxkSetting Then Exit Sub
        Me.RelatedChartItem.MolecularInfo.RealSize = cbRealSize.Checked
        Me.RelatedChartItem.Reload(RelatedChartItem.MolecularInfo, Me.RelatedChartItem.Parent.EnzymeCol)
        Me.RelatedChartItem.Parent.Draw()
    End Sub

    Private Sub File_FileName_LinkLabel_LinkClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles File_FileName_LinkLabel.LinkClicked
        Try
            If IO.File.Exists(RelatedChartItem.MolecularInfo.File_Filename) Then
                ofdVector.FileName = RelatedChartItem.MolecularInfo.File_Filename
            End If
        Catch ex As Exception

        End Try

        Try
            If ofdVector.ShowDialog = DialogResult.OK Then
                RelatedChartItem.MolecularInfo.File_Filename = ofdVector.FileName
                Dim fi As New IO.FileInfo(RelatedChartItem.MolecularInfo.File_Filename)
                If fi.Extension.ToLower = ".gb" Then
                    RelatedChartItem.MolecularInfo.DNAs.Clear()
                    RelatedChartItem.MolecularInfo.DNAs.Add(Nuctions.GeneFile.LoadFromGeneBankFile(fi.FullName))
                Else
                    RelatedChartItem.MolecularInfo.DNAs.Clear()
                    Dim gf As New Nuctions.GeneFile
                    gf.Sequence = Nuctions.TAGCFilter(IO.File.ReadAllText(fi.FullName))
                    gf.End_F = "*B"
                    gf.End_R = "*B"
                    RelatedChartItem.MolecularInfo.DNAs.Add(gf)
                End If
                RelatedChartItem.Reload(RelatedChartItem.MolecularInfo, Me.RelatedChartItem.Parent.EnzymeCol)
                RelatedChartItem.Parent.Draw()
            End If
        Catch ex As Exception

        End Try
    End Sub

    Dim enzSetting As Boolean = False

    Private Sub tbEnzymes_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles tbEnzymes.KeyDown
        If e.KeyCode = Keys.Enter Then
            Accept()
            enzSetting = True
            If RelatedChartItem.MolecularInfo.Enzyme_Enzymes.Count > 0 Then
                tbEnzymes.Text = Enzyme_Enzymes_LinkLabel.Text
            Else
                tbEnzymes.Text = ""
            End If

            enzSetting = False
        End If
    End Sub
    Private Sub tbEnzymes_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tbEnzymes.TextChanged
        If enzSetting Then Exit Sub
        Dim str As String() = tbEnzymes.Text.ToLower.Split(" ")
        Dim stList As New List(Of String)
        stList.AddRange(str)

        Dim stb As New System.Text.StringBuilder
        Me.RelatedChartItem.MolecularInfo.Enzyme_Enzymes.Clear()
        For Each key As Nuctions.RestrictionEnzyme In frmMain.EnzymeCol.RECollection
            If stList.IndexOf(key.Name.ToLower) > -1 Then
                Me.RelatedChartItem.MolecularInfo.Enzyme_Enzymes.Add(key.Name)
                stb.Append(key.Name)
                stb.Append(" ")
            End If
        Next
        Me.Enzyme_Enzymes_LinkLabel.Text = stb.ToString
        If Me.Enzyme_Enzymes_LinkLabel.Text.Length = 0 Then
            Me.Enzyme_Enzymes_LinkLabel.Text = "[Click to Select]"
        End If
        ApplyMode = True
        ChangeValue()
    End Sub

    Private Sub PCR_Primer_TextBox_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) 'Handles PCR_ForwardPrimer_TextBox.TextChanged, PCR_ReversePrimer_TextBox.TextChanged, tbRP.TextChanged, tbFP.TextChanged
        Me.ApplyMode = True
        lblFCount.Text = Nuctions.TAGCFilter(PCR_ForwardPrimer_TextBox.Text).Length.ToString
        lblRCount.Text = Nuctions.TAGCFilter(PCR_ReversePrimer_TextBox.Text).Length.ToString
    End Sub
    Private Sub PCR_ForwardPrimer_TextBox_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PCR_ForwardPrimer_TextBox.TextChanged
        Me.ApplyMode = True
        lblFCount.Text = Nuctions.TAGCFilter(PCR_ForwardPrimer_TextBox.Text).Length.ToString
        StartAnalyzePrimers()
    End Sub

    Private Sub PCR_ReversePrimer_TextBox_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PCR_ReversePrimer_TextBox.TextChanged
        Me.ApplyMode = True
        lblRCount.Text = Nuctions.TAGCFilter(PCR_ReversePrimer_TextBox.Text).Length.ToString
        StartAnalyzePrimers()
    End Sub

    Private Sub tbFP_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles tbFP.KeyDown
        If e.KeyCode = Keys.Enter Then
            Dim tb As TextBox = PCR_ForwardPrimer_TextBox
            Dim sd As TextBox = sender
            Select Case tbFP.Text.ToLower
                Case "m13f"
                    tb.Text = ">TGTAAAACGACGGCCAGT"
                    sd.Text = "M13F"
                Case "m13r"
                    tb.Text = ">CAGGAAACAGCTATGACC"
                    sd.Text = "M13R"
                Case "m13-20"
                    tb.Text = ">GTAAAACGACGGCCAGT"
                    sd.Text = "M13-20"
                Case "m13-26"
                    tb.Text = ">CAGGAAACAGCTATGAC"
                    sd.Text = "M13-26"
                Case "m13-40"
                    tb.Text = ">GTTTTCCCAGTCACGAC"
                    sd.Text = "M13-40"
                Case "m13-46"
                    tb.Text = ">GCCAGGGTTTTCCCAGTCACGA"
                    sd.Text = "M13-46"
                Case "m13-47"
                    tb.Text = ">CGCCAGGGTTTTCCCAGTCACGAC"
                    sd.Text = "M13-47"
                Case "m13-48"
                    tb.Text = ">AGCGGATAACAATTTCACACAGGA"
                    sd.Text = "M13-48"
                Case "m13-96"
                    tb.Text = ">CCCTCATAGTTAGCGTAACG"
                    sd.Text = "M13-96"
                Case "t7pro", "t7 promoter"
                    tb.Text = ">TAATACGACTCACTATAGGG"
                    sd.Text = "T7Pro"
                Case "t7ter", "t7 terminator"
                    tb.Text = ">TGCTAGTTATTGCTCAGCGG"
                    sd.Text = "T7Ter"
                Case "sp6"
                    tb.Text = ">CATACGATTTAGGTGACACTATAG"
                    sd.Text = "SP6"
                Case "t7"
                    tb.Text = ">TAATACGACTCACTATAGGGAGA"
                    sd.Text = "T7"
                Case "t3"
                    tb.Text = ">GCGCGAAATTAACCCTCACTAAAG"
                    sd.Text = "T3"
                Case Else
                    For Each ci As ChartItem In Me.RelatedChartItem.Parent.Items
                        If ci Is RelatedChartItem Then Continue For
                        If ci.MolecularInfo.MolecularOperation = Nuctions.MolecularOperationEnum.PCR Then
                            If ci.MolecularInfo.PCR_FPrimerName.ToLower = sd.Text.ToLower Then tb.Text = ci.MolecularInfo.PCR_ForwardPrimer : sd.Text = ci.MolecularInfo.PCR_FPrimerName
                            If ci.MolecularInfo.PCR_RPrimerName.ToLower = sd.Text.ToLower Then tb.Text = ci.MolecularInfo.PCR_ReversePrimer : sd.Text = ci.MolecularInfo.PCR_RPrimerName
                        ElseIf ci.MolecularInfo.MolecularOperation = Nuctions.MolecularOperationEnum.Screen And ci.MolecularInfo.Screen_Mode = Nuctions.ScreenModeEnum.PCR Then
                            If ci.MolecularInfo.Screen_FName.ToLower = sd.Text.ToLower Then tb.Text = ci.MolecularInfo.Screen_FPrimer : sd.Text = ci.MolecularInfo.Screen_FName
                            If ci.MolecularInfo.Screen_RName.ToLower = sd.Text.ToLower Then tb.Text = ci.MolecularInfo.Screen_RPrimer : sd.Text = ci.MolecularInfo.Screen_RName
                        End If
                    Next
            End Select
        End If
    End Sub

    Private Sub tbFP_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tbFP.TextChanged
        Me.ApplyMode = True
    End Sub

    Private Sub tbRP_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles tbRP.KeyDown
        If e.KeyCode = Keys.Enter Then
            Dim tb As TextBox = PCR_ReversePrimer_TextBox
            Dim sd As TextBox = sender
            Select Case sd.Text.ToLower
                Case "m13f"
                    tb.Text = ">TGTAAAACGACGGCCAGT"
                    sd.Text = "M13F"
                Case "m13r"
                    tb.Text = ">CAGGAAACAGCTATGACC"
                    sd.Text = "M13R"
                Case "m13-20"
                    tb.Text = ">GTAAAACGACGGCCAGT"
                    sd.Text = "M13-20"
                Case "m13-26"
                    tb.Text = ">CAGGAAACAGCTATGAC"
                    sd.Text = "M13-26"
                Case "m13-40"
                    tb.Text = ">GTTTTCCCAGTCACGAC"
                    sd.Text = "M13-40"
                Case "m13-46"
                    tb.Text = ">GCCAGGGTTTTCCCAGTCACGA"
                    sd.Text = "M13-46"
                Case "m13-47"
                    tb.Text = ">CGCCAGGGTTTTCCCAGTCACGAC"
                    sd.Text = "M13-47"
                Case "m13-48"
                    tb.Text = ">AGCGGATAACAATTTCACACAGGA"
                    sd.Text = "M13-48"
                Case "m13-96"
                    tb.Text = ">CCCTCATAGTTAGCGTAACG"
                    sd.Text = "M13-96"
                Case "t7pro", "t7 promoter"
                    tb.Text = ">TAATACGACTCACTATAGGG"
                    sd.Text = "T7Pro"
                Case "t7ter", "t7 terminator"
                    tb.Text = ">TGCTAGTTATTGCTCAGCGG"
                    sd.Text = "T7Ter"
                Case "sp6"
                    tb.Text = ">CATACGATTTAGGTGACACTATAG"
                    sd.Text = "SP6"
                Case "t7"
                    tb.Text = ">TAATACGACTCACTATAGGGAGA"
                    sd.Text = "T7"
                Case "t3"
                    tb.Text = ">GCGCGAAATTAACCCTCACTAAAG"
                    sd.Text = "T3"
                Case Else
                    For Each ci As ChartItem In Me.RelatedChartItem.Parent.Items
                        If ci Is RelatedChartItem Then Continue For
                        If ci.MolecularInfo.MolecularOperation = Nuctions.MolecularOperationEnum.PCR Then
                            If ci.MolecularInfo.PCR_FPrimerName.ToLower = sd.Text.ToLower Then tb.Text = ci.MolecularInfo.PCR_ForwardPrimer : sd.Text = ci.MolecularInfo.PCR_FPrimerName
                            If ci.MolecularInfo.PCR_RPrimerName.ToLower = sd.Text.ToLower Then tb.Text = ci.MolecularInfo.PCR_ReversePrimer : sd.Text = ci.MolecularInfo.PCR_RPrimerName
                        ElseIf ci.MolecularInfo.MolecularOperation = Nuctions.MolecularOperationEnum.Screen And ci.MolecularInfo.Screen_Mode = Nuctions.ScreenModeEnum.PCR Then
                            If ci.MolecularInfo.Screen_FName.ToLower = sd.Text.ToLower Then tb.Text = ci.MolecularInfo.Screen_FPrimer : sd.Text = ci.MolecularInfo.Screen_FName
                            If ci.MolecularInfo.Screen_RName.ToLower = sd.Text.ToLower Then tb.Text = ci.MolecularInfo.Screen_RPrimer : sd.Text = ci.MolecularInfo.Screen_RName
                        End If
                    Next
            End Select
        End If
    End Sub

    Private Sub tbRP_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tbRP.TextChanged
        Me.ApplyMode = True
    End Sub
    Private Sub RefreshMerge()
        mgSetting = True
        cbMergeSignificant.Checked = RelatedChartItem.MolecularInfo.OnlySignificant
        cbMergeExtend.Checked = RelatedChartItem.MolecularInfo.OnlyExtend
        mgSetting = False
    End Sub
    Dim mgSetting As Boolean = False
    Private Sub cbMergeSignificant_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cbMergeSignificant.CheckedChanged
        If mgSetting Then Exit Sub
        RelatedChartItem.MolecularInfo.OnlySignificant = cbMergeSignificant.Checked
        ApplyMode = True
    End Sub

    Private Sub cbMergeExtend_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cbMergeExtend.CheckedChanged
        If mgSetting Then Exit Sub
        RelatedChartItem.MolecularInfo.OnlyExtend = cbMergeExtend.Checked
        ApplyMode = True
    End Sub

    Dim Setting_finished As Boolean = False

    Private Sub rbProgress_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles rbUnstarted.CheckedChanged, rbInprogress.CheckedChanged, rbFinished.CheckedChanged
        If Setting_finished Then Exit Sub
        Dim sdr As RadioButton = sender
        RelatedChartItem.MolecularInfo.Progress = sdr.Tag
        RelatedChartItem.Reload(RelatedChartItem.MolecularInfo, Me.RelatedChartItem.Parent.EnzymeCol)
        Me.RelatedChartItem.Parent.Draw()
    End Sub

End Class

Public Class EnzymeAnalysisItem
    Public GeneFile As Nuctions.GeneFile
    Public Region As String
    Public Use As Boolean = False
    Public Method As EnzymeAnalysisEnum
    Public Value As Integer
End Class
Public Enum EnzymeAnalysisEnum As Integer
    Equal = 0
    Greater = 1
    Less = 2
End Enum