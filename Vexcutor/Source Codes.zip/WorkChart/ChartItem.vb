Public Class RequireParentEventArgs
    Inherits EventArgs
    Public Parent As OperationView
End Class
Public Class ChartItem
    'Private vVectorMap As Bitmap
    Private Shared vFont As Font = New Font("Arial", 10)
    Private Shared tFont As Font = New Font("Calibri", 16, FontStyle.Bold)
    Private title As String
    Private descr As String = ""
    Private vVector As VectorMap
    Private sList As New List(Of String)
    Private vIndex As Integer


    Public Sub New()
        AddHandler MolecularInfo.RequireParentChartItem, AddressOf GetParent
    End Sub

    <XmlDescribe(True)> Public WithEvents MolecularInfo As New DNAInfo

    Public Event RequireParent(ByVal sender As Object, ByVal e As RequireParentEventArgs)

    Private Sub MolecularInfo_RequireParentChartItem(ByVal sender As Object, ByVal e As GetChartItemEventArgs) Handles MolecularInfo.RequireParentChartItem
        e.ParentChartItem = Me
    End Sub

    Private ReadOnly Property MapStringLength() As Integer
        Get
            If Parent Is Nothing Then
                Return 1
            Else
                Return Parent.Items.Count.ToString.Length
            End If
        End Get
    End Property

    Public ReadOnly Property Parent() As OperationView
        Get
            Dim rpe As New RequireParentEventArgs
            RaiseEvent RequireParent(Me, rpe)
            Return rpe.Parent
        End Get
    End Property

    Public ReadOnly Property AllMolecularInfo() As List(Of DNAInfo)
        Get
            Dim lv As OperationView = Me.Parent
            Dim mis As New List(Of DNAInfo)
            If Not (lv Is Nothing) Then
                For Each ci As ChartItem In lv.Items
                    mis.Add(ci.MolecularInfo)
                Next
            End If
            Return mis
        End Get
    End Property

    Public Sub ResetEnzyme(ByVal Enzymes As List(Of String))
        If MolecularInfo.DNAs.Count = 1 Then
            vVector = New VectorMap
            If MolecularInfo.RealSize Then
                Dim gf As Nuctions.GeneFile = MolecularInfo.DNAs(1)
                If gf.Iscircular Then
                    If gf.Length > 1800 * Math.PI Then
                        vVector.Width = gf.Length / Math.PI / 10 + 120
                    End If
                Else
                    If gf.Length > 1800 Then
                        vVector.Width = gf.Length / 10 + 120
                    End If
                End If
            Else
                vVector.Width = 300
            End If
            vVector.RestrictionSite = Enzymes
            vVector.GeneFile = MolecularInfo.DNAs(1)
            'vVectorMap = vVector.GetVectorMap
        End If
    End Sub

    Public ReadOnly Property Index() As Integer
        Get
            Return vIndex
        End Get
    End Property
    Public Sub SetIndex(ByVal vID As Integer)
        vIndex = vID
    End Sub

    Public Sub GetParent(ByVal sender As Object, ByVal e As GetChartItemEventArgs)
        e.ParentChartItem = Me
    End Sub

    Public Sub Reload(ByVal di As DNAInfo, ByVal Enzymes As List(Of String))
        If Not MolecularInfo Is Nothing Then
            RemoveHandler MolecularInfo.RequireParentChartItem, AddressOf GetParent
        End If

        If di.DNAs.Count = 1 Then
            vVector = New VectorMap
            If di.RealSize Then
                Dim gf As Nuctions.GeneFile = di.DNAs(1)
                If gf.Iscircular Then
                    If gf.Length > 1800 * Math.PI Then
                        vVector.Width = gf.Length / Math.PI / 10 + 120
                    End If
                Else
                    If gf.Length > 1800 Then
                        vVector.Width = gf.Length / 10 + 120
                    End If
                End If
            Else
                vVector.Width = 300
            End If
            vVector.RestrictionSite = Enzymes
            vVector.GeneFile = di.DNAs(1)
        Else
            vVector = Nothing
        End If

        X = di.DX
        Y = di.DY

        sList.Clear()

        MolecularInfo = di
        AddHandler MolecularInfo.RequireParentChartItem, AddressOf GetParent

        Dim stb As System.Text.StringBuilder

        Select Case MolecularInfo.MolecularOperation
            Case Nuctions.MolecularOperationEnum.Vector
                title = MolecularInfo.Name
            Case Nuctions.MolecularOperationEnum.Enzyme

                title = "Digestion"
                stb = New System.Text.StringBuilder
                For Each s As String In MolecularInfo.Enzyme_Enzymes
                    stb.Append(s)
                    stb.Append(" ")
                Next
                sList.Add(stb.ToString)
            Case Nuctions.MolecularOperationEnum.Gel
                title = "Gel Extraction"

                stb = New System.Text.StringBuilder
                stb.Append("From ")
                stb.Append(MolecularInfo.Gel_Minimum.ToString)
                stb.Append(" to ")
                stb.Append(MolecularInfo.Gel_Maximun.ToString)
                sList.Add(stb.ToString)
            Case Nuctions.MolecularOperationEnum.PCR
                title = "PCR"
                stb = New System.Text.StringBuilder
                stb.Append(MolecularInfo.PCR_FPrimerName)
                stb.Append(": ")
                stb.Append(MolecularInfo.PCR_ForwardPrimer)
                stb.Append(" Tm:")
                stb.Append(Nuctions.CalculateTm(MolecularInfo.PCR_ForwardPrimer, 80 * 0.001, 625 * 0.000000001).Tm.ToString("0.0"))
                stb.Append("/")
                stb.Append(Nuctions.CalculateTm(Nuctions.ParseInnerPrimer(MolecularInfo.PCR_ForwardPrimer), 80 * 0.001, 625 * 0.000000001).Tm.ToString("0.0"))
                sList.Add(stb.ToString)
                stb = New System.Text.StringBuilder
                stb.Append(MolecularInfo.PCR_RPrimerName)
                stb.Append(": ")
                stb.Append(MolecularInfo.PCR_ReversePrimer)
                stb.Append(" Tm:")
                stb.Append(Nuctions.CalculateTm(MolecularInfo.PCR_ReversePrimer, 80 * 0.001, 625 * 0.000000001).Tm.ToString("0.0"))
                stb.Append("/")
                stb.Append(Nuctions.CalculateTm(Nuctions.ParseInnerPrimer(MolecularInfo.PCR_ReversePrimer), 80 * 0.001, 625 * 0.000000001).Tm.ToString("0.0"))
                sList.Add(stb.ToString)
            Case Nuctions.MolecularOperationEnum.Recombination
                title = "Recombination"
                stb = New System.Text.StringBuilder
                stb.Append(MolecularInfo.RecombinationMethod.ToString)
                sList.Add(stb.ToString)
            Case Nuctions.MolecularOperationEnum.Ligation
                title = "Ligation"
                stb = New System.Text.StringBuilder
                stb.Append(MolecularInfo.LigationMethod.ToString)
                sList.Add(stb.ToString)
            Case Nuctions.MolecularOperationEnum.Screen
                Select Case MolecularInfo.Screen_Mode
                    Case Nuctions.ScreenModeEnum.PCR
                        title = "PCR Screening"
                        stb = New System.Text.StringBuilder
                        stb.Append(MolecularInfo.Screen_FName)
                        stb.Append(": ")
                        stb.Append(MolecularInfo.Screen_FPrimer)
                        stb.Append(" Tm:")
                        stb.Append(Nuctions.CalculateTm(MolecularInfo.Screen_FPrimer, 80 * 0.001, 625 * 0.000000001).Tm.ToString("0.0"))
                        stb.Append("��C/")
                        stb.Append(Nuctions.CalculateTm(Nuctions.ParseInnerPrimer(MolecularInfo.Screen_FPrimer), 80 * 0.001, 625 * 0.000000001).Tm.ToString("0.0"))
                        stb.Append("��C")
                        sList.Add(stb.ToString)

                        stb = New System.Text.StringBuilder
                        stb.Append(MolecularInfo.Screen_RName)
                        stb.Append(": ")
                        stb.Append(MolecularInfo.Screen_RPrimer)
                        stb.Append(" Tm:")
                        stb.Append(Nuctions.CalculateTm(MolecularInfo.Screen_RPrimer, 80 * 0.001, 625 * 0.000000001).Tm.ToString("0.0"))
                        stb.Append("��C/")
                        stb.Append(Nuctions.CalculateTm(Nuctions.ParseInnerPrimer(MolecularInfo.Screen_RPrimer), 80 * 0.001, 625 * 0.000000001).Tm.ToString("0.0"))
                        stb.Append("��C")
                        sList.Add(stb.ToString)

                    Case Nuctions.ScreenModeEnum.Features
                        title = "Feature Screening"
                        stb = New System.Text.StringBuilder
                        If MolecularInfo.Screen_OnlyCircular Then stb.Append("Only Circular; ")
                        For Each s As FeatureScreenInfo In MolecularInfo.Screen_Features
                            stb.Append(s.Feature.Name)
                            stb.Append(" <")
                            stb.Append(s.ScreenMethod.ToString)
                            stb.Append(">; ")
                        Next
                        sList.Add(stb.ToString)
                End Select
            Case Nuctions.MolecularOperationEnum.EnzymeAnalysis
                title = "Enzyme Analysis"

                For Each eai As EnzymeAnalysisItem In di.EnzymeAnalysisParamters
                    stb = New System.Text.StringBuilder
                    If eai.Use Then
                        stb.Append(eai.GeneFile.Name)
                        stb.Append(" <")
                        stb.Append(eai.Region)
                        stb.Append(">  Appearace ")

                        Select Case eai.Method
                            Case EnzymeAnalysisEnum.Equal
                                stb.Append("= ")

                            Case EnzymeAnalysisEnum.Greater
                                stb.Append("> ")

                            Case EnzymeAnalysisEnum.Less
                                stb.Append("< ")

                        End Select
                        stb.Append(eai.Value.ToString)
                        sList.Add(stb.ToString)
                    End If
                Next
                sList.Add("Enzyme Found: " + MolecularInfo.OperationDescription)
            Case Nuctions.MolecularOperationEnum.Modify
                Select Case di.Modify_Method
                    Case Nuctions.ModificationMethodEnum.CIAP
                        title = "CIAP Dephospheration"
                    Case Nuctions.ModificationMethodEnum.Klewnow
                        title = "Klewnow Fragment Blunting"
                    Case Nuctions.ModificationMethodEnum.PNK
                        title = "PNK Phospheration"
                    Case Nuctions.ModificationMethodEnum.T4DNAP
                        title = "T4DNAP Blunting"
                End Select
            Case Nuctions.MolecularOperationEnum.Merge
                title = "Merging Sequencing Results"
                sList.Add(IIf(di.OnlySignificant, "Only Consider Long Significant Matches", "Consider All Matches"))
                sList.Add(IIf(di.OnlyExtend, "Only Get Results Longer than Inputs", "Get All Results"))
        End Select
        stb = New System.Text.StringBuilder
        For Each s As Nuctions.GeneFile In MolecularInfo.DNAs
            stb.Append(s.Length.ToString)
            stb.Append("bp ")
            stb.Append(IIf(s.Iscircular, "C; ", "L; "))
        Next
        sList.Add(stb.ToString)
        If di.MolecularOperation <> Nuctions.MolecularOperationEnum.EnzymeAnalysis Then
            descr = di.OperationDescription
        End If
    End Sub

    Public Sub New(ByVal di As DNAInfo, ByVal Enzymes As List(Of String), ByVal vID As Integer)
        vIndex = vID
        Me.Reload(di, Enzymes)
    End Sub
    Dim R As Single
    Dim B As Single
    Dim X As Single
    Dim Y As Single

    Dim sX As Single
    Dim sY As Single
    Dim sR As Single
    Dim sB As Single

    Public Sub StartMove()
        sX = X
        sY = Y
        sR = R
        sB = B
    End Sub
    Public Sub MoveBy(ByVal dvX As Single, ByVal dvY As Single)
        X = sX + dvX
        R = sR + dvX
        Y = sY + dvY
        B = sB + dvY
    End Sub


    Public Sub SaveGeneFile(ByVal Path As String)
        If vVector Is Nothing Then Exit Sub

        Dim regex As New System.Text.RegularExpressions.Regex("[\\/\:\*\?""<>\|]")
        Dim vName As String = MolecularInfo.Name
        vName = regex.Replace(vName, " ")
        If Not Path.EndsWith("\") Then Path += "\"
        vVector.GeneFile.WriteToFile(Path + vIndex.ToString.PadLeft(Me.MapStringLength, "0") + " " + vName + ".gb")
    End Sub

    Public Property Selected() As Boolean
        Get
            Dim opv As OperationView = Parent
            If opv Is Nothing Then
                Return False
            Else
                Return opv.SelectedItems.Contains(Me)
            End If
        End Get
        Set(ByVal value As Boolean)
            Dim opv As OperationView = Parent
            If Not (opv Is Nothing) AndAlso Not opv.SelectedItems.Contains(Me) Then
                opv.SelectedItems.Add(Me)
                opv.Draw()
                opv.OnSelectedIndexChanged()
            End If
        End Set
    End Property

    Public Sub Draw(ByVal g As Graphics, Optional ByVal redrawvector As Boolean = False)
        Dim vX As Single
        Dim vY As Single
        vX = X
        vY = Y
        MolecularInfo.DX = X
        MolecularInfo.DY = Y
        R = X
        Dim vS As SizeF
        Dim vstr As String

        If Not (vVector Is Nothing) Then
            'If redrawvector Then
            vVector.DrawImage(g, X, Y)
            'Else
            '    g.DrawImage(vVectorMap, New PointF(X, Y))
            'End If
            vY += vVector.Height
            R += vVector.Width
        End If
        vstr = IIf(Me.Parent Is Nothing, title, vIndex.ToString.PadLeft(Parent.Items.Count.ToString.Length, "0") + " " + title)
        g.DrawString(vstr, tFont, Brushes.Black, vX, vY)
        vS = g.MeasureString(vstr, tFont)
        R = Math.Max(R, vX + vS.Width)
        vY += vS.Height
        For Each vstr In sList
            g.DrawString(vstr, vFont, Brushes.Black, vX, vY)
            vS = g.MeasureString(vstr, vFont)
            R = Math.Max(R, vX + vS.Width)
            vY += vS.Height
        Next

        If Not (descr Is Nothing) AndAlso descr.Length > 0 Then
            vstr = descr
            g.DrawString(vstr, vFont, Brushes.Red, vX, vY)
            vS = g.MeasureString(vstr, vFont)
            R = Math.Max(R, vX + vS.Width)
            vY += vS.Height
        End If
        B = vY
        g.DrawRectangle(IIf(Selected, Pens.Red, Pens.Blue), X, Y, R - X, B - Y)
        Select Case MolecularInfo.Progress
            Case ProgressEnum.Unstarted
            Case ProgressEnum.Inprogress
                g.FillRectangle(New SolidBrush(Color.FromArgb(32, 255, 0, 0)), X, Y, R - X, B - Y)
            Case ProgressEnum.Finished
                g.FillRectangle(New SolidBrush(Color.FromArgb(32, 0, 255, 0)), X, Y, R - X, B - Y)
        End Select
    End Sub

    Public Sub DrawArrow(ByVal g As Graphics)
        Dim pnts As PointF()
        Dim vx As Vector2
        Dim si As ChartItem

        For Each dnai As DNAInfo In MolecularInfo.Source
            si = dnai.GetParetntChartItem
            vx = Center - si.Center
            pnts = GetArrow(si.GetPosition(vx), GetPosition(-vx), 0, 0)
            g.FillPolygon(Brushes.LightYellow, pnts)
            g.DrawPolygon(Pens.Gray, pnts)
        Next
    End Sub



    Public Function Hittest(ByVal vP As PointF) As Boolean
        Return vP.X > X And vP.X < R And vP.Y > Y And vP.Y < B
    End Function
    Private Shared Function GetArrow(ByVal V0 As Vector2, ByVal VE As Vector2, ByVal prefix As Single, ByVal suffix As Single) As PointF()
        Dim VX As Vector2 = VE - V0
        Dim VY As Vector2 = VX.GetBase.Turn(Math.PI / 2)
        Dim L As Single = VX.GetLength
        If L < (prefix + suffix + 24) Then
            prefix = (L - 24) / 2 + 8
            suffix = (L - 24) / 2 - 8
        End If
        VX = VX.GetBase
        Return New PointF() {V0 + VX * prefix, V0 + VX * prefix + VY * 6, VE - VX * (suffix + 12) + VY * 6, _
                             VE - VX * (suffix + 12) + VY * 12, VE - VX * suffix, _
                             VE - VX * (suffix + 12) - VY * 12, VE - VX * (suffix + 12) - VY * 6, V0 + VX * prefix - VY * 6}
    End Function
    Public Property Left() As Single
        Get
            Return X
        End Get
        Set(ByVal value As Single)
            Dim delta As Single = value - X

            X += delta
            R += delta
        End Set
    End Property
    Public ReadOnly Property Right() As Single
        Get
            Return R
        End Get
    End Property
    Public Property Top() As Single
        Get
            Return Y
        End Get
        Set(ByVal value As Single)
            Dim delta As Single = value - Y
            Y += delta
            B += delta
        End Set
    End Property
    Public ReadOnly Property Bottom() As Single
        Get
            Return B
        End Get
    End Property
    Public ReadOnly Property Center() As Vector2
        Get
            Return New Vector2((X + R) / 2, (Y + B) / 2)
        End Get
    End Property
    Public Function GetPosition(ByVal vt As Vector2) As Vector2
        Dim w As Single = (R - X) / 2
        Dim h As Single = (B - Y) / 2

        If vt.X = 0 And vt.Y = 0 Then
            Return New Vector2((X + R) / 2, B)
        ElseIf vt.Y = 0 Then
            Return New Vector2((X + R) / 2 + w * Math.Sign(vt.X), (Y + B) / 2)
        ElseIf vt.X = 0 Then
            Return New Vector2((X + R) / 2, (Y + B) / 2 + h * Math.Sign(vt.Y))
        Else
            If h * Math.Abs(vt.X) > w * Math.Abs(vt.Y) Then
                Return New Vector2((X + R) / 2 + w * Math.Sign(vt.X), (Y + B) / 2)
            Else
                Return New Vector2((X + R) / 2, (Y + B) / 2 + h * Math.Sign(vt.Y))
            End If
        End If
    End Function

    Public Sub AutoFit()
        If MolecularInfo.Source.Count > 0 Then
            Dim X1 As Single = 0
            Dim Y1 As Single = Single.MinValue
            Dim W As Single = (R - X) / 2

            Dim si As ChartItem
            For Each DNAi As DNAInfo In MolecularInfo.Source
                si = DNAi.GetParetntChartItem
                X1 += si.Center.X
                Y1 = IIf(Y1 > si.Bottom, Y1, si.Bottom)
            Next

            Left = X1 / MolecularInfo.Source.Count - W
            Top = Y1 + 40
        End If
    End Sub

    Public ReadOnly Property Feature() As List(Of Nuctions.Feature)
        Get
            If TypeOf Me.Parent.Parent.Parent.Parent Is WorkControl Then
                Dim wc As WorkControl = Me.Parent.Parent.Parent.Parent
                Return wc.FeatureCol
            Else
                Return Nothing
            End If
        End Get
    End Property
End Class



<XmlDescribe(True)> Public Class DNAInfo
    'common titles
    Private vName As String
    <XmlDescribe(False)> Public Property Name() As String
        Get
            Return vName
        End Get
        Set(ByVal value As String)
            vName = value
        End Set
    End Property
    Public OperationDescription As String
    Private vMolecularOperation As Nuctions.MolecularOperationEnum
    <XmlDescribe(False)> Public Event UpdateImage(ByVal sender As Object, ByVal e As EventArgs)
    <XmlDescribe(False)> Public Property MolecularOperation() As Nuctions.MolecularOperationEnum
        Get
            Return vMolecularOperation
        End Get
        Set(ByVal value As Nuctions.MolecularOperationEnum)
            vMolecularOperation = value
            RaiseEvent UpdateImage(Me, New EventArgs)
        End Set
    End Property
    Public DNAs As New Collection
    Public Calculated As Boolean

    Public File_Filename As String
    Public Enzyme_Enzymes As New List(Of String)
    Public PCR_ForwardPrimer As String
    Public PCR_FPrimerName As String
    Public PCR_ReversePrimer As String
    Public PCR_RPrimerName As String
    Public Modify_Method As Nuctions.ModificationMethodEnum
    'T4DNAP Klewnow CIAP PNK
    Public Screen_Features As New List(Of FeatureScreenInfo)
    Public Screen_OnlyCircular As Boolean
    Public Source As New List(Of DNAInfo)
    Public Editing As Boolean = False
    Public Creating As Boolean = False

    Public Ligation_TriFragment As LigationMethod = Vecute.LigationMethod.Normal2Fragment

    Public LigationMethod As LigationMethod

    'Public FeatureCol As New List(Of Nuctions.Feature)
    Public Gel_Minimum As Integer = 1000
    Public Gel_Maximun As Integer = 1500
    Public SetPosition As Point
    'ScreenMode
    Public Screen_PCRMax As Integer = 1500
    Public Screen_PCRMin As Integer = 1000
    Public Screen_FPrimer As String = ""
    Public Screen_FName As String = "F"
    Public Screen_RPrimer As String = ""
    Public Screen_RName As String = "R"
    Public Screen_Mode As Nuctions.ScreenModeEnum = Nuctions.ScreenModeEnum.Features

    'Recombination
    Public RecombinationMethod As RecombinationMethod

    'EnzymeAnalysis
    Public EnzymeAnalysisParamters As New List(Of EnzymeAnalysisItem)
    Public FetchedEnzymes As New List(Of String)

    'Merge
    Public OnlySignificant As Boolean = True
    Public OnlyExtend As Boolean = True

    <XmlDescribe(False)> Public Event RequireParentChartItem(ByVal sender As Object, ByVal e As GetChartItemEventArgs)

    <XmlDescribe(False)> Public Function GetParetntChartItem() As ChartItem
        Dim pnt As ChartItem = Nothing
        Dim e As New GetChartItemEventArgs
        RaiseEvent RequireParentChartItem(Me, e)
        Return e.ParentChartItem
    End Function

    '��ͼ��Ϣ

    Public DX As Single
    Public DY As Single
    Public RealSize As Boolean

    Public Finished As Boolean = False
    Public Progress As ProgressEnum

    Public Function Clone() As DNAInfo
        Dim dnai As New DNAInfo
        Dim t As Type = GetType(DNAInfo)
        For Each fi As System.Reflection.FieldInfo In t.GetFields(Reflection.BindingFlags.Public Or Reflection.BindingFlags.Instance)
            fi.SetValue(dnai, fi.GetValue(Me))
        Next
        dnai.vName = vName
        dnai.vMolecularOperation = vMolecularOperation
        Return dnai
    End Function

    Public Function Backup() As DNAInfo
        Dim dnai As New DNAInfo
        Dim t As Type = GetType(DNAInfo)
        For Each fi As System.Reflection.FieldInfo In t.GetFields(Reflection.BindingFlags.Public Or Reflection.BindingFlags.Instance)
            fi.SetValue(dnai, fi.GetValue(Me))
        Next
        dnai.Source = New List(Of DNAInfo)
        dnai.Source.AddRange(Source)
        dnai.DNAs = New Collection
        For Each gf As Nuctions.GeneFile In DNAs
            dnai.DNAs.Add(gf)
        Next
        dnai.vName = vName
        dnai.vMolecularOperation = vMolecularOperation
        Return dnai
    End Function

    Public Sub Recover(ByVal DNAi As DNAInfo)
        Dim t As Type = GetType(DNAInfo)
        For Each fi As System.Reflection.FieldInfo In t.GetFields(Reflection.BindingFlags.Public Or Reflection.BindingFlags.Instance)
            fi.SetValue(Me, fi.GetValue(DNAi))
        Next
    End Sub

    Public Sub Calculate()
        Select Case Me.MolecularOperation
            Case Nuctions.MolecularOperationEnum.Enzyme
                'get the vectors from source and analyze enzyme cutting.
                Dim gf As Nuctions.GeneFile
                Dim EARC As Nuctions.EnzymeAnalysis.EnzymeAnalysisResult
                Dim earcCol As New Collection
                Dim info As String
                Dim infoQ As New Queue(Of String)
                Dim dnaList As List(Of Nuctions.GeneFile)
                Dim DNA As Nuctions.GeneFile

                Dim SourceDNA As New Collection
                For Each mi As DNAInfo In Source
                    For Each gf In mi.DNAs
                        SourceDNA.Add(gf)
                    Next
                Next
                For Each gf In SourceDNA
                    EARC = New Nuctions.EnzymeAnalysis.EnzymeAnalysisResult(Enzyme_Enzymes, gf)
                    For Each info In EARC.Confliction
                        infoQ.Enqueue(info)
                    Next
                    earcCol.Add(EARC)
                Next
                If infoQ.Count = 0 Then
                    If DNAs.Count > 0 Then DNAs.Clear()
                    For Each EARC In earcCol
                        dnaList = EARC.CutDNA()
                        For Each DNA In dnaList
                            DNAs.Add(DNA)
                        Next
                    Next
                    Nuctions.AddFeatures(DNAs, GetParetntChartItem.Feature)
                    'refresh the DNA view:

                Else
                    infoQ.Enqueue("Failed to Cut the vectors")
                    Dim fER As New frmErrorReport
                    fER.ShowDialog(infoQ, Me)
                End If
            Case Nuctions.MolecularOperationEnum.Gel

                Dim gf As Nuctions.GeneFile
                Dim gfCol As New Collection

                'get all the DNAs
                For Each mi As DNAInfo In Source
                    For Each gf In mi.DNAs
                        gfCol.Add(gf)
                    Next
                Next

                Dim gelCol As List(Of Nuctions.GeneFile) = Nuctions.ScreenLength(gfCol, Gel_Minimum, Gel_Maximun)
                If DNAs.Count > 0 Then DNAs.Clear()
                For Each gf In gelCol
                    DNAs.Add(gf)
                Next
                Nuctions.AddFeatures(DNAs, GetParetntChartItem.Feature)

            Case Nuctions.MolecularOperationEnum.Ligation
                Dim gf As Nuctions.GeneFile
                Dim gfCol As New List(Of Nuctions.GeneFile)

                'get all the DNAs
                For Each mi As DNAInfo In Source
                    For Each gf In mi.DNAs
                        gfCol.Add(gf)
                    Next
                Next
                'ligate

                Dim lgCol As List(Of Nuctions.GeneFile) = Nothing

                Select Case Ligation_TriFragment
                    Case LigationMethod.Normal2Fragment
                        lgCol = Nuctions.LigateDNA(gfCol, False)
                    Case LigationMethod.Consider3Fragment
                        lgCol = Nuctions.LigateDNA(gfCol, True)
                    Case LigationMethod.MultipleFragmentUnique
                        lgCol = Nuctions.MultipleLinearLigate(gfCol)
                End Select

                If DNAs.Count > 0 Then DNAs.Clear()
                For Each gf In lgCol
                    DNAs.Add(gf)
                Next
                Nuctions.AddFeatures(DNAs, GetParetntChartItem.Feature)
            Case Nuctions.MolecularOperationEnum.Modify
                Dim gf As Nuctions.GeneFile
                Dim gfCol As New Collection
                'get all the DNAs
                For Each mi As DNAInfo In Source
                    For Each gf In mi.DNAs
                        gfCol.Add(gf)
                    Next
                Next
                Dim lgCol As List(Of Nuctions.GeneFile) = Nuctions.ModifyDNA(gfCol, Modify_Method)
                If DNAs.Count > 0 Then DNAs.Clear()
                For Each gf In lgCol
                    DNAs.Add(gf)
                Next
                Nuctions.AddFeatures(DNAs, GetParetntChartItem.Feature)

            Case Nuctions.MolecularOperationEnum.PCR

                Dim gf As Nuctions.GeneFile
                Dim gfCol As New Collection

                'get all the DNAs
                For Each mi As DNAInfo In Source
                    For Each gf In mi.DNAs
                        gfCol.Add(gf)
                    Next
                Next
                Dim pmrList As New List(Of String)
                pmrList.Add(Nuctions.TAGCFilter(PCR_ForwardPrimer))
                pmrList.Add(Nuctions.TAGCFilter(PCR_ReversePrimer))
                Dim gfList As List(Of Nuctions.GeneFile) = Nuctions.PCR(gfCol, pmrList)
                If DNAs.Count > 0 Then DNAs.Clear()
                For Each gf In gfList
                    DNAs.Add(gf)
                Next
                Nuctions.AddFeatures(DNAs, GetParetntChartItem.Feature)

            Case Nuctions.MolecularOperationEnum.Screen
                Dim gf As Nuctions.GeneFile
                Dim gfCol As New Collection

                'get all the DNAs
                If Screen_Mode = Nuctions.ScreenModeEnum.Features Then
                    For Each mi As DNAInfo In Source
                        For Each gf In mi.DNAs
                            gfCol.Add(gf)
                        Next
                    Next
                    Dim gfList As List(Of Nuctions.GeneFile) = Nuctions.ScreenFeature(gfCol, Screen_Features, Screen_OnlyCircular)
                    If DNAs.Count > 0 Then DNAs.Clear()
                    For Each gf In gfList
                        DNAs.Add(gf)
                    Next
                    'Screen needs not additional features
                    Nuctions.AddFeatures(DNAs, GetParetntChartItem.Feature)
                Else

                    Dim errQ As New Queue(Of String)
                    Dim scrErr As Boolean = False


                    'process the PCR Screen
                    For Each mi As DNAInfo In Source
                        For Each gf In mi.DNAs
                            gfCol.Add(gf)
                        Next
                    Next
                    Dim gfList As List(Of Nuctions.GeneFile) = Nuctions.ScreenPCR(gfCol, Screen_FPrimer, Screen_RPrimer, Screen_PCRMax, Screen_PCRMin, Screen_OnlyCircular)
                    If DNAs.Count > 0 Then DNAs.Clear()
                    For Each gf In gfList
                        DNAs.Add(gf)
                    Next
                    Nuctions.AddFeatures(DNAs, GetParetntChartItem.Feature)
                End If
            Case Nuctions.MolecularOperationEnum.Vector

            Case Nuctions.MolecularOperationEnum.Recombination

                Dim gList As New List(Of Nuctions.GeneFile)
                For Each mi As DNAInfo In Source
                    For Each gf As Nuctions.GeneFile In mi.DNAs
                        gList.Add(gf)
                    Next
                Next
                Dim rList As List(Of Nuctions.GeneFile)
                rList = Nuctions.Recombination(gList, RecombinationMethod)
                DNAs.Clear()
                For Each gf As Nuctions.GeneFile In rList
                    DNAs.Add(gf)
                Next
                Nuctions.AddFeatures(DNAs, GetParetntChartItem.Feature)
            Case Nuctions.MolecularOperationEnum.EnzymeAnalysis

                FetchedEnzymes = Nuctions.FindEnzymes(EnzymeAnalysisParamters)
                Dim stb As New System.Text.StringBuilder
                For Each enzm As String In FetchedEnzymes
                    stb.Append(enzm)
                    stb.Append(" ")
                Next
                OperationDescription = stb.ToString
        End Select
    End Sub
End Class

Public Class GetChartItemEventArgs
    Inherits EventArgs
    Public ParentChartItem As ChartItem
End Class

Public Enum LigationMethod
    Normal2Fragment
    Consider3Fragment
    MultipleFragmentUnique
End Enum

Public Enum RecombinationMethod
    Homologous
    LambdaRecombination
    LambdaAttBP
    LambdaAttLR
    HK022AttBP
    HK022AttLR
    Phi80AttBP
    Phi80AttLR
    P21AttBP
    P21AttLR
    P22AttBP
    P22AttLR
    FRT
    LoxP
End Enum

Public Class WorkSpace
    Public ChartItems As New List(Of DNAInfo)
    Public Features As New List(Of Nuctions.Feature)
    Public Enzymes As New List(Of String)
    Public Summary As String
    Public Scale As Single = 1
    Public OffsetX As Single
    Public OffsetY As Single
End Class

Public Class SourceEventArgs
    Inherits EventArgs
    Public Target As DNAInfo
End Class

Public Enum ProgressEnum As Integer
    Unstarted
    Inprogress
    Finished
End Enum