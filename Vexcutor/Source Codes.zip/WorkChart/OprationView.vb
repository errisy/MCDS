﻿Public Class OperationView
    Private smList As New List(Of ChartItem)
    Private EnzymeSites As List(Of String)
    Public Menu As ContextMenuStrip

    Public Property ScaleValue() As Single
        Get
            Return vScale
        End Get
        Set(ByVal value As Single)
            vScale = value
        End Set
    End Property

    Public Property Offset() As PointF
        Get
            Return New PointF(offsetX, offsetY)
        End Get
        Set(ByVal value As PointF)
            offsetX = value.X
            offsetY = value.Y
        End Set
    End Property

    Public ReadOnly Property SelectedItems() As List(Of ChartItem)
        Get
            Return vSelectedItems
        End Get
    End Property

    Public ReadOnly Property Items() As List(Of ChartItem)
        Get
            Return smList
        End Get
    End Property

    Public ReadOnly Property EnzymeCol() As List(Of String)
        Get
            Return EnzymeSites
        End Get
    End Property

    Public Function Add(ByVal vDNA As DNAInfo, ByVal Enzymes As List(Of String)) As ChartItem
        Dim ci As ChartItem
        ci = New ChartItem(vDNA, Enzymes, smList.Count)
        AddHandler ci.RequireParent, AddressOf OnRequireParent
        smList.Add(ci)
        EnzymeSites = Enzymes
        Return ci
    End Function


    Public Sub Remove(ByVal vItem As ChartItem)
        RemoveHandler vItem.RequireParent, AddressOf OnRequireParent
        smList.Remove(vItem)
        For Each ci As ChartItem In smList
            If ci.MolecularInfo.Source.Contains(vItem.MolecularInfo) Then ci.MolecularInfo.Source.Remove(vItem.MolecularInfo)
        Next
        ResetIndex()
        Draw()
    End Sub

    Public Sub ResetIndex()
        Dim i As Integer = 0
        For Each ci As ChartItem In smList
            ci.SetIndex(i)
            i += 1
        Next
    End Sub

    Public Sub OnRequireParent(ByVal sender As Object, ByVal e As RequireParentEventArgs)
        e.Parent = Me
    End Sub

    Public Sub LoadSummary(ByVal Source As List(Of DNAInfo), ByVal Enzymes As List(Of String))
        smList.Clear()
        Dim ci As ChartItem
        For Each di As DNAInfo In Source
            ci = New ChartItem(di, Enzymes, smList.Count)
            AddHandler ci.RequireParent, AddressOf OnRequireParent
            smList.Add(ci)
        Next
        EnzymeSites = Enzymes
    End Sub

    Public Sub Draw()
        Dim g As Graphics = bpbMain.BufferedGraphics
        If vSourceMode Then
            g.Clear(Color.LightCyan)
        Else
            g.Clear(Color.White)
        End If

        g.ResetTransform()
        g.SmoothingMode = Drawing2D.SmoothingMode.HighQuality
        g.InterpolationMode = Drawing2D.InterpolationMode.Low
        g.ScaleTransform(vScale, vScale)
        g.TranslateTransform(offsetX, offsetY)
        For Each si As ChartItem In smList
            si.Draw(g, True)
        Next
        For Each si As ChartItem In smList
            si.DrawArrow(g)
        Next
        bpbMain.Draw()
    End Sub

    Dim RectSelChanged As Boolean

    Public Sub DrawRect()
        Dim g As Graphics = bpbMain.BufferedGraphics
        If vSourceMode Then
            g.Clear(Color.LightCyan)
        Else
            g.Clear(Color.White)
        End If
        g.ResetTransform()
        g.SmoothingMode = Drawing2D.SmoothingMode.HighQuality
        g.InterpolationMode = Drawing2D.InterpolationMode.Low
        g.ScaleTransform(vScale, vScale)
        g.TranslateTransform(offsetX, offsetY)
        Dim vL As Single = Math.Min(startX, rectX)
        Dim vR As Single = Math.Max(startX, rectX)
        Dim vT As Single = Math.Min(startY, rectY)
        Dim vB As Single = Math.Max(startY, rectY)

        For Each si As ChartItem In smList
            If si.Left < vR And si.Right > vL And si.Top < vB And si.Bottom > vT And (Not vSelectedItems.Contains(si)) Then
                vSelectedItems.Add(si)
                RectSelChanged = True
            End If
            If Not (si.Left < vR And si.Right > vL And si.Top < vB And si.Bottom > vT) And vSelectedItems.Contains(si) Then
                vSelectedItems.Remove(si)
                RectSelChanged = True
            End If
            si.Draw(g, True)
        Next

        For Each si As ChartItem In smList
            si.DrawArrow(g)
        Next
        If recting Then g.DrawRectangle(Pens.OrangeRed, vL, vT, vR - vL, vB - vT)
        bpbMain.Draw()
    End Sub

    Dim offsetX As Single
    Dim offsetY As Single
    Dim oldX As Single
    Dim oldY As Single
    Dim startX As Single
    Dim startY As Single
    Dim vScale As Single = 1
    Dim dragging As Boolean = False
    Dim moving As Boolean = False
    Dim draggingItem As ChartItem
    'x2 = x1*scale + offset
    Dim relatedItems As New List(Of ChartItem)
    Dim vSelectedItems As New List(Of ChartItem)
    Public Event SelectedIndexChanged(ByVal sender As Object, ByVal e As EventArgs)

    Public Sub OnSelectedIndexChanged()
        RaiseEvent SelectedIndexChanged(Me, New EventArgs)
        Me.Focus()
    End Sub

    Public Sub FindRelatedItems()
        Dim cnLevel As ChartItem

        Dim ntLevel As New List(Of ChartItem)

        relatedItems.Clear()

        cnLevel = draggingItem



        While Not (cnLevel Is Nothing)

            ntLevel.Clear()
            '再寻找下一层


            For Each si As ChartItem In smList

                If si.MolecularInfo.Source.Count = 1 And si.MolecularInfo.Source.Contains(cnLevel.MolecularInfo) Then
                    ntLevel.Add(si)
                End If
            Next
            If ntLevel.Count <> 1 Then Exit While
            cnLevel = ntLevel(0)
            cnLevel.AutoFit()
            '排列下一层
            relatedItems.Add(cnLevel)
        End While
        Draw()
    End Sub

    Dim vMenuLocation As PointF

    Public ReadOnly Property MenuLocation() As PointF
        Get
            Return vMenuLocation
        End Get
    End Property

    Dim Grabbing As Boolean = False
    Dim recting As Boolean = False

    Private Sub bpbMain_MouseDown(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles bpbMain.MouseDown
        Me.Focus()
        Select Case e.Button
            Case Windows.Forms.MouseButtons.Left
                If moving Then
                    oldX = offsetX
                    oldY = offsetY
                    startX = e.X
                    startY = e.Y
                    Grabbing = True
                Else
                    Dim si As ChartItem
                    Dim vp As PointF
                    vp = New PointF(e.X / vScale - offsetX, e.Y / vScale - offsetY)
                    For i As Integer = smList.Count - 1 To 0 Step -1
                        si = smList(i)
                        If si.Hittest(vp) Then

                            startX = vp.X
                            startY = vp.Y
                            dragging = True
                            draggingItem = si
                            Select Case ModifierKeys
                                Case Keys.Control
                                    If Not (vSelectedItems.Contains(si)) Then
                                        vSelectedItems.Add(si)
                                        Draw()
                                        OnSelectedIndexChanged()
                                    End If
                                Case Keys.Shift
                                    If Not (vSelectedItems.Count = 1 And vSelectedItems.Contains(si)) Then
                                        vSelectedItems.Clear()
                                        vSelectedItems.Add(si)
                                        OnSelectedIndexChanged()
                                    End If
                                    FindRelatedItems()
                                    Draw()
                                Case Else
                                    If Not (vSelectedItems.Count = 1 And vSelectedItems.Contains(si)) Then
                                        vSelectedItems.Clear()
                                        vSelectedItems.Add(si)
                                        Draw()
                                        OnSelectedIndexChanged()
                                    End If
                            End Select
                            For Each ci As ChartItem In vSelectedItems
                                ci.StartMove()
                            Next
                            Exit For
                        End If
                    Next
                    If Not dragging And Not (ModifierKeys = Keys.Control) Then
                        vSelectedItems.Clear()
                        OnSelectedIndexChanged()
                        recting = True
                        vp = New PointF(e.X / vScale - offsetX, e.Y / vScale - offsetY)
                        startX = vp.X
                        startY = vp.Y
                        RectSelChanged = False
                        Draw()

                    End If
                End If
            Case Windows.Forms.MouseButtons.Right
                Dim vp As PointF
                vp = New PointF(e.X / vScale - offsetX, e.Y / vScale - offsetY)
                If Not (Menu Is Nothing) Then
                    vMenuLocation = vp
                    Me.Menu.Show(Me, e.Location)
                End If

        End Select
    End Sub
    Dim rectX As Single
    Dim rectY As Single

    Private Sub bpbMain_MouseMove(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles bpbMain.MouseMove
        If dragging Then
            Dim vp As New PointF(e.X / vScale - offsetX, e.Y / vScale - offsetY)
            For Each ci As ChartItem In vSelectedItems
                ci.MoveBy(vp.X - startX, vp.Y - startY)
            Next
            If ModifierKeys = Keys.Shift Then
                For Each si As ChartItem In relatedItems
                    si.AutoFit()
                Next
            End If
            Draw()
        End If
        If recting Then
            Dim vp As New PointF(e.X / vScale - offsetX, e.Y / vScale - offsetY)
            rectX = vp.X
            rectY = vp.Y
            DrawRect()
        End If
        If Grabbing Then

            offsetX = oldX + (e.X - startX) / vScale
            offsetY = oldY + (e.Y - startY) / vScale
            Draw()
        End If
    End Sub

    Private vSourceMode As Boolean

    Public Property SourceMode() As Boolean
        Get
            Return vSourceMode
        End Get
        Set(ByVal value As Boolean)
            vSourceMode = value
            Draw()
        End Set
    End Property

    Public Event PositionChanged(ByVal sender As Object, ByVal e As EventArgs)
    Private Sub bpbMain_MouseUp(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles bpbMain.MouseUp
        If dragging Then
            Dim vp As New PointF(e.X / vScale - offsetX, e.Y / vScale - offsetY)
            For Each ci As ChartItem In vSelectedItems
                ci.MoveBy(vp.X - startX, vp.Y - startY)
            Next
            If ModifierKeys = Keys.Shift Then
                For Each si As ChartItem In relatedItems
                    si.AutoFit()
                Next
            End If
            Draw()
            dragging = False
            If (vp.X - startX) <> 0 Or (vp.Y - startY) <> 0 Then
                RaiseEvent PositionChanged(Me, New EventArgs)
            End If
        End If
        If recting Then
            Dim vp As New PointF(e.X / vScale - offsetX, e.Y / vScale - offsetY)
            rectX = vp.X
            rectY = vp.Y
            recting = False
            DrawRect()
            If RectSelChanged Then
                RaiseEvent SelectedIndexChanged(Me, New EventArgs)
                RectSelChanged = False
            End If
        End If
        If Grabbing Then
            offsetX = oldX + (e.X - startX) / vScale
            offsetY = oldY + (e.Y - startY) / vScale
            Grabbing = False
            Draw()
        End If
    End Sub

    Private Sub frmSummary_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Me.KeyDown
        Select Case e.KeyCode
            Case Keys.Space

                moving = True
            Case Keys.W
                offsetY -= 200
                Draw()
            Case Keys.S
                offsetY += 200
                Draw()
            Case Keys.A
                offsetX -= 200
                Draw()
            Case Keys.D
                offsetX += 200
                Draw()
            Case Keys.Z
                Dim os As Single = vScale
                vScale = vScale * 1.25
                If vScale > 10 Then vScale = 10
                If vScale < 0.01 Then vScale = 0.01
                offsetX += Width / 2 / vScale - Width / 2 / os
                offsetY += Height / 2 / vScale - Height / 2 / os
                Draw()
            Case Keys.X
                Dim os As Single = vScale
                vScale = vScale / 1.25
                If vScale > 10 Then vScale = 10
                If vScale < 0.01 Then vScale = 0.01
                offsetX += Width / 2 / vScale - Width / 2 / os
                offsetY += Height / 2 / vScale - Height / 2 / os
                Draw()
        End Select
    End Sub
    Public Sub SavePicture()
        Dim L As Single
        Dim R As Single
        Dim T As Single
        Dim B As Single
        Dim NotSet As Boolean = True
        For Each si As ChartItem In smList
            If NotSet Then
                L = si.Left
                R = si.Right
                T = si.Top
                B = si.Bottom
                NotSet = False
            Else
                L = IIf(L < si.Left, L, si.Left)
                T = IIf(T < si.Top, T, si.Top)
                R = IIf(R > si.Right, R, si.Right)
                B = IIf(B > si.Bottom, B, si.Bottom)
            End If
        Next

        If R - L > 0 And B - T > 0 Then
            sfdPic.FileName = Me.Text
            If sfdPic.ShowDialog = Windows.Forms.DialogResult.OK Then


                Dim ofsX As Single = L - 10

                Dim ofsY As Single = T - 10

                Dim bitmap As New Bitmap(R - L + 20, B - T + 20, Imaging.PixelFormat.Format32bppArgb)
                Dim vg As Graphics = Graphics.FromImage(bitmap)
                Dim hdc As IntPtr = vg.GetHdc
                Dim emf As New System.Drawing.Imaging.Metafile(sfdPic.FileName, hdc, Imaging.EmfType.EmfPlusDual)
                Dim g As Graphics = Graphics.FromImage(emf)
                g.Clear(Color.White)
                g.ResetTransform()
                g.SmoothingMode = Drawing2D.SmoothingMode.HighQuality
                g.InterpolationMode = Drawing2D.InterpolationMode.HighQualityBicubic
                g.TranslateTransform(-ofsX, -ofsY)
                For Each si As ChartItem In smList
                    si.Draw(g, True)
                Next
                For Each si As ChartItem In smList
                    si.DrawArrow(g)
                Next
                g.Dispose()
                emf.Dispose()
                vg.ReleaseHdc()
                bitmap.Dispose()
            End If
        End If
    End Sub

    Public Sub SavePictureTo(ByVal vFilename As String)
        Dim L As Single
        Dim R As Single
        Dim T As Single
        Dim B As Single
        Dim NotSet As Boolean = True
        For Each si As ChartItem In smList
            If NotSet Then
                L = si.Left
                R = si.Right
                T = si.Top
                B = si.Bottom
                NotSet = False
            Else
                L = IIf(L < si.Left, L, si.Left)
                T = IIf(T < si.Top, T, si.Top)
                R = IIf(R > si.Right, R, si.Right)
                B = IIf(B > si.Bottom, B, si.Bottom)
            End If
        Next

        If R - L > 0 And B - T > 0 Then
            sfdPic.FileName = Me.Text



            Dim ofsX As Single = L - 10

            Dim ofsY As Single = T - 10

            Dim bitmap As New Bitmap(R - L + 20, B - T + 20, Imaging.PixelFormat.Format32bppArgb)

            Dim vg As Graphics = Graphics.FromImage(bitmap)

            Dim hdc As IntPtr = vg.GetHdc

            'bitmap.GetHbitmap()
            Dim emf As New System.Drawing.Imaging.Metafile(vFilename, hdc, Imaging.EmfType.EmfPlusDual)
            Dim g As Graphics = Graphics.FromImage(emf)
            g.Clear(Color.White)
            g.ResetTransform()
            g.SmoothingMode = Drawing2D.SmoothingMode.HighQuality
            g.InterpolationMode = Drawing2D.InterpolationMode.HighQualityBicubic
            g.TranslateTransform(-ofsX, -ofsY)
            For Each si As ChartItem In smList
                si.DrawArrow(g)
            Next
            For Each si As ChartItem In smList
                si.Draw(g, True)
            Next
            g.Dispose()

            emf.Dispose()
            vg.ReleaseHdc()
            bitmap.Dispose()

        End If
    End Sub

    Public Sub SaveFilesTo(ByVal DirectoryPath As String)
        For Each si As ChartItem In smList
            si.SaveGeneFile(DirectoryPath)
        Next
    End Sub

    Private Sub bpbMain_MouseDoubleClick(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles bpbMain.MouseDoubleClick
        Dim si As ChartItem
        For i As Integer = smList.Count - 1 To 0 Step -1
            si = smList(i)
            Dim vp As New PointF(e.X / vScale - offsetX, e.Y / vScale - offsetY)
            If si.Hittest(vp) Then
                si.AutoFit()
                dragging = False
                Draw()
                Exit For
            End If
        Next
    End Sub

    Private Sub OperationView_KeyUp(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Me.KeyUp
        Select Case e.KeyCode
            Case Keys.Space
                moving = False
        End Select
    End Sub

    Private Sub bpbMain_MouseWheel(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles Me.MouseWheel
        Select Case ModifierKeys
            Case Keys.Control
                Dim os As Single = vScale
                vScale = vScale * (1.25) ^ (e.Delta / 120)
                If vScale > 10 Then vScale = 10
                If vScale < 0.01 Then vScale = 0.01
                offsetX += e.X / vScale - e.X / os
                offsetY += e.Y / vScale - e.Y / os
                Draw()
            Case Keys.Shift
                offsetX += e.Delta / 2 / vScale
                Draw()

            Case Else
                offsetY += e.Delta / 2 / vScale
                Draw()

        End Select

    End Sub

    Private Sub bpbMain_Resize(ByVal sender As Object, ByVal e As System.EventArgs) Handles bpbMain.SizeChanged
        Draw()
    End Sub

    Private Sub SaveToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        SavePicture()
    End Sub

    Public Sub AutoArragne()

        Dim cnLevel As New List(Of ChartItem)

        For Each si As ChartItem In smList
            If si.MolecularInfo.Source.Count = 0 Then
                cnLevel.Add(si)
            End If
        Next

        '在顶层排列

        Dim vX As Single
        vX = 0
        Dim w As Single
        For Each si As ChartItem In cnLevel
            w = si.Right - si.Left
            si.Left = vX
            si.Top = 0
            vX += w + 100
        Next

        '寻找下一层
        Dim ntLevel As New List(Of ChartItem)

        For Each si As ChartItem In smList
            For Each ci As ChartItem In cnLevel
                If si.MolecularInfo.Source.Contains(ci.MolecularInfo) Then
                    ntLevel.Add(si)
                    Exit For
                End If
            Next
        Next

        While ntLevel.Count > 0


            cnLevel.Clear()
            cnLevel.AddRange(ntLevel)
            ntLevel.Clear()

            '排列下一层
            For Each si As ChartItem In cnLevel
                si.AutoFit()
            Next

            '再寻找下一层
            For Each si As ChartItem In smList
                For Each ci As ChartItem In cnLevel
                    If si.MolecularInfo.Source.Contains(ci.MolecularInfo) Then
                        ntLevel.Add(si)
                        Exit For
                    End If
                Next
            Next
        End While
        Draw()
    End Sub

    Private Sub AutoArragneToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        AutoArragne()
    End Sub
    Public Sub AutoFitChildren()
        Dim cnLevel As New List(Of ChartItem)
        cnLevel.Add(draggingItem)

        Dim ntLevel As New List(Of ChartItem)

        For Each si As ChartItem In smList
            For Each ci As ChartItem In cnLevel
                If si.MolecularInfo.Source.Contains(ci.MolecularInfo) Then
                    ntLevel.Add(si)
                    Exit For
                End If
            Next
        Next

        While ntLevel.Count > 0


            cnLevel.Clear()
            cnLevel.AddRange(ntLevel)
            ntLevel.Clear()

            '排列下一层
            For Each si As ChartItem In cnLevel
                si.AutoFit()
            Next

            '再寻找下一层
            For Each si As ChartItem In smList
                For Each ci As ChartItem In cnLevel
                    If si.MolecularInfo.Source.Contains(ci.MolecularInfo) Then
                        ntLevel.Add(si)
                        Exit For
                    End If
                Next
            Next
        End While
        Draw()
    End Sub

    Public Sub FitChildrenStepByStep()
        Dim cnLevel As New List(Of ChartItem)
        cnLevel.Add(draggingItem)

        Dim ntLevel As New List(Of ChartItem)

        For Each si As ChartItem In smList
            For Each ci As ChartItem In cnLevel
                If si.MolecularInfo.Source.Contains(ci.MolecularInfo) Then
                    ntLevel.Add(si)
                    Exit For
                End If
            Next
        Next

        While ntLevel.Count > 0

            cnLevel.Clear()
            cnLevel.AddRange(ntLevel)
            ntLevel.Clear()

            '排列下一层
            For Each si As ChartItem In cnLevel
                si.AutoFit()
            Next

            If MsgBox("Continue Next Level?", MsgBoxStyle.YesNo, "Fit Children Step by Step") = MsgBoxResult.No Then Exit While

            '再寻找下一层
            For Each si As ChartItem In smList
                For Each ci As ChartItem In cnLevel
                    If si.MolecularInfo.Source.Contains(ci.MolecularInfo) Then
                        ntLevel.Add(si)
                        Exit For
                    End If
                Next
            Next
            Draw()
        End While
    End Sub

    Public Sub SetEnzymes(ByVal sites As List(Of String))
        For Each ci As ChartItem In smList
            ci.ResetEnzyme(sites)
        Next
        EnzymeSites = sites
        Draw()
    End Sub

    Private Sub AutoFitChildrenToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        AutoFitChildren()
    End Sub

    Private Sub StepFitChildrenToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        FitChildrenStepByStep()
    End Sub
End Class

