﻿Public Structure Vector2
    Public X As Single
    Public Y As Single
    Public Sub New(ByVal vX As Single, ByVal vY As Single)
        X = vX
        Y = vY
    End Sub
    Public Sub New(ByVal vP As PointF)
        X = vP.X
        Y = vP.Y
    End Sub
    Public Sub New(ByVal vP As Point)
        X = vP.X
        Y = vP.Y
    End Sub
    Public Function GetBase() As Vector2
        If X = 0 And Y = 0 Then
            Return New Vector2(0, 0)
        Else
            Return Me / Math.Sqrt(X * X + Y * Y)
        End If
    End Function
    Public Function Turn(ByVal Rad As Single) As Vector2
        Dim vX As Single = X * Math.Cos(Rad) - Y * Math.Sin(Rad)
        Dim vY As Single = X * Math.Sin(Rad) + Y * Math.Cos(Rad)
        Return New Vector2(vX, vY)
    End Function
    Public Function GetLength() As Single
        Return Math.Sqrt(X * X + Y * Y)
    End Function
    Public Shared Widening Operator CType(ByVal vPoint As PointF) As Vector2
        Return New Vector2(vPoint.X, vPoint.Y)
    End Operator
    Public Shared Widening Operator CType(ByVal vPoint As Point) As Vector2
        Return New Vector2(vPoint.X, vPoint.Y)
    End Operator
    Public Shared Narrowing Operator CType(ByVal vVector As Vector2) As PointF
        Return New PointF(vVector.X, vVector.Y)
    End Operator
    Public Shared Narrowing Operator CType(ByVal vVector As Vector2) As Point
        Return New Point(vVector.X, vVector.Y)
    End Operator
    Public Shared Operator -(ByVal vVector1 As Vector2, ByVal vVector2 As Vector2) As Vector2
        Return New Vector2(vVector1.X - vVector2.X, vVector1.Y - vVector2.Y)
    End Operator
    Public Shared Operator -(ByVal vVector2 As Vector2) As Vector2
        Return New Vector2(-vVector2.X, -vVector2.Y)
    End Operator
    Public Shared Operator +(ByVal vVector1 As Vector2, ByVal vVector2 As Vector2) As Vector2
        Return New Vector2(vVector1.X + vVector2.X, vVector1.Y + vVector2.Y)
    End Operator
    Public Shared Operator *(ByVal vVector1 As Vector2, ByVal vValue As Single) As Vector2
        Return New Vector2(vVector1.X * vValue, vVector1.Y * vValue)
    End Operator
    Public Shared Operator /(ByVal vVector1 As Vector2, ByVal vValue As Single) As Vector2
        Return New Vector2(vVector1.X / vValue, vVector1.Y / vValue)
    End Operator
End Structure
