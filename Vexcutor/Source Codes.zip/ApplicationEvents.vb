Namespace My

    ' The following events are availble for MyApplication:
    ' 
    ' Startup: Raised when the application starts, before the startup form is created.
    ' Shutdown: Raised after all application forms are closed.  This event is not raised if the application terminates abnormally.
    ' UnhandledException: Raised if the application encounters an unhandled exception.
    ' StartupNextInstance: Raised when launching a single-instance application and the application is already active. 
    ' NetworkAvailabilityChanged: Raised when the network connection is connected or disconnected.
    Partial Friend Class MyApplication
        Private Sub MyApplication_Startup( _
            ByVal sender As Object, _
            ByVal e As Microsoft.VisualBasic.ApplicationServices.StartupEventArgs _
        ) Handles Me.Startup


            ProcessCommand(e.CommandLine)

        End Sub
        Private Sub MyApplication_Startup( _
            ByVal sender As Object, _
            ByVal e As Microsoft.VisualBasic.ApplicationServices.StartupNextInstanceEventArgs _
        ) Handles Me.StartupNextInstance
            e.BringToForeground = True
            ProcessCommand(e.CommandLine)
        End Sub
        Private Sub ProcessCommand(ByVal lines As System.Collections.ObjectModel.ReadOnlyCollection(Of String))
            'Dim fr As New IO.StreamWriter("D:\gen.txt")
            Dim fileOK As Boolean = True
            For Each s As String In lines
                fileOK = True
                Try
                    Dim fi As New IO.FileInfo(s)
                Catch ex As Exception
                    fileOK = False
                End Try
                If fileOK Then frmMain.OpenFile(s)
            Next
        End Sub
    End Class

End Namespace

