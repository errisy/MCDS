﻿
Partial Public Class Nuctions

    Public Class Energy
        Public dS As Single
        Public dH As Single
        Public dG As Single
        Public Sub New(ByVal vH As Single, ByVal vS As Single, ByVal vG As Single)
            dS = vS
            dH = vH
            dG = vG
        End Sub
    End Class

    Public Shared EnergyDict As New Dictionary(Of String, Energy)

    Public Structure OligoInfo
        Public Tm As Single
        Public dG As Single
        Public Sub New(ByVal vTm As Single, ByVal vdG As Single)
            Tm = vTm
            dG = vdG
        End Sub
    End Structure

    Public Shared Function CalculateTm(ByVal Oligo As String, ByVal Na As Single, ByVal C As Single) As OligoInfo
        Static R As Single = 1.987
        Static S0 As Single = -10.8
        Static regGC As New System.Text.RegularExpressions.Regex("[GC][GC]")
        Static regAT As New System.Text.RegularExpressions.Regex("[AT][AT]")
        If EnergyDict.Count = 0 Then
            Dim ed As Energy
            '一种16种相邻序列
            'AA/TT -9.1 -24.0 -1.9
            ed = New Energy(-9.1, -24.0, -1.9)
            EnergyDict.Add("AA", ed)
            EnergyDict.Add("TT", ed)
            'AT/TA -8.6 -23.9 -1.5
            ed = New Energy(-8.6, -23.9, -1.5)
            EnergyDict.Add("AT", ed)
            'TA/AT -6.0 -16.9 -1.0
            ed = New Energy(-6.0, -16.9, -1.0)
            EnergyDict.Add("TA", ed)
            'CA/GT -5.8 -12.9 -2.0
            ed = New Energy(-5.8, -12.9, -2.0)
            EnergyDict.Add("CA", ed)
            EnergyDict.Add("TG", ed)
            'GT/CA -6.5 -17.3 -1.3
            ed = New Energy(-6.5, -17.3, -1.3)
            EnergyDict.Add("GT", ed)
            EnergyDict.Add("AC", ed)
            'CT/GA -7.8 -20.8 -1.6
            ed = New Energy(-7.8, -20.8, -1.6)
            EnergyDict.Add("CT", ed)
            EnergyDict.Add("AG", ed)
            'GA/CT -5.6 -13.5 -1.6
            ed = New Energy(-5.6, -13.5, -1.6)
            EnergyDict.Add("GA", ed)
            EnergyDict.Add("TC", ed)
            'CG/GC -11.9 -27.8 -3.6
            ed = New Energy(-11.9, -27.8, -3.6)
            EnergyDict.Add("CG", ed)
            'GC/CG -11.1 -26.7 -3.1
            ed = New Energy(-11.1, -26.7, -3.1)
            EnergyDict.Add("GC", ed)
            'GG/CC -11.0 -26.6 -3.1
            ed = New Energy(-11.0, -26.6, -3.1)
            EnergyDict.Add("GG", ed)
            EnergyDict.Add("CC", ed)
        End If

        Oligo = TAGCFilter(Oligo)
        Dim key As String
        Dim H As Single
        Dim S As Single
        Dim G As Single

        For i As Integer = 0 To Oligo.Length - 2
            key = Oligo.Substring(i, 2)
            H += EnergyDict(key).dH
            G += EnergyDict(key).dG
            S += EnergyDict(key).dS
        Next
        S += S0
        H = H * 1000

        If Oligo.Length > 2 Then
            If Not regAT.IsMatch(Oligo) Then
                G += 6
            ElseIf regGC.IsMatch(Oligo) Then
                G += 5
            Else

            End If
        End If

        'Therm. Tm = dH°- 273.15 + 16.6(log[Na+]) dS° + dSo° + R(ln(c/4))
        Return New OligoInfo(H / (S + S0 + R * Math.Log(C / 4)) - 273.15 + 16.6 * Math.Log10(Na), G)
    End Function

    Public Class PrimerAnalysisResult
        Public Primers As New Dictionary(Of String, String)
        Public Hairpins As New Dictionary(Of String, List(Of StructInfo))
        Public Dimers As New Dictionary(Of String, List(Of StructInfo))
        Public CrossDimers As New List(Of StructInfo)
        Public Primings As New Dictionary(Of String, List(Of PrimeInfo))
        Public Products As List(Of GeneFile)
    End Class

    Public Class StructInfo
        Implements System.IComparable(Of StructInfo)
        Public K1 As String
        Public K2 As String
        Public S1 As Integer
        Public S2 As Integer
        Public E1 As Integer
        Public E2 As Integer
        Public AG As Single
        Public Function CompareTo(ByVal other As StructInfo) As Integer Implements System.IComparable(Of StructInfo).CompareTo
            Return Math.Sign(AG - other.AG)
        End Function
    End Class

    Public Class PrimeInfo
        Implements System.IComparable(Of PrimeInfo)
        Public K1 As String
        Public K2 As GeneFile
        Public IsRC As Boolean
        Public S1 As Integer
        Public S2 As Integer
        Public E1 As Integer
        Public E2 As Integer
        Public AG As Single
        Public Function CompareTo(ByVal other As PrimeInfo) As Integer Implements System.IComparable(Of PrimeInfo).CompareTo
            Return Math.Sign(AG - other.AG)
        End Function
    End Class

    Public Shared Function AnalyzePrimer(ByVal Primers As Dictionary(Of String, String), ByVal temps As List(Of GeneFile), ByVal Na As Single, ByVal C As Single) As PrimerAnalysisResult


        Dim reg As System.Text.RegularExpressions.Regex
        Dim info As StructInfo
        Dim pmr As String

        Dim PAR As New PrimerAnalysisResult

        For Each key As String In Primers.Keys
            pmr = Primers(key)
            If pmr Is Nothing OrElse pmr.Length < 5 Then Continue For
            PAR.Primers.Add(key, pmr)
        Next

        If PAR.Primers.Count = 0 Then
            PAR.Products = New List(Of GeneFile)
            Return PAR
        End If

        '分析发卡
        info = New StructInfo
        For Each key As String In Primers.Keys
            pmr = Primers(key)


            '分析发卡
            PAR.Hairpins.Add(key, New List(Of StructInfo))
            For l As Integer = 3 To pmr.Length
                For i As Integer = 0 To pmr.Length - l
                    reg = New System.Text.RegularExpressions.Regex(ReverseComplement(pmr.Substring(i, l)))
                    For Each mt As System.Text.RegularExpressions.Match In reg.Matches(pmr)
                        If mt.Index + mt.Length < i - 3 Or i + l + 3 < mt.Index Then
                            Dim AG As Single = CalculateTm(mt.Captures(0).Value, Na, C).dG
                            info = New StructInfo
                            info.S1 = i
                            info.S2 = mt.Index
                            info.E1 = i + l
                            info.E2 = mt.Index + l
                            info.AG = AG
                            PAR.Hairpins(key).Add(info)
                        End If
                    Next
                Next
            Next
            PAR.Hairpins(key).Sort()
            '二聚体
            PAR.Dimers.Add(key, New List(Of StructInfo))
            For l As Integer = 3 To pmr.Length
                For i As Integer = 0 To pmr.Length - l
                    reg = New System.Text.RegularExpressions.Regex(ReverseComplement(pmr.Substring(i, l)))
                    For Each mt As System.Text.RegularExpressions.Match In reg.Matches(pmr)
                        Dim AG As Single = CalculateTm(mt.Captures(0).Value, Na, C).dG
                        info = New StructInfo
                        info.S1 = i
                        info.S2 = mt.Index
                        info.E1 = i + l
                        info.E2 = mt.Index + l
                        info.AG = AG
                        PAR.Dimers(key).Add(info)
                    Next
                Next
            Next
            PAR.Dimers(key).Sort()
            '交叉二聚体
            For l As Integer = 3 To pmr.Length
                For i As Integer = 0 To pmr.Length - l
                    reg = New System.Text.RegularExpressions.Regex(ReverseComplement(pmr.Substring(i, l)))
                    Dim started As Boolean = False
                    For Each rKey As String In Primers.Keys
                        If rKey <> key And Not started Then

                        ElseIf rKey = key Then
                            started = True
                        ElseIf started Then
                            Dim pmr2 As String = Primers(rKey)
                            For Each mt As System.Text.RegularExpressions.Match In reg.Matches(pmr2)
                                Dim AG As Single = CalculateTm(mt.Captures(0).Value, Na, C).dG

                                info = New StructInfo
                                info.K1 = key
                                info.K2 = rKey
                                info.S1 = i
                                info.S2 = mt.Index
                                info.E1 = i + l
                                info.E2 = mt.Index + l
                                info.AG = AG
                                PAR.CrossDimers.Add(info)

                            Next
                        End If
                    Next

                Next
            Next

            PAR.Primings.Add(key, New List(Of PrimeInfo))
        Next


         
        Dim tmpF As String
        Dim tmpR As String
        Dim pmrl As Integer

        For Each temp As GeneFile In temps
            For Each key As String In PAR.Primers.Keys
                pmr = PAR.Primers(key)
                pmrl = pmr.Length
                If temp.Iscircular Then
                    tmpF = temp.Sequence + temp.Sequence.Substring(0, pmrl)
                    tmpR = temp.RCSequence + temp.RCSequence.Substring(0, pmrl)
                Else
                    tmpF = temp.Sequence
                    tmpR = temp.RCSequence
                End If
                For si As Integer = 0 To tmpF.Length - pmrl
                    PAR.Primings(key).AddRange(FindMatches(pmr, tmpF, si, pmrl, key, temp, False, Na, C))
                Next
                For si As Integer = 0 To tmpR.Length - pmrl
                    PAR.Primings(key).AddRange(FindMatches(pmr, tmpR, si, pmrl, key, temp, True, Na, C))
                Next
            Next
        Next

        For Each key As String In PAR.Primers.Keys
            PAR.Primings(key).Sort()
        Next

        Dim col As New Collection
        For Each temp As GeneFile In temps
            col.Add(temp)
        Next
        Dim plist As New List(Of String)
        For Each pmr In Primers.Values
            plist.Add(pmr)
        Next
        PAR.Products = PCR(col, plist)
        PAR.CrossDimers.Sort()
        Return PAR
    End Function

    Public Shared Function FindMatches(ByVal Pmr As String, ByVal Temp As String, ByVal start As Integer, ByVal length As Integer, ByVal key As String, ByVal source As GeneFile, ByVal IsRC As Boolean, ByVal Na As Single, ByVal C As Single) As List(Of PrimeInfo)

        Dim mList As New List(Of PrimeInfo)
        Dim acc As Integer
        Dim pi As PrimeInfo

        acc = 0
        Dim i As Integer

        For i = 0 To length - 1
            If Pmr.Chars(i) = Temp.Chars(i + start) Then
                acc += 1
            ElseIf acc > 3 Then
                pi = New PrimeInfo
                pi.K1 = key
                pi.K2 = source
                pi.IsRC = IsRC
                pi.S1 = i - acc
                pi.E1 = i
                pi.S2 = start + i - acc
                pi.E2 = start + i
                pi.AG = CalculateTm(Pmr.Substring(i - acc, acc), Na, C).dG
                mList.Add(pi)
                acc = 0
            Else
                acc = 0
            End If
        Next
        If acc > 3 Then
            pi = New PrimeInfo
            pi.K1 = key
            pi.K2 = source
            pi.IsRC = IsRC
            pi.S1 = i - acc
            pi.E1 = i
            pi.S2 = start + i - acc
            pi.E2 = start + i
            pi.AG = CalculateTm(Pmr.Substring(i - acc, acc), Na, C).dG
            mList.Add(pi)
        End If
        Return mList
    End Function

    Public Shared Function SearchMaximumHomologousRegion(ByVal gList As List(Of GeneFile), boxlength As Integer ) As List(Of String)
        Dim wtList As New List(Of GeneFile)
        wtList.AddRange(gList)
        Dim mc As System.Text.RegularExpressions.MatchCollection
        Dim boxF As String
        Dim boxR As String
        Dim cF As Integer
        Dim cR As Integer
        Dim sList As New List(Of String)
        Dim pattern As String

        For Each g As GeneFile In gList
            If g.Sequence.Length < boxlength Then Continue For

            'get a box of 300bp length to search the sequence

            Dim be As Integer = g.BoxEnd(boxlength)
            For i As Integer = 0 To be
                boxF = g.SubSequence(i, boxlength + i)
                boxR = g.SubRCSequence(i, boxlength + i)

                For Each gv As GeneFile In wtList
                    mc = gv.Matches(boxF)
                    For Each m As System.Text.RegularExpressions.Match In mc
                        If gv Is g And i = m.Index Then Continue For
                        cF = GeneFile.ContinueMatch(g, i + boxlength, True, gv, m.Index + boxlength, True)
                        pattern = g.SubSequence(i, boxlength + cF + i)
                        i += cF
                        If Not sList.Contains(pattern) Then sList.Add(pattern)
                    Next
                    mc = gv.Matches(boxR)
                    For Each m As System.Text.RegularExpressions.Match In mc
                        If gv Is g And i = m.Index Then Continue For
                        cR = GeneFile.ContinueMatch(g, i + boxlength, False, gv, m.Index + boxlength, True)
                        pattern = g.SubRCSequence(i, boxlength + cR + i)
                        i += cR
                        If Not sList.Contains(pattern) Then sList.Add(pattern)
                    Next
                Next
            Next
            wtList.Remove(g)
        Next
        Return sList
    End Function

    Public Shared Function MergeSequence(ByVal gList As List(Of GeneFile), ByVal OnlySignificant As Boolean, ByVal OnlyExtend As Boolean) As List(Of GeneFile)
        '至少12个碱基完全相同
        Dim boxlength As Integer = 15
        'find a homologous arm first
        Dim xList As List(Of String)
        xList = SearchMaximumHomologousRegion(gList, boxlength)


        Dim sList As New List(Of String)
        If OnlySignificant Then
            Dim xLength As Integer = 0
            For Each s As String In xList
                xLength = Math.Max(s.Length, xLength)
            Next
            For Each s As String In xList
                If s.Length > 0.6 * xLength Then sList.Add(s)
            Next
        Else
            sList.AddRange(xList)
        End If

        'Next

        Dim LDict As New Dictionary(Of String, RestrictionEnzyme)

        Dim rec As String
        Dim cut As String
        Dim idx As Integer
        Dim ptn As String
        Dim kList As New List(Of String)

        For i As Integer = 0 To sList.Count - 1
            ptn = sList(i)
            rec = ptn
            cut = rec
            idx = 0
            LDict.Add("Homo" + i.ToString, New Nuctions.RestrictionEnzyme("Homo" + i.ToString, rec, idx + cut.Length, idx, "&"))
            kList.Add("Homo" + i.ToString)
        Next

        '确保只发生单交换 任何情况下，只有一种方法会发挥作用

        Dim zList As New List(Of String)

        '被单交换切割的列表
        Dim c0List As New List(Of GeneFile)
        Dim rsList As New List(Of GeneFile)
        Dim slrList As List(Of GeneFile)


        '不添加原始的质粒
        'rsList.AddRange(gList)
        For Each ptn In kList
            '每次清空列表 然后仅加入一种序列 确保单交换
            zList.Clear()
            zList.Add(ptn)
            c0List.Clear()
            For Each gf As GeneFile In gList
                Dim re As New EnzymeAnalysis.EnzymeAnalysisResult(zList, gf, LDict)
                c0List.AddRange(re.CutDNA())
            Next
            slrList = SingleLigateRecombination(c0List)
            For Each gf As GeneFile In slrList
                gf.Name = "Merge(" + LDict(ptn).Sequence.Length.ToString + ")-" + gf.Length.ToString
            Next
            rsList.AddRange(slrList)
        Next

        Dim reList As New List(Of GeneFile)

        If OnlyExtend Then
            Dim gLength As Integer = 0
            For Each gf As GeneFile In gList
                gLength = IIf(gf.Length > gLength, gf.Length, gLength)
            Next
            For Each gf As GeneFile In rsList
                If gf.Length > gLength Then
                    reList.Add(gf)
                End If
            Next
        Else
            reList.AddRange(rsList)
        End If

        Dim sVList As New List(Of GeneFile)
        Dim contains As Boolean
        For Each gf As GeneFile In reList
            '不可能有小于1000bp的环形质粒
            If gf.Length <= 1024 And gf.Iscircular Then Continue For
            contains = False
            For Each gfx As GeneFile In gList
                contains = contains Or (gfx = gf)
                If contains Then Exit For
            Next
            If Not contains Then
                For Each gfx As GeneFile In sVList
                    contains = contains Or (gfx = gf)
                    If contains Then Exit For
                Next
            End If
            If Not contains Then sVList.Add(gf)
        Next
        Return sVList
    End Function

    Public Shared Function Recombination(ByVal gList As List(Of GeneFile), ByVal method As RecombinationMethod) As List(Of GeneFile)
        Dim vList As New List(Of GeneFile)

        Select Case method
            Case RecombinationMethod.Homologous
                '至少300个碱基
                Dim boxlength As Integer = 300
                'find a homologous arm first
                Dim sList As List(Of String)
                sList = SearchMaximumHomologousRegion(gList, boxlength)

                Dim LDict As New Dictionary(Of String, RestrictionEnzyme)

                Dim rec As String
                Dim cut As String
                Dim idx As Integer
                Dim ptn As String
                Dim kList As New List(Of String)

                For i As Integer = 0 To sList.Count - 1
                    ptn = sList(i)
                    rec = ptn
                    cut = rec
                    idx = 0
                    LDict.Add("Homo" + i.ToString, New Nuctions.RestrictionEnzyme("Homo" + i.ToString, rec, idx + cut.Length, idx, "&"))
                    kList.Add("Homo" + i.ToString)
                Next

                '确保只发生单交换 任何情况下，只有一种方法会发挥作用

                Dim zList As New List(Of String)

                '被单交换切割的列表
                Dim c0List As New List(Of GeneFile)
                Dim rsList As New List(Of GeneFile)
                rsList.AddRange(gList)

                For Each ptn In kList
                    '每次清空列表 然后仅加入一种序列 确保单交换
                    zList.Clear()
                    zList.Add(ptn)
                    c0List.Clear()
                    For Each gf As GeneFile In gList
                        Dim re As New EnzymeAnalysis.EnzymeAnalysisResult(zList, gf, LDict)
                        c0List.AddRange(re.CutDNA())

                    Next
                    rsList.AddRange(SingleLigateRecombination(c0List))
                Next

                Dim sVList As New List(Of GeneFile)
                Dim contains As Boolean
                For Each gf As GeneFile In rsList
                    contains = False
                    For Each gfx As GeneFile In sVList
                        contains = contains Or (gfx = gf)
                    Next
                    If Not contains Then sVList.Add(gf)
                Next

                Return sVList

            Case RecombinationMethod.LambdaRecombination

                Dim LDict As New Dictionary(Of String, RestrictionEnzyme)

                Dim rvList As New List(Of GeneFile)
                Dim rsList As New List(Of GeneFile)
                For Each gf As GeneFile In gList
                    If gf.Length > 70 And gf.Length < 10000 And (Not gf.Iscircular) Then
                        Dim gfc As GeneFile = gf.CloneWithoutFeatures
                        Dim sList As New List(Of String)



                        Dim rec As String
                        Dim cut As String
                        Dim idx As Integer
                        LDict.Clear()


                        rec = gf.Sequence.Substring(0, 35)
                        cut = rec
                        idx = 0
                        LDict.Add("LambdaRecF", New Nuctions.RestrictionEnzyme("LambdaRecF", rec, idx + cut.Length, idx, "&"))
                        gfc.End_F = "&3" + Nuctions.ReverseComplement(rec)
                        sList.Add("LambdaRecF")

                        rec = gf.Sequence.Substring(gf.Length - 35, 35)
                        cut = rec
                        idx = 0
                        LDict.Add("LambdaRecR", New Nuctions.RestrictionEnzyme("LambdaRecR", rec, idx + cut.Length, idx, "&"))
                        gfc.End_R = "&3" + rec
                        sList.Add("LambdaRecR")


                        rvList.Clear()
                        rvList.AddRange(gList)
                        rvList.Remove(gf)

                        Dim c0List As New List(Of GeneFile)

                        For Each gfs As GeneFile In rvList
                            Dim re As New EnzymeAnalysis.EnzymeAnalysisResult(sList, gfs, LDict)
                            c0List.AddRange(re.CutDNA)
                        Next
                        c0List.Add(gfc)

                        rsList = LigateRecombination(c0List)

                        If rsList.Count > 1 Then
                            Return rsList
                        End If
                    End If
                Next
                Return rsList
            Case RecombinationMethod.FRT
                Dim rlist As New List(Of String)
                rlist.Add("frt")
                Dim c0List As New List(Of GeneFile)

                For Each gf As GeneFile In gList
                    Dim re As New EnzymeAnalysis.EnzymeAnalysisResult(rlist, gf, frmMain.RecombinationSiteDict)
                    c0List.AddRange(re.CutDNA)
                Next
                Return LigateRecombination(c0List)
            Case RecombinationMethod.LoxP
                Dim rlist As New List(Of String)
                rlist.Add("loxP")
                Dim c0List As New List(Of GeneFile)

                For Each gf As GeneFile In gList
                    Dim re As New EnzymeAnalysis.EnzymeAnalysisResult(rlist, gf, frmMain.RecombinationSiteDict)
                    c0List.AddRange(re.CutDNA)
                Next
                Return LigateRecombination(c0List)
            Case RecombinationMethod.LambdaAttBP

                '成对出现原罪
                '必须成对出现才能切割 否则会造成错误
                Dim rlist As New List(Of String)
                '

                If ContainsRecombineGroup(New String() {"LattB", "LattP"}, gList) Then
                    rlist.Add("LattB")
                    rlist.Add("LattP")
                End If
                If ContainsRecombineGroup(New String() {"LattB1", "LattP1"}, gList) Then
                    rlist.Add("LattB1")
                    rlist.Add("LattP1")
                End If
                If ContainsRecombineGroup(New String() {"LattB2", "LattP2"}, gList) Then
                    rlist.Add("LattB2")
                    rlist.Add("LattP2")
                End If
                Dim c0List As New List(Of GeneFile)

                For Each gf As GeneFile In gList
                    Dim re As New EnzymeAnalysis.EnzymeAnalysisResult(rlist, gf, frmMain.RecombinationSiteDict)
                    c0List.AddRange(re.CutDNA)
                Next
                Return LigateRecombination(c0List)
            Case RecombinationMethod.LambdaAttLR
                Dim rlist As New List(Of String)
                If ContainsRecombineGroup(New String() {"LattL", "LattR"}, gList) Then
                    rlist.Add("LattL")
                    rlist.Add("LattR")
                End If
                If ContainsRecombineGroup(New String() {"LattL1", "LattR1"}, gList) Then
                    rlist.Add("LattL1")
                    rlist.Add("LattR1")
                End If
                If ContainsRecombineGroup(New String() {"LattL2", "LattR2"}, gList) Then
                    rlist.Add("LattL2")
                    rlist.Add("LattR2")
                End If
                Dim c0List As New List(Of GeneFile)

                For Each gf As GeneFile In gList
                    Dim re As New EnzymeAnalysis.EnzymeAnalysisResult(rlist, gf, frmMain.RecombinationSiteDict)
                    c0List.AddRange(re.CutDNA)
                Next
                Return LigateRecombination(c0List)
            Case RecombinationMethod.HK022AttBP
                Dim rlist As New List(Of String)
                If ContainsRecombineGroup(New String() {"HattB", "HattP"}, gList) Then
                    rlist.Add("HattB")
                    rlist.Add("HattP")
                End If
                Dim c0List As New List(Of GeneFile)

                For Each gf As GeneFile In gList
                    Dim re As New EnzymeAnalysis.EnzymeAnalysisResult(rlist, gf, frmMain.RecombinationSiteDict)
                    c0List.AddRange(re.CutDNA)
                Next
                Return LigateRecombination(c0List)
            Case RecombinationMethod.HK022AttLR
                Dim rlist As New List(Of String)
                If ContainsRecombineGroup(New String() {"HattL", "HattR"}, gList) Then
                    rlist.Add("HattL")
                    rlist.Add("HattR")
                End If

                Dim c0List As New List(Of GeneFile)

                For Each gf As GeneFile In gList
                    Dim re As New EnzymeAnalysis.EnzymeAnalysisResult(rlist, gf, frmMain.RecombinationSiteDict)
                    c0List.AddRange(re.CutDNA)
                Next
                Return LigateRecombination(c0List)
            Case RecombinationMethod.P21AttBP
                Dim rlist As New List(Of String)
                If ContainsRecombineGroup(New String() {"P21attB", "P21attP"}, gList) Then
                    rlist.Add("P21attB")
                    rlist.Add("P21attP")
                End If
                Dim c0List As New List(Of GeneFile)

                For Each gf As GeneFile In gList
                    Dim re As New EnzymeAnalysis.EnzymeAnalysisResult(rlist, gf, frmMain.RecombinationSiteDict)
                    c0List.AddRange(re.CutDNA)
                Next
                Return LigateRecombination(c0List)
            Case RecombinationMethod.P21AttLR
                Dim rlist As New List(Of String)
                If ContainsRecombineGroup(New String() {"P21attL", "P21attR"}, gList) Then
                    rlist.Add("P21attL")
                    rlist.Add("P21attR")
                End If
                Dim c0List As New List(Of GeneFile)

                For Each gf As GeneFile In gList
                    Dim re As New EnzymeAnalysis.EnzymeAnalysisResult(rlist, gf, frmMain.RecombinationSiteDict)
                    c0List.AddRange(re.CutDNA)
                Next
                Return LigateRecombination(c0List)
            Case RecombinationMethod.P22AttBP
                Dim rlist As New List(Of String)
                If ContainsRecombineGroup(New String() {"P22attB", "P22attP"}, gList) Then
                    rlist.Add("P22attB")
                    rlist.Add("P22attP")
                End If

                Dim c0List As New List(Of GeneFile)

                For Each gf As GeneFile In gList
                    Dim re As New EnzymeAnalysis.EnzymeAnalysisResult(rlist, gf, frmMain.RecombinationSiteDict)
                    c0List.AddRange(re.CutDNA)
                Next
                Return LigateRecombination(c0List)
            Case RecombinationMethod.P22AttLR
                Dim rlist As New List(Of String)
                If ContainsRecombineGroup(New String() {"P22attL", "P22attR"}, gList) Then
                    rlist.Add("P22attL")
                    rlist.Add("P22attR")

                End If
                Dim c0List As New List(Of GeneFile)

                For Each gf As GeneFile In gList
                    Dim re As New EnzymeAnalysis.EnzymeAnalysisResult(rlist, gf, frmMain.RecombinationSiteDict)
                    c0List.AddRange(re.CutDNA)
                Next
                Return LigateRecombination(c0List)
            Case RecombinationMethod.Phi80AttBP
                Dim rlist As New List(Of String)
                If ContainsRecombineGroup(New String() {"PattB", "PattP"}, gList) Then
                    rlist.Add("PattB")
                    rlist.Add("PattP")

                End If
                Dim c0List As New List(Of GeneFile)

                For Each gf As GeneFile In gList
                    Dim re As New EnzymeAnalysis.EnzymeAnalysisResult(rlist, gf, frmMain.RecombinationSiteDict)
                    c0List.AddRange(re.CutDNA)
                Next
                Return LigateRecombination(c0List)
            Case RecombinationMethod.Phi80AttLR
                Dim rlist As New List(Of String)
                If ContainsRecombineGroup(New String() {"PattL", "PattR"}, gList) Then
                    rlist.Add("PattL")
                    rlist.Add("PattR")

                End If
                Dim c0List As New List(Of GeneFile)

                For Each gf As GeneFile In gList
                    Dim re As New EnzymeAnalysis.EnzymeAnalysisResult(rlist, gf, frmMain.RecombinationSiteDict)
                    c0List.AddRange(re.CutDNA)
                Next
                Return LigateRecombination(c0List)
            Case Else
                Return New List(Of GeneFile)
        End Select

    End Function

    Private Shared Function ContainsRecombineGroup(ByVal Keys As String(), ByVal gList As List(Of GeneFile)) As Boolean

        Dim vList As New List(Of String)
        Dim contains As Boolean = True
        Dim found As Boolean

        For Each key As String In Keys
            vList.Clear()
            vList.Add(key)
            found = False
            For Each gf As GeneFile In gList
                Dim re As New EnzymeAnalysis.EnzymeAnalysisResult(vList, gf, frmMain.RecombinationSiteDict)
                If re.Count > 0 Then found = True : Exit For
            Next
            contains = contains And found
        Next
        Return contains
    End Function

    Private Shared Function LigateRecombination(ByVal c0List As List(Of GeneFile)) As List(Of GeneFile)
        Dim c1List As New List(Of GeneFile)

        For Each gf1 As GeneFile In c0List
            For Each gf2 As GeneFile In c0List
                Dim gf As GeneFile
                gf = gf1 - gf2
                If Not (gf Is Nothing) Then c1List.Add(gf)
                gf = gf1 - gf2.RC
                If Not (gf Is Nothing) Then c1List.Add(gf)
                gf = gf1.RC - gf2
                If Not (gf Is Nothing) Then c1List.Add(gf)
                gf = gf1.RC - gf2.RC
                If Not (gf Is Nothing) Then c1List.Add(gf)
            Next
        Next

        Dim c2List As New List(Of GeneFile)

        For Each gf1 As GeneFile In c1List
            For Each gf2 As GeneFile In c0List
                Dim gf As GeneFile
                gf = gf1 - gf2
                If Not (gf Is Nothing) Then c2List.Add(gf)
                gf = gf1 - gf2.RC
                If Not (gf Is Nothing) Then c2List.Add(gf)
                gf = gf1.RC - gf2
                If Not (gf Is Nothing) Then c2List.Add(gf)
                gf = gf1.RC - gf2.RC
                If Not (gf Is Nothing) Then c2List.Add(gf)
            Next
        Next

        Dim cSList As New List(Of GeneFile)
        Dim gfu As GeneFile
        For Each gf As GeneFile In c0List
            gfu = -gf
            If Not (gfu Is Nothing) And gf.Length > 0 Then cSList.Add(gfu)
        Next
        For Each gf As GeneFile In c1List
            gfu = -gf
            If Not (gfu Is Nothing) And gf.Length > 0 Then cSList.Add(gfu)
        Next
        For Each gf As GeneFile In c2List
            gfu = -gf
            If Not (gfu Is Nothing) And gf.Length > 0 Then cSList.Add(gfu)
        Next
        cSList.AddRange(c0List)
        cSList.AddRange(c1List)
        cSList.AddRange(c2List)

        Dim sRList As New List(Of GeneFile)
        For Each gf As GeneFile In cSList
            If gf.IsNotRecombinating Then sRList.Add(gf)
        Next

        Dim sVList As New List(Of GeneFile)
        Dim contains As Boolean
        For Each gf As GeneFile In sRList
            contains = False
            For Each gfx As GeneFile In sVList
                contains = contains Or (gfx = gf)
            Next
            If Not contains Then sVList.Add(gf)
        Next

        For Each gf As GeneFile In sVList
            gf.Name = "Rec " + gf.Length.ToString
        Next
        Return sVList
    End Function

    Private Shared Function SingleLigateRecombination(ByVal c0List As List(Of GeneFile)) As List(Of GeneFile)
        Dim c1List As New List(Of GeneFile)

        For Each gf1 As GeneFile In c0List
            For Each gf2 As GeneFile In c0List
                Dim gf As GeneFile
                gf = gf1 - gf2
                If Not (gf Is Nothing) Then c1List.Add(gf)
                gf = gf1 - gf2.RC
                If Not (gf Is Nothing) Then c1List.Add(gf)
                gf = gf1.RC - gf2
                If Not (gf Is Nothing) Then c1List.Add(gf)
                gf = gf1.RC - gf2.RC
                If Not (gf Is Nothing) Then c1List.Add(gf)
            Next
        Next

        'Dim c2List As New List(Of GeneFile)

        'For Each gf1 As GeneFile In c1List
        '    For Each gf2 As GeneFile In c0List
        '        Dim gf As GeneFile
        '        gf = gf1 - gf2
        '        If Not (gf Is Nothing) Then c2List.Add(gf)
        '        gf = gf1 - gf2.RC
        '        If Not (gf Is Nothing) Then c2List.Add(gf)
        '        gf = gf1.RC - gf2
        '        If Not (gf Is Nothing) Then c2List.Add(gf)
        '        gf = gf1.RC - gf2.RC
        '        If Not (gf Is Nothing) Then c2List.Add(gf)
        '    Next
        'Next

        Dim cSList As New List(Of GeneFile)
        Dim gfu As GeneFile
        For Each gf As GeneFile In c0List
            gfu = -gf
            If Not (gfu Is Nothing) And gf.Length > 0 Then cSList.Add(gfu)
        Next
        For Each gf As GeneFile In c1List
            gfu = -gf
            If Not (gfu Is Nothing) And gf.Length > 0 Then cSList.Add(gfu)
        Next
        'For Each gf As GeneFile In c2List
        '    gfu = -gf
        '    If Not (gfu Is Nothing) Then cSList.Add(gfu)
        'Next
        'cSList.AddRange(c0List)
        cSList.AddRange(c1List)
        'cSList.AddRange(c2List)

        Dim sRList As New List(Of GeneFile)
        For Each gf As GeneFile In cSList
            If gf.IsNotRecombinating Then sRList.Add(gf)
        Next

        Dim sVList As New List(Of GeneFile)
        Dim contains As Boolean
        For Each gf As GeneFile In sRList
            contains = False
            For Each gfx As GeneFile In sVList
                contains = contains Or (gfx = gf)
            Next
            If Not contains Then sVList.Add(gf)
        Next

        For Each gf As GeneFile In sVList
            gf.Name = "Rec " + gf.Length.ToString
        Next
        Return sVList
    End Function

    Public Shared Function FindEnzymes(ByVal Conditions As List(Of EnzymeAnalysisItem)) As List(Of String)
        Dim sList As New List(Of String)

        For Each ez As RestrictionEnzyme In frmMain.EnzymeCol.RECollection
            sList.Add(ez.Name)
        Next

        Dim rmList As New List(Of String)
        Dim kList As New List(Of String)

        For Each eai As EnzymeAnalysisItem In Conditions
            If eai.Use Then
                Select Case eai.Method
                    Case EnzymeAnalysisEnum.Equal
                        rmList.Clear()
                        For Each key As String In sList
                            kList.Clear()
                            kList.Add(key)
                            Dim ear As New Nuctions.EnzymeAnalysis.EnzymeAnalysisResult(kList, eai.GeneFile)
                            If ear.Count <> eai.Value Then
                                rmList.Add(key)
                            End If
                        Next
                        For Each key As String In rmList
                            sList.Remove(key)
                        Next
                    Case EnzymeAnalysisEnum.Greater
                        rmList.Clear()
                        For Each key As String In sList
                            kList.Clear()
                            kList.Add(key)
                            Dim ear As New Nuctions.EnzymeAnalysis.EnzymeAnalysisResult(kList, eai.GeneFile)
                            If ear.Count <= eai.Value Then
                                rmList.Add(key)
                            End If
                        Next
                        For Each key As String In rmList
                            sList.Remove(key)
                        Next
                    Case EnzymeAnalysisEnum.Less
                        rmList.Clear()
                        For Each key As String In sList
                            kList.Clear()
                            kList.Add(key)
                            Dim ear As New Nuctions.EnzymeAnalysis.EnzymeAnalysisResult(kList, eai.GeneFile)
                            If ear.Count >= eai.Value Then
                                rmList.Add(key)
                            End If
                        Next
                        For Each key As String In rmList
                            sList.Remove(key)
                        Next
                End Select
            End If
        Next
        sList.Sort()
        Return sList
    End Function

    Public Shared Function ParseInnerPrimer(ByVal pmr As String) As String
        If pmr Is Nothing Then Return ""

        Dim ip As Integer = pmr.LastIndexOf(">")
        ip = IIf(ip < 0, 0, ip)
        Return pmr.Substring(ip)
    End Function
End Class
