﻿Public Class VecLib
    '这个功能就是把所有的Vector保存在数据库当中
    '便于对所有的Vector进行Feature和序列的搜索



End Class


Public Class FeatureLib
    '保存所有的Feature

End Class