Public Class frmVecDesign

End Class