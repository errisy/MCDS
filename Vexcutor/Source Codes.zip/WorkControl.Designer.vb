﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class WorkControl
    Inherits System.Windows.Forms.UserControl

    'UserControl 重写 Dispose，以清理组件列表。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows 窗体设计器所必需的
    Private components As System.ComponentModel.IContainer

    '注意: 以下过程是 Windows 窗体设计器所必需的
    '可以使用 Windows 窗体设计器修改它。
    '不要使用代码编辑器修改它。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(WorkControl))
        Me.scMain = New System.Windows.Forms.SplitContainer
        Me.cms_ChartItem = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.tsmCopyGroup = New System.Windows.Forms.ToolStripMenuItem
        Me.tsmPasteGroup = New System.Windows.Forms.ToolStripMenuItem
        Me.ViewVToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolStripSeparator1 = New System.Windows.Forms.ToolStripSeparator
        Me.EnzymeDigestionEToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.PCRRToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ModificationMToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.GelSeparationGToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.LigationLToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.TransformationScreenTToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.RecombinationCToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.EnzymeAnalysisAToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.MergeXToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolStripSeparator2 = New System.Windows.Forms.ToolStripSeparator
        Me.RecalculateAllChildrenToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolStripSeparator3 = New System.Windows.Forms.ToolStripSeparator
        Me.AutoArragneToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.AutoFitChildrenToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.StepFitChildrenToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.sfdProject = New System.Windows.Forms.SaveFileDialog
        Me.ofdGeneFile = New System.Windows.Forms.OpenFileDialog
        Me.ofdSequence = New System.Windows.Forms.OpenFileDialog
        Me.sfdExport = New System.Windows.Forms.SaveFileDialog
        Me.lv_Chart = New Vecute.OperationView
        Me.pvMain = New Vecute.PropertyView
        Me.scMain.Panel1.SuspendLayout()
        Me.scMain.Panel2.SuspendLayout()
        Me.scMain.SuspendLayout()
        Me.cms_ChartItem.SuspendLayout()
        Me.SuspendLayout()
        '
        'scMain
        '
        Me.scMain.BackColor = System.Drawing.Color.Lavender
        Me.scMain.Dock = System.Windows.Forms.DockStyle.Fill
        Me.scMain.Location = New System.Drawing.Point(0, 0)
        Me.scMain.Name = "scMain"
        Me.scMain.Orientation = System.Windows.Forms.Orientation.Horizontal
        '
        'scMain.Panel1
        '
        Me.scMain.Panel1.Controls.Add(Me.lv_Chart)
        '
        'scMain.Panel2
        '
        Me.scMain.Panel2.Controls.Add(Me.pvMain)
        Me.scMain.Size = New System.Drawing.Size(968, 505)
        Me.scMain.SplitterDistance = 362
        Me.scMain.TabIndex = 4
        '
        'cms_ChartItem
        '
        Me.cms_ChartItem.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.tsmCopyGroup, Me.tsmPasteGroup, Me.ViewVToolStripMenuItem, Me.ToolStripSeparator1, Me.EnzymeDigestionEToolStripMenuItem, Me.PCRRToolStripMenuItem, Me.ModificationMToolStripMenuItem, Me.GelSeparationGToolStripMenuItem, Me.LigationLToolStripMenuItem, Me.TransformationScreenTToolStripMenuItem, Me.RecombinationCToolStripMenuItem, Me.EnzymeAnalysisAToolStripMenuItem, Me.MergeXToolStripMenuItem, Me.ToolStripSeparator2, Me.RecalculateAllChildrenToolStripMenuItem, Me.ToolStripSeparator3, Me.AutoArragneToolStripMenuItem, Me.AutoFitChildrenToolStripMenuItem, Me.StepFitChildrenToolStripMenuItem})
        Me.cms_ChartItem.Name = "cms_ChartItem"
        Me.cms_ChartItem.Size = New System.Drawing.Size(215, 374)
        '
        'tsmCopyGroup
        '
        Me.tsmCopyGroup.Name = "tsmCopyGroup"
        Me.tsmCopyGroup.Size = New System.Drawing.Size(214, 22)
        Me.tsmCopyGroup.Text = "Copy Group"
        '
        'tsmPasteGroup
        '
        Me.tsmPasteGroup.Name = "tsmPasteGroup"
        Me.tsmPasteGroup.Size = New System.Drawing.Size(214, 22)
        Me.tsmPasteGroup.Text = "Paste Group"
        '
        'ViewVToolStripMenuItem
        '
        Me.ViewVToolStripMenuItem.Name = "ViewVToolStripMenuItem"
        Me.ViewVToolStripMenuItem.Size = New System.Drawing.Size(214, 22)
        Me.ViewVToolStripMenuItem.Text = "View(&V)"
        '
        'ToolStripSeparator1
        '
        Me.ToolStripSeparator1.Name = "ToolStripSeparator1"
        Me.ToolStripSeparator1.Size = New System.Drawing.Size(211, 6)
        '
        'EnzymeDigestionEToolStripMenuItem
        '
        Me.EnzymeDigestionEToolStripMenuItem.Name = "EnzymeDigestionEToolStripMenuItem"
        Me.EnzymeDigestionEToolStripMenuItem.Size = New System.Drawing.Size(214, 22)
        Me.EnzymeDigestionEToolStripMenuItem.Tag = "1"
        Me.EnzymeDigestionEToolStripMenuItem.Text = "Enzyme Digestion...(&E)"
        '
        'PCRRToolStripMenuItem
        '
        Me.PCRRToolStripMenuItem.Name = "PCRRToolStripMenuItem"
        Me.PCRRToolStripMenuItem.Size = New System.Drawing.Size(214, 22)
        Me.PCRRToolStripMenuItem.Tag = "2"
        Me.PCRRToolStripMenuItem.Text = "PCR...(&R)"
        '
        'ModificationMToolStripMenuItem
        '
        Me.ModificationMToolStripMenuItem.Name = "ModificationMToolStripMenuItem"
        Me.ModificationMToolStripMenuItem.Size = New System.Drawing.Size(214, 22)
        Me.ModificationMToolStripMenuItem.Tag = "3"
        Me.ModificationMToolStripMenuItem.Text = "Modification...(&M)"
        '
        'GelSeparationGToolStripMenuItem
        '
        Me.GelSeparationGToolStripMenuItem.Name = "GelSeparationGToolStripMenuItem"
        Me.GelSeparationGToolStripMenuItem.Size = New System.Drawing.Size(214, 22)
        Me.GelSeparationGToolStripMenuItem.Tag = "4"
        Me.GelSeparationGToolStripMenuItem.Text = "Gel Separation...(&G)"
        '
        'LigationLToolStripMenuItem
        '
        Me.LigationLToolStripMenuItem.Name = "LigationLToolStripMenuItem"
        Me.LigationLToolStripMenuItem.Size = New System.Drawing.Size(214, 22)
        Me.LigationLToolStripMenuItem.Tag = "5"
        Me.LigationLToolStripMenuItem.Text = "Ligation...(&L)"
        '
        'TransformationScreenTToolStripMenuItem
        '
        Me.TransformationScreenTToolStripMenuItem.Name = "TransformationScreenTToolStripMenuItem"
        Me.TransformationScreenTToolStripMenuItem.Size = New System.Drawing.Size(214, 22)
        Me.TransformationScreenTToolStripMenuItem.Tag = "6"
        Me.TransformationScreenTToolStripMenuItem.Text = "Screen...(&T)"
        '
        'RecombinationCToolStripMenuItem
        '
        Me.RecombinationCToolStripMenuItem.Name = "RecombinationCToolStripMenuItem"
        Me.RecombinationCToolStripMenuItem.Size = New System.Drawing.Size(214, 22)
        Me.RecombinationCToolStripMenuItem.Tag = "7"
        Me.RecombinationCToolStripMenuItem.Text = "Recombination...(&C)"
        '
        'EnzymeAnalysisAToolStripMenuItem
        '
        Me.EnzymeAnalysisAToolStripMenuItem.Name = "EnzymeAnalysisAToolStripMenuItem"
        Me.EnzymeAnalysisAToolStripMenuItem.Size = New System.Drawing.Size(214, 22)
        Me.EnzymeAnalysisAToolStripMenuItem.Tag = "8"
        Me.EnzymeAnalysisAToolStripMenuItem.Text = "Enzyme Analysis...(&A)"
        '
        'MergeXToolStripMenuItem
        '
        Me.MergeXToolStripMenuItem.Name = "MergeXToolStripMenuItem"
        Me.MergeXToolStripMenuItem.Size = New System.Drawing.Size(214, 22)
        Me.MergeXToolStripMenuItem.Tag = "10"
        Me.MergeXToolStripMenuItem.Text = "Merge...(&X)"
        '
        'ToolStripSeparator2
        '
        Me.ToolStripSeparator2.Name = "ToolStripSeparator2"
        Me.ToolStripSeparator2.Size = New System.Drawing.Size(211, 6)
        '
        'RecalculateAllChildrenToolStripMenuItem
        '
        Me.RecalculateAllChildrenToolStripMenuItem.Name = "RecalculateAllChildrenToolStripMenuItem"
        Me.RecalculateAllChildrenToolStripMenuItem.Size = New System.Drawing.Size(214, 22)
        Me.RecalculateAllChildrenToolStripMenuItem.Text = "Recalculate All Children"
        '
        'ToolStripSeparator3
        '
        Me.ToolStripSeparator3.Name = "ToolStripSeparator3"
        Me.ToolStripSeparator3.Size = New System.Drawing.Size(211, 6)
        '
        'AutoArragneToolStripMenuItem
        '
        Me.AutoArragneToolStripMenuItem.Name = "AutoArragneToolStripMenuItem"
        Me.AutoArragneToolStripMenuItem.Size = New System.Drawing.Size(214, 22)
        Me.AutoArragneToolStripMenuItem.Text = "Auto Arrange"
        '
        'AutoFitChildrenToolStripMenuItem
        '
        Me.AutoFitChildrenToolStripMenuItem.Name = "AutoFitChildrenToolStripMenuItem"
        Me.AutoFitChildrenToolStripMenuItem.Size = New System.Drawing.Size(214, 22)
        Me.AutoFitChildrenToolStripMenuItem.Text = "Auto Fit Children"
        '
        'StepFitChildrenToolStripMenuItem
        '
        Me.StepFitChildrenToolStripMenuItem.Name = "StepFitChildrenToolStripMenuItem"
        Me.StepFitChildrenToolStripMenuItem.Size = New System.Drawing.Size(214, 22)
        Me.StepFitChildrenToolStripMenuItem.Text = "Step Fit Children"
        '
        'sfdProject
        '
        Me.sfdProject.Filter = "Vecute Files|*.stone"
        '
        'ofdGeneFile
        '
        Me.ofdGeneFile.Filter = "GeneBank Files|*.gb"
        '
        'ofdSequence
        '
        Me.ofdSequence.Filter = "Sequence Files|*.txt;*.seq"
        '
        'sfdExport
        '
        Me.sfdExport.Filter = "TEXT File|*.txt"
        '
        'lv_Chart
        '
        Me.lv_Chart.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lv_Chart.Location = New System.Drawing.Point(0, 0)
        Me.lv_Chart.Name = "lv_Chart"
        Me.lv_Chart.Offset = CType(resources.GetObject("lv_Chart.Offset"), System.Drawing.PointF)
        Me.lv_Chart.ScaleValue = 1.0!
        Me.lv_Chart.Size = New System.Drawing.Size(968, 362)
        Me.lv_Chart.SourceMode = False
        Me.lv_Chart.TabIndex = 0
        '
        'pvMain
        '
        Me.pvMain.Dock = System.Windows.Forms.DockStyle.Fill
        Me.pvMain.Location = New System.Drawing.Point(0, 0)
        Me.pvMain.Name = "pvMain"
        Me.pvMain.SelectItem = Nothing
        Me.pvMain.Size = New System.Drawing.Size(968, 139)
        Me.pvMain.TabIndex = 0
        '
        'WorkControl
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.Controls.Add(Me.scMain)
        Me.Name = "WorkControl"
        Me.Size = New System.Drawing.Size(968, 505)
        Me.scMain.Panel1.ResumeLayout(False)
        Me.scMain.Panel2.ResumeLayout(False)
        Me.scMain.ResumeLayout(False)
        Me.cms_ChartItem.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents scMain As System.Windows.Forms.SplitContainer
    Friend WithEvents pvMain As Vecute.PropertyView
    Friend WithEvents sfdProject As System.Windows.Forms.SaveFileDialog
    Friend WithEvents ofdGeneFile As System.Windows.Forms.OpenFileDialog
    Friend WithEvents cms_ChartItem As System.Windows.Forms.ContextMenuStrip
    Friend WithEvents ViewVToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator1 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents EnzymeDigestionEToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PCRRToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ModificationMToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents GelSeparationGToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents LigationLToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TransformationScreenTToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents RecombinationCToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents EnzymeAnalysisAToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents MergeXToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ofdSequence As System.Windows.Forms.OpenFileDialog
    Friend WithEvents sfdExport As System.Windows.Forms.SaveFileDialog
    Friend WithEvents ToolStripSeparator2 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents RecalculateAllChildrenToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents lv_Chart As Vecute.OperationView
    Friend WithEvents ToolStripSeparator3 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents AutoArragneToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AutoFitChildrenToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents StepFitChildrenToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents tsmCopyGroup As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents tsmPasteGroup As System.Windows.Forms.ToolStripMenuItem

End Class
